#!/usr/bin/env python3
"""Negative security/availability test: unreachable hybrid port must not produce downgrade.
Running alongside the primary experiment is safe (different port/IP).
"""
import json,subprocess,time,sys
from pathlib import Path
D=Path(__file__).resolve().parent
B=str(D/'bin/tls_app');cert=str(D/'certs/server.crt');key=str(D/'certs/server.key')
server=subprocess.Popen([B,'server','--bind','127.0.0.39','--old-port','31339','--new-port','32339','--cert',cert,'--key',key],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,bufsize=1)
try:
 ready=server.stdout.readline().strip();assert ready.startswith('READY'),ready
 result=[]
 for mode in ['mbb','bmb']:
  c=subprocess.Popen([B,'client','--host','127.0.0.39','--old-port','31339','--new-port','32339',
      '--ca',cert,'--mode',mode,'--force-hybrid-fail','1'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,
      stderr=subprocess.PIPE,text=True,bufsize=1)
  line=c.stdout.readline().strip();assert line.startswith('READY classical_verified=1'),line
  time.sleep(.060)
  c.stdin.write('MIGRATE\n');c.stdin.flush();mig=c.stdout.readline().strip()
  time.sleep(.065)
  c.stdin.write('STOP\n');c.stdin.flush();end=c.stdout.readline().strip()
  c.stdin.close();status=c.wait(timeout=4)
  assert end.startswith('RESULT '),(mode,end)
  m=json.loads(end[7:]);m['mode']=mode;m['stop_status']=status;m['migrate_line']=mig
  assert m['classical_verified']==1 and m['hybrid_verified']==0 and m['unsafe_downgrade']==0
  if mode=='mbb':
   assert m['old_preserved_on_failure']==1 and status==0 and m['old_responses']>=10,(status,m)
  else:assert m['old_preserved_on_failure']==0 and status!=0,(status,m)
  result.append(m)
 out=D/'results/negative_test_unavailable_hybrid.json';out.write_text(json.dumps(result,indent=2))
 print('NEGATIVE TEST PASS',json.dumps([{'mode':r['mode'],'old_preserved':r['old_preserved_on_failure'],
  'classical_responses':r['old_responses'],'hybrid_verified':r['hybrid_verified'],'unsafe_downgrade':r['unsafe_downgrade']} for r in result]))
finally:
 server.terminate()
 try:server.wait(timeout=2)
 except subprocess.TimeoutExpired:server.kill();server.wait()
