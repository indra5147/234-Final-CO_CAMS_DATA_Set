# EXP-09A: make-before-break vs break-before-make TLS migration

**Experimental purpose:** test whether keeping a certificate-verified, active classical TLS application session running until a certificate-verified X25519MLKEM768 session is ready reduces application response gaps. This evaluates the migration mechanism. The locked P1 V1.0 scheduler is copied unchanged from EXP-08.

## What is actually implemented

Seven Linux processes: C0 coordinating node, SW1/SW2 asyncio bidirectional TCP proxies, CL1/CL2 HTTP endpoint agents, SR1/SR2 real OpenSSL TLS1.3 servers. Each policy run serves twelve simultaneous recurring real `PING`/`PONG` application sessions, split across the two proxied paths. All clients use server hostname verification (`sdn-pqc.local`) and validate the negotiated key-exchange group. The server uses a self-signed P-256 ECDSA certificate. OpenSSL 3.5.5, no TLS session resumption tickets.

- **BMB:** stop and close the old classical session; then establish, validate and application-test the new hybrid TLS session; then resume scheduled requests.
- **MBB:** establish, validate and application-test the new hybrid TLS session while old traffic continues. Under the sender mutex, wait for the old in-flight request to finish, switch the session, then close the old session. If hybrid establishment fails, do *not* mark migration complete; keep verified old transport active as a temporary transitional recovery state. **This prototype has no implemented hard-deadline enforcement and must not be deployed as a post-deadline fallback controller.**
- **Policies:** B1 bulk, B2 fixed batch, B3 fixed rate, B4 load-aware and **unchanged locked P1**. All use equal four-worker concurrency. Data are NOT a training set for algorithm tuning.

## Exact measurement meaning

`ack_gap_ms` is the elapsed time from the last successful classical `PONG` to the first successful hybrid `PONG`. It is **not** continuous-service availability, WAN throughput or a proof of zero downtime. `excess_gap_ms` subtracts that session's mean pre-cutover inter-response cadence; it's a descriptive surrogate, not a guarantee. `no_verified_session_ms` is the time between the closing of classical TLS and hybrid application preflight completion for BMB (zero by design for successful MBB) and is not the primary outcome. `batch_wall_ms_including_harness` includes endpoint start/stop, control and application overhead.

## Reproduce

```
python3 exp09a.py --trials 30 --policies B1,B2,B3,B4,P1 --scenario pilot
python3 analyze_exp09a.py --prefix EXP09A_pilot_cap4_30blocks
python3 exp09a.py --trials 500 --policies B4,P1 --scenario core
python3 analyze_exp09a.py --prefix EXP09A_core_cap4_500blocks
python3 negative_test_recovery.py
```

Requires Linux, gcc, OpenSSL 3.5+ with native `X25519MLKEM768`, Python3 with numpy/matplotlib for analysis, and available localhost ports/IPs. **No root/admin, Docker, ONOS or OVS required for this seven-process prototype.** The `make_bin` function compiles the bundled C source.

## Limitations and research integrity

The environment has NO actual ONOS/OpenFlow and no two Open vSwitch instances, network namespaces, 1Gbps commodity hardware, controlled 10%–90% link loads, network faults, measured controller CPU, SLA-ground-truth deadlines, or field deployment. These are **single-host loopback TLS process timings**, not physical H1.0 SDN performance. Comparing algorithms here does not establish P1 superiority. There is no claim of a complete post-quantum signature scheme: authentication is classical ECDSA, and only KEM is hybrid-PQC. Tests must be replicated on a privileged real OVS testbed and a dedicated physical H1.0 lab before hardware superiority claims.

The independent resampling unit is the *matched trial block*, not individual service observations. Statistical results use 95% paired bootstrap confidence intervals on run-level aggregates. Source data, source code, environment, measured outcomes and checksum inventory are supplied in the package.
