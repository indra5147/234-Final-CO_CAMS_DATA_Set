#!/usr/bin/env python3
"""Read real endpoint logs, compute paired trial-level uncertainty, and plot descriptive results.
Service observations are clustered within trials; bootstrap resamples matched trial blocks.
"""
import argparse,csv,statistics,json,hashlib,collections
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
D=Path(__file__).resolve().parent
POLICIES=['B1','B2','B3','B4','P1']

def get_rows(p):
 with p.open(newline='') as f:return list(csv.DictReader(f))
def pct(xs,p):return float(np.percentile(xs,p))
def boot_delta(a,b,seed=9901,n_boot=3000):
 # mean of paired differences across independent trial blocks (not per service)
 ds=np.asarray([float(x)-float(y) for x,y in zip(a,b)],dtype=float)
 rng=np.random.default_rng(seed)
 means=np.empty(n_boot)
 for i in range(n_boot):means[i]=np.mean(rng.choice(ds,len(ds),replace=True))
 return {'n':len(ds),'mean_diff_ms':float(ds.mean()),'median_diff_ms':float(np.median(ds)),
         'ci_low_ms':pct(means,2.5),'ci_high_ms':pct(means,97.5),
         'fraction_first_lower':float((ds<0).mean())}

def analyze(prefix):
 res=D/'results'; plots=D/'plots';plots.mkdir(exist_ok=True)
 runs=get_rows(res/(prefix+'_policy_runs.csv'))
 svcs=get_rows(res/(prefix+'_service_events.csv'))
 expected_trials=len({int(x['trial']) for x in runs})
 combos={(r['policy'],r['mode']) for r in runs}
 assert len(runs)==expected_trials*len(combos)
 assert len(svcs)==len(runs)*12
 assert all(int(q['classical_verified'])==1 and int(q['hybrid_verified'])==1 and int(q['new_preflight_ok'])==1 for q in svcs)
 assert all(int(q['unsafe_downgrade'])==0 for q in svcs)
 assert all(int(q['hybrid_ready_before_old_close'])==1 for q in svcs if q['mode']=='mbb')
 assert all(int(q['offline_attempts'])==0 for q in svcs if q['mode']=='mbb')
 assert all(float(q['no_verified_session_ms'])==0.0 for q in svcs if q['mode']=='mbb')
 ix={(int(r['trial']),r['policy'],r['mode']):r for r in runs}
 policies=[p for p in POLICIES if (p,'bmb') in combos]
 def val(t,p,m,k):return float(ix[(t,p,m)][k])
 ts=sorted(set(int(r['trial']) for r in runs))
 rows=[];comparisons=[]
 for policy in policies:
  for mode in ('bmb','mbb'):
   a=[ix[(t,policy,mode)] for t in ts]
   rows.append({'policy':policy,'mode':mode,'n_trials':len(a),
     'mean_run_p95_ack_gap_ms':statistics.mean(float(x['p95_ack_gap_ms']) for x in a),
     'mean_run_p95_excess_gap_ms':statistics.mean(float(x['p95_excess_gap_ms']) for x in a),
     'mean_run_batch_wall_ms_including_harness':statistics.mean(float(x['batch_wall_ms_including_harness']) for x in a),
     'mean_run_offline_attempts':statistics.mean(int(x['offline_attempts']) for x in a),
     'total_offline_attempts':sum(int(x['offline_attempts']) for x in a),
     'total_failed_attempts':sum(int(x['failed_attempts']) for x in a),
     'total_verified_cutovers':sum(int(x['hybrid_handshakes_verified']) for x in a)})
  for metric in ['p95_ack_gap_ms','p95_excess_gap_ms','batch_wall_ms_including_harness','offline_attempts']:
   x=[val(t,policy,'mbb',metric) for t in ts]
   y=[val(t,policy,'bmb',metric) for t in ts]
   c=boot_delta(x,y,seed=9109+len(comparisons));c.update({'comparison':f'{policy}: MBB minus BMB','metric':metric});comparisons.append(c)
 if {'B4','P1'}.issubset(set(policies)):
  for mode in ('bmb','mbb'):
   for metric in ['p95_ack_gap_ms','p95_excess_gap_ms','batch_wall_ms_including_harness']:
    x=[val(t,'P1',mode,metric) for t in ts]
    y=[val(t,'B4',mode,metric) for t in ts]
    c=boot_delta(x,y,seed=6119+len(comparisons));c.update({'comparison':f'{mode.upper()}: P1 minus B4','metric':metric});comparisons.append(c)
 def wcsv(name,rws):
  with (res/name).open('w',newline='') as f:
   w=csv.DictWriter(f,fieldnames=list(rws[0]));w.writeheader();w.writerows(rws)
 wcsv(prefix+'_descriptive_statistics.csv',rows)
 wcsv(prefix+'_paired_bootstrap_CI.csv',comparisons)
 # Compare mechanisms in individual policies with readable plots
 fig,ax=plt.subplots(figsize=(10.3,5.2))
 x=np.arange(len(policies));w=.36
 aa=[next(z for z in rows if z['policy']==p and z['mode']=='bmb')['mean_run_p95_ack_gap_ms'] for p in policies]
 bb=[next(z for z in rows if z['policy']==p and z['mode']=='mbb')['mean_run_p95_ack_gap_ms'] for p in policies]
 ax.bar(x-w/2,aa,w,label='Break-before-make')
 ax.bar(x+w/2,bb,w,label='Make-before-break')
 ax.set_xticks(x,policies);ax.set_ylabel('Mean run-level p95 inter-response gap (ms)')
 ax.set_title('EXP-09A: measured TLS application response gaps')
 ax.legend();fig.tight_layout();fig.savefig(plots/(prefix+'_response_gap.png'),dpi=900);plt.close(fig)
 fig,ax=plt.subplots(figsize=(10.3,5.2))
 aa=[next(z for z in rows if z['policy']==p and z['mode']=='bmb')['mean_run_batch_wall_ms_including_harness'] for p in policies]
 bb=[next(z for z in rows if z['policy']==p and z['mode']=='mbb')['mean_run_batch_wall_ms_including_harness'] for p in policies]
 ax.bar(x-w/2,aa,w,label='Break-before-make');ax.bar(x+w/2,bb,w,label='Make-before-break')
 ax.set_xticks(x,policies);ax.set_ylabel('Mean complete run wall time incl. test harness (ms)')
 ax.set_title('EXP-09A: endpoint lifecycle and harness wall time')
 ax.legend();fig.tight_layout();fig.savefig(plots/(prefix+'_run_wall.png'),dpi=900);plt.close(fig)
 report=[f'# EXP-09A — Executed Continuous-Service TLS Migration ({prefix})','',
 f'**Sample:** {len(runs):,} completed policy executions, {len(svcs):,} individually verified live TLS cutovers in {expected_trials} matched trial blocks.','',
 '## Mechanism',
 'Both schemes perform OpenSSL TLS1.3 X25519 to X25519MLKEM768 migration through two TCP forwarding proxies. ECDSA P-256 certificates are validated and no session tickets are used. BMB closes the active classical TLS session before establishing and verifying the new session. MBB establishes, certificate/group-verifies, sends a preflight PING/PONG on the new session while the classical session continues serving requests, then swaps connections under a mutex after the old in-flight request finishes. Old session closes only after successful new-session verification. All strategies use equal four-job concurrency.',
 '', '## Raw outcome semantics',
 '- `ack_gap_ms`: time from last successful response on classical TLS to first successful response on hybrid TLS.','- `baseline_gap_ms`: mean pre-migration inter-response cadence.','- `excess_gap_ms`: max(0, ack_gap_ms − baseline_gap_ms).','- `no_verified_session_ms`: measurement between old close and hybrid readiness for BMB; MBB is zero by construction on successful cutovers. It is **not** actual service downtime.','- `batch_wall_ms_including_harness`: includes startup, requests, shutdown, scheduling, and control agent overhead; is not pure migration makespan.','',
 '## Results (run-level means)',
 '|Policy|Mode|Runs|Mean p95 response gap (ms)|Mean p95 excess gap (ms)|Mean run wall (ms)|Offline attempts|Verified cutovers|','|---|---|---:|---:|---:|---:|---:|---:|']
 for z in rows:report.append(f"|{z['policy']}|{z['mode'].upper()}|{z['n_trials']}|{z['mean_run_p95_ack_gap_ms']:.3f}|{z['mean_run_p95_excess_gap_ms']:.3f}|{z['mean_run_batch_wall_ms_including_harness']:.2f}|{z['total_offline_attempts']}|{z['total_verified_cutovers']}|")
 report+=['','## Paired trial-block comparisons (95% bootstrap CI)',
 '|Comparison|Metric|Mean Δ (ms / count)|95% CI|','|---|---|---:|---|']
 for z in comparisons:
  report.append(f"|{z['comparison']}|{z['metric']}|{z['mean_diff_ms']:+.3f}|[{z['ci_low_ms']:+.3f}, {z['ci_high_ms']:+.3f}]|")
 report+=['','## Scientific qualifications','1. These are real negotiated TLS/application response timings **on one host** with loopback TCP proxies, **not** ONOS/OpenFlow, kernel-isolated virtual machines, WAN latency, switch congestion or seven physical PCs.','2. ACK gaps are a request-continuity proxy rather than full-service network availability; MBB overhead and overlapping session resources must be examined on a real network.','3. The synthetic fixed priority/load/deadline configuration is used only to keep workload matching; no real traffic regimes, CPU overhead, or SDN controller measurements were gathered.','4. Certificate authentication is classical ECDSA P-256; X25519MLKEM768 provides hybrid key establishment only.','5. The claim under test is a **migration-mechanism benefit**, not P1 scheduling superiority. The preserved original P1 algorithm is unchanged.','6. TLS preparation and response timing are nonindependent at service level within runs; bootstrap resamples matched blocks.','7. This report does not establish security against an active adversary, nor zero downtime, nor safe rollback after deadline.','',
 '## Reproduction','```bash','cc -O2 -std=c11 -pthread src/tls_app.c -o bin/tls_app -lssl -lcrypto',f'python3 exp09a.py --trials {expected_trials} --policies {",".join(policies)}',f'python3 analyze_exp09a.py --prefix {prefix}','```','',
 'All outputs are measured or computed from files in `results/`. This is an exploratory software prototype, not a replacement for locked H1.0 physical validation.']
 (res/(prefix+'_REPORT.md')).write_text('\n'.join(report)+'\n')
 # fingerprint input CSVs
 sha={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(res.glob(prefix+'*csv'))}
 (res/(prefix+'_SHA256.json')).write_text(json.dumps(sha,indent=2))
 print(json.dumps({'blocks':expected_trials,'runs':len(runs),'cutovers':len(svcs),'summary':rows,'key_comparisons':[c for c in comparisons if c['metric']=='p95_ack_gap_ms']},indent=2))
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--prefix',required=True);args=a.parse_args();analyze(args.prefix)
