#!/usr/bin/env python3
"""Package only completed auditable experiment outputs. Omit local private key."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import json,hashlib
D=Path(__file__).resolve().parent
P=Path('/mnt/data/EXP09A_Live_TLS_Make_Before_Break_Executed.zip')
files=[]
for f in sorted(D.rglob('*')):
 if not f.is_file() or '__pycache__' in f.parts or f.name in ('server.key','SHA256_FILE_MANIFEST.json'):continue
 rel=f.relative_to(D)
 if rel.parts[0]=='results' and not (f.name.startswith('EXP09A_pilot_') or f.name.startswith('EXP09A_core_') or f.name in ('negative_test_unavailable_hybrid.json','group_mismatch_security_tests.json','PILOT_ANALYSIS.log','CORE_ANALYSIS.log','FINAL_INTEGRITY_CHECK.json')):continue
 if rel.parts[0]=='plots' and not (f.name.startswith('EXP09A_pilot_') or f.name.startswith('EXP09A_core_')):continue
 if rel.parts[0]=='logs' and not ('hybrid_client_to_classical_server' in f.name or 'classical_client_to_hybrid_server' in f.name):continue
 files.append(f)
 hashes={str(f.relative_to(D)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files}
 manifest=D/'SHA256_FILE_MANIFEST.json'
 manifest.write_text(json.dumps({'experiment':'EXP09A','file_count':len(files),'sha256':hashes,'key_excluded':'Self-signed temporary private key is intentionally not distributed. The reproduce script regenerates it.'},indent=2))
 files.append(manifest)
 with ZipFile(P,'w',compression=ZIP_DEFLATED,compresslevel=7) as z:
  for f in files:z.write(f,arcname=str(Path('EXP09A_Continuous_TLS_MBB_vs_BMB')/f.relative_to(D)))
 with ZipFile(P) as z:
  err=z.testzip()
  if err:raise RuntimeError('Invalid ZIP entry '+err)
 print(json.dumps({'zip':str(P),'bytes':P.stat().st_size,'nfiles':len(files),'validated_zip':True}))
