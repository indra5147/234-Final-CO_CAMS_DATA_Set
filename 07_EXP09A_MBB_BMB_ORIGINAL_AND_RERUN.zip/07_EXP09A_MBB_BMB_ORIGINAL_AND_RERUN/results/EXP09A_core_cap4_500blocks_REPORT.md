# EXP-09A — Executed Continuous-Service TLS Migration (EXP09A_core_cap4_500blocks)

**Sample:** 2,000 completed policy executions, 24,000 individually verified live TLS cutovers in 500 matched trial blocks.

## Mechanism
Both schemes perform OpenSSL TLS1.3 X25519 to X25519MLKEM768 migration through two TCP forwarding proxies. ECDSA P-256 certificates are validated and no session tickets are used. BMB closes the active classical TLS session before establishing and verifying the new session. MBB establishes, certificate/group-verifies, sends a preflight PING/PONG on the new session while the classical session continues serving requests, then swaps connections under a mutex after the old in-flight request finishes. Old session closes only after successful new-session verification. All strategies use equal four-job concurrency.

## Raw outcome semantics
- `ack_gap_ms`: time from last successful response on classical TLS to first successful response on hybrid TLS.
- `baseline_gap_ms`: mean pre-migration inter-response cadence.
- `excess_gap_ms`: max(0, ack_gap_ms − baseline_gap_ms).
- `no_verified_session_ms`: measurement between old close and hybrid readiness for BMB; MBB is zero by construction on successful cutovers. It is **not** actual service downtime.
- `batch_wall_ms_including_harness`: includes startup, requests, shutdown, scheduling, and control agent overhead; is not pure migration makespan.

## Results (run-level means)
|Policy|Mode|Runs|Mean p95 response gap (ms)|Mean p95 excess gap (ms)|Mean run wall (ms)|Offline attempts|Verified cutovers|
|---|---|---:|---:|---:|---:|---:|---:|
|B4|BMB|500|9.423|6.091|186.63|7668|6000|
|B4|MBB|500|4.309|0.992|184.90|0|6000|
|P1|BMB|500|9.078|5.719|184.83|7638|6000|
|P1|MBB|500|4.410|1.058|186.28|0|6000|

## Paired trial-block comparisons (95% bootstrap CI)
|Comparison|Metric|Mean Δ (ms / count)|95% CI|
|---|---|---:|---|
|B4: MBB minus BMB|p95_ack_gap_ms|-5.114|[-5.877, -4.650]|
|B4: MBB minus BMB|p95_excess_gap_ms|-5.099|[-5.801, -4.643]|
|B4: MBB minus BMB|batch_wall_ms_including_harness|-1.726|[-3.423, -0.142]|
|B4: MBB minus BMB|offline_attempts|-15.336|[-15.634, -15.064]|
|P1: MBB minus BMB|p95_ack_gap_ms|-4.668|[-4.905, -4.439]|
|P1: MBB minus BMB|p95_excess_gap_ms|-4.661|[-4.884, -4.430]|
|P1: MBB minus BMB|batch_wall_ms_including_harness|+1.453|[-0.078, +2.969]|
|P1: MBB minus BMB|offline_attempts|-15.276|[-15.554, -15.004]|
|BMB: P1 minus B4|p95_ack_gap_ms|-0.344|[-1.110, +0.161]|
|BMB: P1 minus B4|p95_excess_gap_ms|-0.372|[-1.146, +0.121]|
|BMB: P1 minus B4|batch_wall_ms_including_harness|-1.795|[-3.598, -0.105]|
|MBB: P1 minus B4|p95_ack_gap_ms|+0.101|[-0.067, +0.266]|
|MBB: P1 minus B4|p95_excess_gap_ms|+0.066|[-0.088, +0.235]|
|MBB: P1 minus B4|batch_wall_ms_including_harness|+1.384|[-0.065, +2.783]|

## Scientific qualifications
1. These are real negotiated TLS/application response timings **on one host** with loopback TCP proxies, **not** ONOS/OpenFlow, kernel-isolated virtual machines, WAN latency, switch congestion or seven physical PCs.
2. ACK gaps are a request-continuity proxy rather than full-service network availability; MBB overhead and overlapping session resources must be examined on a real network.
3. The synthetic fixed priority/load/deadline configuration is used only to keep workload matching; no real traffic regimes, CPU overhead, or SDN controller measurements were gathered.
4. Certificate authentication is classical ECDSA P-256; X25519MLKEM768 provides hybrid key establishment only.
5. The claim under test is a **migration-mechanism benefit**, not P1 scheduling superiority. The preserved original P1 algorithm is unchanged.
6. TLS preparation and response timing are nonindependent at service level within runs; bootstrap resamples matched blocks.
7. This report does not establish security against an active adversary, nor zero downtime, nor safe rollback after deadline.

## Reproduction
```bash
cc -O2 -std=c11 -pthread src/tls_app.c -o bin/tls_app -lssl -lcrypto
python3 exp09a.py --trials 500 --policies B4,P1
python3 analyze_exp09a.py --prefix EXP09A_core_cap4_500blocks
```

All outputs are measured or computed from files in `results/`. This is an exploratory software prototype, not a replacement for locked H1.0 physical validation.
