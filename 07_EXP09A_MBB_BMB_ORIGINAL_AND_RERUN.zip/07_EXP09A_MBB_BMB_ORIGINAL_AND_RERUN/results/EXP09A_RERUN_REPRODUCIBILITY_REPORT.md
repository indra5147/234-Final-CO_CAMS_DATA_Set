# EXP-09A — Fresh 500-block re-execution versus original 500-block execution

**Real local TLS/application traffic; not an OpenFlow/OVS or physical SDN experiment.**

Both executions contain 500 matched trial blocks, 2,000 policy runs, and 24,000 individually verified TLS migrations (12 services/run).
Original and rerun source files have distinct SHA256 digests, and the original files were preserved.

## Response gap (mean of 500 within-run p95 values)

|Policy|Mode|Original ms|Rerun ms|Rerun − original ms|
|---|---|---:|---:|---:|
|B4|BMB|9.423|8.782|-0.641|
|B4|MBB|4.309|4.240|-0.069|
|P1|BMB|9.078|8.896|-0.183|
|P1|MBB|4.410|4.292|-0.119|

## Mechanism and scheduler contrasts

|Execution|Contrast|Mean difference ms|
|---|---|---:|
|original|B4 MBB minus BMB|-5.114|
|original|P1 MBB minus BMB|-4.668|
|original|BMB P1 minus B4|-0.344|
|original|MBB P1 minus B4|+0.101|
|rerun|B4 MBB minus BMB|-4.542|
|rerun|P1 MBB minus BMB|-4.604|
|rerun|BMB P1 minus B4|+0.114|
|rerun|MBB P1 minus B4|+0.052|

**Interpretation:** A negative MBB-minus-BMB difference favors make-before-break for inter-successful-response gap. A negative P1-minus-B4 difference favors P1 on this measurement only.

## Scope and safeguards

- Both modes perform real authenticated TLS1.3 and a live PING/PONG service; MBB prepares the new session before closing the old one.
- Each execution contains exactly 500 trial blocks per policy/mode, with 12 cutovers per block and 4-worker concurrency.
- All 48,000 original+fresh rerun cutovers passed key-exchange, certificate and application-response checks; no unauthorized downgrade was recorded.
- The measured inter-successful-response gap is *not* proof of zero downtime, network availability or actual SLA compliance.
- There is no ONOS, Open vSwitch, network namespace, packet loss or 1GbE hardware in the current test; do not report it as physical H1.0 validation.
- Classical ECDSA authentication remains; only TLS key-establishment group changes to a hybrid PQC group.
- P1 scheduler V1.0 is frozen; if the algorithm is inferior or statistically indistinguishable from B4, that must be reported.
- Trial blocks, not the 12 correlated service observations, are the resampling unit.

## Reproduction
```bash
python3 exp09a.py --trials 500 --policies B4,P1 --scenario rerun
python3 analyze_exp09a.py --prefix EXP09A_rerun_cap4_500blocks
python3 compare_two_executions.py
```
