# EXP-09A — Executed Continuous-Service TLS Migration (EXP09A_pilot_cap4_30blocks)

**Sample:** 300 completed policy executions, 3,600 individually verified live TLS cutovers in 30 matched trial blocks.

## Mechanism
Both schemes perform OpenSSL TLS1.3 X25519 to X25519MLKEM768 migration through two TCP forwarding proxies. ECDSA P-256 certificates are validated and no session tickets are used. BMB closes the active classical TLS session before establishing and verifying the new session. MBB establishes, certificate/group-verifies, sends a preflight PING/PONG on the new session while the classical session continues serving requests, then swaps connections under a mutex after the old in-flight request finishes. Old session closes only after successful new-session verification. All strategies use equal four-job concurrency.

## Raw outcome semantics
- `ack_gap_ms`: time from last successful response on classical TLS to first successful response on hybrid TLS.
- `baseline_gap_ms`: mean pre-migration inter-response cadence.
- `excess_gap_ms`: max(0, ack_gap_ms − baseline_gap_ms).
- `no_verified_session_ms`: measurement between old close and hybrid readiness for BMB; MBB is zero by construction on successful cutovers. It is **not** actual service downtime.
- `batch_wall_ms_including_harness`: includes startup, requests, shutdown, scheduling, and control agent overhead; is not pure migration makespan.

## Results (run-level means)
|Policy|Mode|Runs|Mean p95 response gap (ms)|Mean p95 excess gap (ms)|Mean run wall (ms)|Offline attempts|Verified cutovers|
|---|---|---:|---:|---:|---:|---:|---:|
|B1|BMB|30|8.653|5.404|181.56|424|360|
|B1|MBB|30|4.252|0.967|182.38|0|360|
|B2|BMB|30|8.264|5.047|228.68|444|360|
|B2|MBB|30|3.585|0.429|236.47|0|360|
|B3|BMB|30|7.739|4.459|267.17|410|360|
|B3|MBB|30|3.508|0.342|263.62|0|360|
|B4|BMB|30|9.484|6.063|185.50|463|360|
|B4|MBB|30|4.470|1.040|186.16|0|360|
|P1|BMB|30|8.699|5.336|183.45|445|360|
|P1|MBB|30|4.152|0.877|180.92|0|360|

## Paired trial-block comparisons (95% bootstrap CI)
|Comparison|Metric|Mean Δ (ms / count)|95% CI|
|---|---|---:|---|
|B1: MBB minus BMB|p95_ack_gap_ms|-4.401|[-5.081, -3.810]|
|B1: MBB minus BMB|p95_excess_gap_ms|-4.437|[-5.107, -3.855]|
|B1: MBB minus BMB|batch_wall_ms_including_harness|+0.825|[-3.586, +5.015]|
|B1: MBB minus BMB|offline_attempts|-14.133|[-14.833, -13.467]|
|B2: MBB minus BMB|p95_ack_gap_ms|-4.679|[-5.074, -4.322]|
|B2: MBB minus BMB|p95_excess_gap_ms|-4.618|[-4.987, -4.269]|
|B2: MBB minus BMB|batch_wall_ms_including_harness|+7.796|[-1.622, +20.480]|
|B2: MBB minus BMB|offline_attempts|-14.800|[-15.667, -14.000]|
|B3: MBB minus BMB|p95_ack_gap_ms|-4.231|[-4.858, -3.668]|
|B3: MBB minus BMB|p95_excess_gap_ms|-4.117|[-4.709, -3.550]|
|B3: MBB minus BMB|batch_wall_ms_including_harness|-3.552|[-10.589, +3.514]|
|B3: MBB minus BMB|offline_attempts|-13.667|[-14.633, -12.800]|
|B4: MBB minus BMB|p95_ack_gap_ms|-5.014|[-5.957, -4.191]|
|B4: MBB minus BMB|p95_excess_gap_ms|-5.023|[-5.929, -4.296]|
|B4: MBB minus BMB|batch_wall_ms_including_harness|+0.655|[-8.019, +8.362]|
|B4: MBB minus BMB|offline_attempts|-15.433|[-16.567, -14.467]|
|P1: MBB minus BMB|p95_ack_gap_ms|-4.547|[-4.894, -4.218]|
|P1: MBB minus BMB|p95_excess_gap_ms|-4.459|[-4.832, -4.108]|
|P1: MBB minus BMB|batch_wall_ms_including_harness|-2.531|[-6.267, +1.165]|
|P1: MBB minus BMB|offline_attempts|-14.833|[-15.567, -14.167]|
|BMB: P1 minus B4|p95_ack_gap_ms|-0.785|[-1.835, +0.036]|
|BMB: P1 minus B4|p95_excess_gap_ms|-0.727|[-1.694, +0.008]|
|BMB: P1 minus B4|batch_wall_ms_including_harness|-2.058|[-10.968, +5.065]|
|MBB: P1 minus B4|p95_ack_gap_ms|-0.318|[-0.809, +0.093]|
|MBB: P1 minus B4|p95_excess_gap_ms|-0.163|[-0.584, +0.174]|
|MBB: P1 minus B4|batch_wall_ms_including_harness|-5.243|[-9.971, -0.634]|

## Scientific qualifications
1. These are real negotiated TLS/application response timings **on one host** with loopback TCP proxies, **not** ONOS/OpenFlow, kernel-isolated virtual machines, WAN latency, switch congestion or seven physical PCs.
2. ACK gaps are a request-continuity proxy rather than full-service network availability; MBB overhead and overlapping session resources must be examined on a real network.
3. The synthetic fixed priority/load/deadline configuration is used only to keep workload matching; no real traffic regimes, CPU overhead, or SDN controller measurements were gathered.
4. Certificate authentication is classical ECDSA P-256; X25519MLKEM768 provides hybrid key establishment only.
5. The claim under test is a **migration-mechanism benefit**, not P1 scheduling superiority. The preserved original P1 algorithm is unchanged.
6. TLS preparation and response timing are nonindependent at service level within runs; bootstrap resamples matched blocks.
7. This report does not establish security against an active adversary, nor zero downtime, nor safe rollback after deadline.

## Reproduction
```bash
cc -O2 -std=c11 -pthread src/tls_app.c -o bin/tls_app -lssl -lcrypto
python3 exp09a.py --trials 30 --policies B1,B2,B3,B4,P1
python3 analyze_exp09a.py --prefix EXP09A_pilot_cap4_30blocks
```

All outputs are measured or computed from files in `results/`. This is an exploratory software prototype, not a replacement for locked H1.0 physical validation.
