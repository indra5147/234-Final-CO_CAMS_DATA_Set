#!/usr/bin/env python3
"""Package auditable source and two full original/rerun datasets; exclude private key."""
import hashlib,json
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
D=Path(__file__).resolve().parent
OUTPUT=Path('/mnt/data/EXP09A_Fresh_500_Block_Rerun_Results.zip')
root=Path('EXP09A_Continuous_TLS_MBB_vs_BMB')
files=[]
for f in sorted(D.rglob('*')):
 if not f.is_file():continue
 rel=f.relative_to(D)
 if any(x in rel.parts for x in ('__pycache__','.git')):continue
 if f.name=='server.key' or f.suffix in ('.pyc',):continue
 if rel.parts[0]=='bin':continue
 if rel.parts[0]=='logs':
  if 'hybrid_client_to_classical_server' not in f.name and 'classical_client_to_hybrid_server' not in f.name:continue
 if rel.parts[0]=='results':
  patterns=('EXP09A_core_','EXP09A_rerun_','EXP09A_500block_','EXP09A_REEXECUTION_')
  others=('negative_test_unavailable_hybrid.json','group_mismatch_security_tests.json')
  if not (f.name.startswith(patterns) or f.name in others):continue
 if rel.parts[0]=='plots':
  if not (f.name.startswith('EXP09A_core_') or f.name.startswith('EXP09A_rerun_') or f.name=='EXP09A_original_vs_rerun.png'):continue
 if f.name=='SHA256_RERUN_PACKAGE.json':continue
 files.append(f)
manifest={str(f.relative_to(D)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files}
mp=D/'SHA256_RERUN_PACKAGE.json';mp.write_text(json.dumps({'files':manifest,'note':'server.key intentionally omitted; reproduction regenerates a temporary cert'},indent=2))
files.append(mp)
with ZipFile(OUTPUT,'w',compression=ZIP_DEFLATED,compresslevel=6) as zipf:
 for f in files:zipf.write(f,arcname=str(root/f.relative_to(D)))
with ZipFile(OUTPUT) as zipf:
 assert zipf.testzip() is None
 assert all('server.key' not in x for x in zipf.namelist())
print(json.dumps({'zip':str(OUTPUT),'size_bytes':OUTPUT.stat().st_size,'n_files':len(files),'zip_verified':True}))
