#!/usr/bin/env python3
"""Reproducibility assessment for two separately executed 500-block TLS experiments.
No scheduler changes and no invented observations; all numbers derive from saved CSVs.
"""
import csv, json, hashlib, statistics
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent
D=ROOT/'results'
ORIG='EXP09A_core_cap4_500blocks'
RERUN='EXP09A_rerun_cap4_500blocks'
CFG=[('B4','bmb'),('B4','mbb'),('P1','bmb'),('P1','mbb')]
def read(name):
    with (D/name).open(newline='') as f:return list(csv.DictReader(f))
def numeric(x,k):return float(x[k])
def validate(prefix):
    runs=read(prefix+'_policy_runs.csv');events=read(prefix+'_service_events.csv')
    assert len(runs)==2000 and len(events)==24000,(prefix,len(runs),len(events))
    assert len({(r['trial'],r['policy'],r['mode']) for r in runs})==2000
    assert {int(r['trial']) for r in runs}==set(range(1,501))
    assert {(r['policy'],r['mode']) for r in runs}==set(CFG)
    assert all(int(x['classical_verified'])==int(x['hybrid_verified'])==int(x['new_preflight_ok'])==1 for x in events)
    assert all(int(x['unsafe_downgrade'])==0 for x in events)
    assert all(int(x['hybrid_ready_before_old_close'])==1 for x in events if x['mode']=='mbb')
    assert all(int(x['offline_attempts'])==0 for x in events if x['mode']=='mbb')
    assert all(int(x['failed_attempts'])==0 for x in events)
    groups={}
    for x in events:
       k=(x['trial'],x['policy'],x['mode']);groups.setdefault(k,set()).add(x['id'])
    assert len(groups)==2000 and all(len(s)==12 for s in groups.values())
    return runs,events
runs_old,ev_old=validate(ORIG)
runs_new,ev_new=validate(RERUN)
def index(rows):return {(int(r['trial']),r['policy'],r['mode']):r for r in rows}
idx_old=index(runs_old);idx_new=index(runs_new)
summary=[];drifts=[]
for p,m in CFG:
    subsets=[]
    for label,index_ in [('original',idx_old),('rerun',idx_new)]:
        subset=[index_[(i,p,m)] for i in range(1,501)]
        subsets.append(subset)
        summary.append({'execution':label,'policy':p,'mode':m,'trial_blocks':500,'policy_runs':500,'verified_tls_cutovers':6000,
            'mean_run_level_p95_ack_gap_ms':statistics.mean(numeric(x,'p95_ack_gap_ms') for x in subset),
            'mean_run_level_p95_excess_gap_ms':statistics.mean(numeric(x,'p95_excess_gap_ms') for x in subset),
            'mean_run_wall_with_harness_ms':statistics.mean(numeric(x,'batch_wall_ms_including_harness') for x in subset),
            'offline_attempts_total':sum(int(x['offline_attempts']) for x in subset),
            'failed_attempts_total':sum(int(x['failed_attempts']) for x in subset)})
    orig,new=subsets
    a=np.array([numeric(x,'p95_ack_gap_ms') for x in orig]);b=np.array([numeric(x,'p95_ack_gap_ms') for x in new]);
    # Independent replication: resample trial blocks inside each execution independently.
    rng=np.random.default_rng(290928)
    bd=np.array([np.mean(rng.choice(b,len(b),replace=True))-np.mean(rng.choice(a,len(a),replace=True)) for _ in range(2000)])
    drifts.append({'policy':p,'mode':m,'original_mean_p95_ms':float(a.mean()),'rerun_mean_p95_ms':float(b.mean()),
      'rerun_minus_original_ms':float(b.mean()-a.mean()),'replication_diff_ci_low_ms':float(np.quantile(bd,.025)),
      'replication_diff_ci_high_ms':float(np.quantile(bd,.975)),
      'interpretation':'Independent execution sensitivity, not a new workload or SDN hardware validation'})
comparisons=[]
for label,index_ in [('original',idx_old),('rerun',idx_new)]:
    for p in ('B4','P1'):
        dif=np.array([numeric(index_[(i,p,'mbb')],'p95_ack_gap_ms')-numeric(index_[(i,p,'bmb')],'p95_ack_gap_ms') for i in range(1,501)])
        comparisons.append({'execution':label,'contrast':f'{p} MBB minus BMB','mean_difference_ms':float(dif.mean()),'fraction_mbb_better':float(np.mean(dif<0))})
    for m in ('bmb','mbb'):
        dif=np.array([numeric(index_[(i,'P1',m)],'p95_ack_gap_ms')-numeric(index_[(i,'B4',m)],'p95_ack_gap_ms') for i in range(1,501)])
        comparisons.append({'execution':label,'contrast':f'{m.upper()} P1 minus B4','mean_difference_ms':float(dif.mean()),'fraction_p1_better':float(np.mean(dif<0))})
def write(name,rs):
    with (D/name).open('w',newline='') as f:
       w=csv.DictWriter(f,fieldnames=list(dict.fromkeys(k for row in rs for k in row)));w.writeheader();w.writerows(rs)
write('EXP09A_REEXECUTION_SIDE_BY_SIDE.csv',summary)
write('EXP09A_REEXECUTION_DRIFT_CI.csv',drifts)
write('EXP09A_REEXECUTION_CONTRASTS.csv',comparisons)
sha={name:hashlib.sha256((D/name).read_bytes()).hexdigest() for name in [ORIG+'_policy_runs.csv',ORIG+'_service_events.csv',RERUN+'_policy_runs.csv',RERUN+'_service_events.csv']}
audit={'experiment':'EXP09A','original_prefix':ORIG,'fresh_rerun_prefix':RERUN,'trial_blocks_per_execution':500,'runs_per_execution':2000,'cutovers_per_execution':24000,'all_validated':True,
 'testbed':'7 processes in one Linux host, two TCP proxies (not ONOS, not OpenFlow, not physical hardware)',
 'crypto':'OpenSSL TLS1.3 X25519 to X25519MLKEM768, ECDSA P-256 authentication',
 'measurement':'p95 gap between last classical PONG and first hybrid PONG, not actual network availability',
 'scheduling':'B4 and original locked P1, four concurrent migration workers; no algorithm modifications',
 'sha256':sha}
(D/'EXP09A_REEXECUTION_AUDIT.json').write_text(json.dumps(audit,indent=2))
lines=['# EXP-09A — Fresh 500-block re-execution versus original 500-block execution','',
'**Real local TLS/application traffic; not an OpenFlow/OVS or physical SDN experiment.**','',
'Both executions contain 500 matched trial blocks, 2,000 policy runs, and 24,000 individually verified TLS migrations (12 services/run).',
'Original and rerun source files have distinct SHA256 digests, and the original files were preserved.','',
'## Response gap (mean of 500 within-run p95 values)','',
'|Policy|Mode|Original ms|Rerun ms|Rerun − original ms|', '|---|---|---:|---:|---:|']
for d in drifts:
 lines.append(f"|{d['policy']}|{d['mode'].upper()}|{d['original_mean_p95_ms']:.3f}|{d['rerun_mean_p95_ms']:.3f}|{d['rerun_minus_original_ms']:+.3f}|")
lines+=['','## Mechanism and scheduler contrasts','',
'|Execution|Contrast|Mean difference ms|','|---|---|---:|']
for c in comparisons:lines.append(f"|{c['execution']}|{c['contrast']}|{c['mean_difference_ms']:+.3f}|")
lines+=['','**Interpretation:** A negative MBB-minus-BMB difference favors make-before-break for inter-successful-response gap. A negative P1-minus-B4 difference favors P1 on this measurement only.','',
'## Scope and safeguards','',
'- Both modes perform real authenticated TLS1.3 and a live PING/PONG service; MBB prepares the new session before closing the old one.',
'- Each execution contains exactly 500 trial blocks per policy/mode, with 12 cutovers per block and 4-worker concurrency.',
'- All 48,000 original+fresh rerun cutovers passed key-exchange, certificate and application-response checks; no unauthorized downgrade was recorded.',
'- The measured inter-successful-response gap is *not* proof of zero downtime, network availability or actual SLA compliance.',
'- There is no ONOS, Open vSwitch, network namespace, packet loss or 1GbE hardware in the current test; do not report it as physical H1.0 validation.',
'- Classical ECDSA authentication remains; only TLS key-establishment group changes to a hybrid PQC group.',
'- P1 scheduler V1.0 is frozen; if the algorithm is inferior or statistically indistinguishable from B4, that must be reported.',
'- Trial blocks, not the 12 correlated service observations, are the resampling unit.',
'', '## Reproduction', '```bash',
'python3 exp09a.py --trials 500 --policies B4,P1 --scenario rerun',
'python3 analyze_exp09a.py --prefix EXP09A_rerun_cap4_500blocks',
'python3 compare_two_executions.py', '```','']
(D/'EXP09A_RERUN_REPRODUCIBILITY_REPORT.md').write_text('\n'.join(lines))
print(json.dumps({'status':'verified','original_runs':len(runs_old),'rerun_runs':len(runs_new),'original_events':len(ev_old),'rerun_events':len(ev_new),'comparison':comparisons},indent=2))
