import csv
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
D=Path(__file__).resolve().parent
with (D/'results/EXP09A_REEXECUTION_SIDE_BY_SIDE.csv').open() as f:data=list(csv.DictReader(f))
labels=['B4 BMB','B4 MBB','P1 BMB','P1 MBB']
orig=[float(next(x['mean_run_level_p95_ack_gap_ms'] for x in data if x['execution']=='original' and x['policy']==p and x['mode']==m)) for p,m in [('B4','bmb'),('B4','mbb'),('P1','bmb'),('P1','mbb')]]
new=[float(next(x['mean_run_level_p95_ack_gap_ms'] for x in data if x['execution']=='rerun' and x['policy']==p and x['mode']==m)) for p,m in [('B4','bmb'),('B4','mbb'),('P1','bmb'),('P1','mbb')]]
y=np.arange(4);fig,ax=plt.subplots(figsize=(9,4.3));ax.barh(y-.19,orig,height=.36,label='Original 500-block execution');ax.barh(y+.19,new,height=.36,label='Fresh 500-block rerun');ax.set_yticks(y,labels);ax.invert_yaxis();ax.set_xlabel('Mean of 500 run-level p95 response gaps (ms)');ax.legend(loc='lower right');ax.grid(axis='x',alpha=.25)
fig.tight_layout();out=D/'plots/EXP09A_original_vs_rerun.png';fig.savefig(out,dpi=300);plt.close(fig);print(out)
