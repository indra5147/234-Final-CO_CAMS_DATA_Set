#!/usr/bin/env python3
"""Run only while EXP09A live server/proxy roles are running."""
import subprocess,json
from pathlib import Path
D=Path(__file__).resolve().parent
cases=[('hybrid_client_to_classical_server',31101,'X25519MLKEM768'),('classical_client_to_hybrid_server',32101,'X25519')]
out=[]
for name,port,group in cases:
 cmd=['openssl','s_client','-connect',f'127.0.0.11:{port}','-tls1_3','-groups',group,'-CAfile',str(D/'certs/server.crt'),'-verify_hostname','sdn-pqc.local','-verify_return_error','-quiet']
 p=subprocess.run(cmd,input=b'PING\n',capture_output=True,timeout=4)
 entry={'test':name,'port':port,'attempted_group':group,'exit_code':p.returncode,'expected_rejection':True,'rejected':p.returncode!=0 and b'handshake failure' in p.stderr,'stderr_excerpt':p.stderr.decode('utf-8','replace')[:450]}
 if not entry['rejected']:raise RuntimeError('unexpected TLS acceptance/unexpected error '+json.dumps(entry))
 out.append(entry)
(D/'results/group_mismatch_security_tests.json').write_text(json.dumps(out,indent=2))
print('SECURITY TESTS PASSED',[(x['test'],x['exit_code']) for x in out])
