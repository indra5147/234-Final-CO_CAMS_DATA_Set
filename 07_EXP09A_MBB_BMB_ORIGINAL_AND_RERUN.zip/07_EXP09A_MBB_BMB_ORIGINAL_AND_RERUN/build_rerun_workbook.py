#!/usr/bin/env python3
"""Summary Excel for two already measured 500-block live-TLS executions. Uses artifact_tool."""
import csv,json
from pathlib import Path
from artifact_tool import Workbook,SpreadsheetFile
D=Path(__file__).resolve().parent;R=D/'results'
DARK='#17324F'; TEAL='#0A7180'; PALE='#EEF5F8';WHITE='#FFFFFF'
def read(filename):
 with (R/filename).open(newline='') as f:return list(csv.DictReader(f))
def cast(x):
 try:return float(x) if '.' in x or 'e' in x.lower() else int(x)
 except (ValueError,AttributeError):return x

def add(w,name,title,rows,max_rows=None,widths=None):
 s=w.worksheets.add(name)
 if not rows:return s
 cols=list(rows[0]);n=len(cols)
 s.get_range_by_indexes(0,0,1,n).merge();s.get_cell(0,0).values=[[title]]
 s.get_range_by_indexes(0,0,1,n).format={'fill':DARK,'font':{'color':WHITE,'bold':True,'size':15},'row_height':35}
 s.get_range_by_indexes(2,0,1,n).values=[cols]
 s.get_range_by_indexes(2,0,1,n).format={'fill':TEAL,'font':{'color':WHITE,'bold':True},'row_height':33,'wrap_text':True}
 rr=rows if max_rows is None else rows[:max_rows]
 s.get_range_by_indexes(3,0,len(rr),n).values=[[cast(r.get(c,'')) for c in cols] for r in rr]
 s.freeze_panes.freeze_rows(3)
 for i,c in enumerate(cols):
  s.get_range_by_indexes(0,i,4,1).format.column_width=(widths or {}).get(c,min(32,max(15,len(c)+3)))
 return s

def run():
 summary=read('EXP09A_REEXECUTION_SIDE_BY_SIDE.csv')
 drift=read('EXP09A_REEXECUTION_DRIFT_CI.csv')
 contrasts=read('EXP09A_REEXECUTION_CONTRASTS.csv')
 new_runs=read('EXP09A_rerun_cap4_500blocks_policy_runs.csv')
 orig_runs=read('EXP09A_core_cap4_500blocks_policy_runs.csv')
 assert len(new_runs)==len(orig_runs)==2000
 wb=Workbook.create();over=wb.worksheets.add('Read First')
 over.get_range('A1:F1').merge();over.get_range('A1').values=[['EXP-09A  |  Fresh 500-Block Re-Execution']]
 over.get_range('A1:F1').format={'fill':DARK,'font':{'color':WHITE,'bold':True,'size':18},'row_height':42}
 notes=[['Original execution','500 blocks · 2,000 policy runs · 24,000 verified TLS transitions'],
 ['Independent rerun','500 blocks · 2,000 policy runs · 24,000 verified TLS transitions'],
 ['Topology','7 local Linux processes · SW1 / SW2 are TCP forwarding proxies, not OpenFlow'],
 ['Compared policies','B4 load-aware greedy vs unchanged locked P1'],
 ['Compared mechanisms','BMB = break-before-make; MBB = make-before-break'],
 ['Equivalent resources','4 migration workers; 12 concurrent active TLS services/run'],
 ['Measured endpoint','Run-level p95 gap: last classical PONG to first hybrid PONG, in ms'],
 ['Security boundary','Hybrid X25519MLKEM768 key exchange; classical P-256 ECDSA authentication'],
 ['Inference','Paired trial blocks *within* each execution; independent bootstrap for execution drift'],
 ['Scientific limits','Single-host application-level proxy. No ONOS, OVS, isolated VMs, WAN load or physical H1.0']]
 over.get_range('A3:B12').values=notes
 over.get_range('A3:A12').format={'fill':PALE,'font':{'bold':True},'column_width':29,'row_height':37,'wrap_text':True}
 over.get_range('B3:B12').format={'column_width':85,'row_height':37,'wrap_text':True}
 over.get_range('A14:F14').merge();over.get_range('A14').values=[['Interpretation: negative MBB−BMB gap favors MBB; negative P1−B4 gap favors P1. Neither equals hardware superiority.']]
 over.get_range('A14:F14').format={'fill':PALE,'font':{'bold':True,'color':DARK},'row_height':33}
 add(wb,'Execution Summary','Original vs Rerun · Measured TLS Response-Gap Statistics',summary)
 add(wb,'Replication Drift','Rerun Minus Original · Independent Bootstrap 95% CI',drift,
     widths={'interpretation':68,'replication_diff_ci_low_ms':30,'replication_diff_ci_high_ms':30})
 add(wb,'Mechanism Contrasts','Within-Execution Comparisons (Each has 500 matched trial blocks)',contrasts,
     widths={'contrast':32,'fraction_mbb_better':25,'fraction_p1_better':25})
 add(wb,'Rerun 2000 Runs','Rerun · Complete Raw Policy-Level Measurements',new_runs)
 add(wb,'Original 2000 Runs','Original · Complete Raw Policy-Level Measurements',orig_runs)
 audit=json.loads((R/'EXP09A_REEXECUTION_AUDIT.json').read_text())
 source=[{'source_file':k,'sha256':v} for k,v in audit['sha256'].items()]
 add(wb,'SHA256 Provenance','Original and Fresh Rerun Raw CSV SHA256 Digests',source,widths={'source_file':64,'sha256':76})
 p=D/'EXP09A_Fresh_Rerun_500_Comparison.xlsx'
 SpreadsheetFile.export_xlsx(wb).save(str(p))
 assert p.stat().st_size>10000
 print(json.dumps({'file':str(p),'bytes':p.stat().st_size,'sheets':7,'original_policy_rows':len(orig_runs),'new_policy_rows':len(new_runs)}))
if __name__=='__main__':run()
