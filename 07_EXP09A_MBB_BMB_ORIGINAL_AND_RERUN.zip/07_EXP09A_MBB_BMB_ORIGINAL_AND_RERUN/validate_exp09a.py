#!/usr/bin/env python3
"""Assert exact result counts, group verification evidence and per-session completeness."""
import csv,sys,json,collections,hashlib
from pathlib import Path
D=Path(__file__).resolve().parent
R=D/'results'

def read(p):
 with p.open(newline='') as f:return list(csv.DictReader(f))

def verify(prefix,n_trials,policies):
 runs=read(R/(prefix+'_policy_runs.csv'));events=read(R/(prefix+'_service_events.csv'))
 expected=n_trials*len(policies)*2
 assert len(runs)==expected,(prefix,len(runs),expected)
 assert len(events)==12*expected,(prefix,len(events),expected*12)
 key=lambda r:(int(r['trial']),r['policy'],r['mode'])
 groups=collections.defaultdict(set)
 for e in events:
  k=key(e);assert k[1] in policies and k[2] in ('mbb','bmb')
  assert e['id'] not in groups[k],(k,e['id'])
  groups[k].add(e['id'])
  assert e['classical_verified']=='1' and e['hybrid_verified']=='1' and e['new_preflight_ok']=='1'
  assert e['unsafe_downgrade']=='0' and float(e['ack_gap_ms'])>=0
  assert int(e['old_responses'])>=1 and int(e['new_responses'])>=1
  if e['mode']=='mbb':
   assert e['hybrid_ready_before_old_close']=='1'
   assert e['offline_attempts']=='0'
 assert set(groups)==set(key(r) for r in runs)
 assert len(groups)==expected
 assert all(len(jobs)==12 for jobs in groups.values())
 return {'prefix':prefix,'trial_blocks':n_trials,'policy_runs':len(runs),'verified_cutovers':len(events),
  'no_downgrade_events':sum(int(x['unsafe_downgrade']) for x in events),
  'sha256_csv':hashlib.sha256((R/(prefix+'_service_events.csv')).read_bytes()).hexdigest()}

def main():
 out=[verify('EXP09A_pilot_cap4_30blocks',30,{'B1','B2','B3','B4','P1'}),
  verify('EXP09A_core_cap4_500blocks',500,{'B4','P1'})]
 out.append({'negative_test':json.loads((R/'negative_test_unavailable_hybrid.json').read_text())[0]['old_preserved_on_failure']==1})
 assert out[-1]['negative_test']
 (R/'FINAL_INTEGRITY_CHECK.json').write_text(json.dumps(out,indent=2))
 print(json.dumps(out,indent=2))
if __name__=='__main__':main()
