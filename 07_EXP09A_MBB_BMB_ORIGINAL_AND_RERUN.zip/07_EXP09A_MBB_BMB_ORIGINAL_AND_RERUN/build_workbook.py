#!/usr/bin/env python3
"""Professional EXP09A workbook; source CSV is authoritative for all measurements."""
import csv,json
from pathlib import Path
from artifact_tool import Workbook,SpreadsheetFile
ROOT=Path(__file__).resolve().parent
R=ROOT/'results'
BLUE='#142D4E'; TEAL='#006F78'; CREAM='#F0F5FA'; GREEN='#E9F7F4'; WHITE='#FFFFFF'
def read(name):
 path=R/name
 with path.open(newline='') as f:return list(csv.DictReader(f)) if path.exists() else []
def cast_cell(v):
 if not isinstance(v,str) or v=='':return v
 try:return float(v) if ('.' in v or 'e' in v.lower()) else int(v)
 except ValueError:return v
def sheet(w,name,title,cols,rows,widths=None,max_rows=None):
 s=w.worksheets.add(name);n=len(cols)
 s.get_range_by_indexes(0,0,1,n).merge()
 s.get_cell(0,0).values=[[title]]
 s.get_range_by_indexes(0,0,1,n).format={'fill':BLUE,'font':{'bold':True,'color':WHITE,'size':15},'row_height':32,'vertical_alignment':'center'}
 s.get_range_by_indexes(2,0,1,n).values=[cols]
 s.get_range_by_indexes(2,0,1,n).format={'fill':TEAL,'font':{'bold':True,'color':WHITE},'row_height':24,'wrap_text':True,'vertical_alignment':'center'}
 use=rows if max_rows is None else rows[:max_rows]
 if use:
  s.get_range_by_indexes(3,0,len(use),n).values=[[cast_cell(r.get(c,'')) for c in cols] for r in use]
  s.get_range_by_indexes(3,0,len(use),n).format.row_height=20
 s.freeze_panes.freeze_rows(3)
 for j,c in enumerate(cols):
  wid=(widths or {}).get(c,min(37,max(14,len(c)+3)))
  s.get_range_by_indexes(0,j,max(4,len(use)+3),1).format.column_width=wid
 return s

def build():
 main_prefix='EXP09A_core_cap4_500blocks';pilot_prefix='EXP09A_pilot_cap4_30blocks'
 core=read(main_prefix+'_descriptive_statistics.csv');pairs=read(main_prefix+'_paired_bootstrap_CI.csv');raw=read(main_prefix+'_policy_runs.csv');pilot=read(pilot_prefix+'_descriptive_statistics.csv')
 if not core:raise RuntimeError('Core results must be complete before workbook creation')
 wb=Workbook.create()
 overview=wb.worksheets.add('Overview')
 overview.get_range('A1:F1').merge();overview.get_range('A1').values=[['EXP-09A  |  Real TLS Session Migration']]
 overview.get_range('A1:F1').format={'fill':BLUE,'font':{'bold':True,'color':WHITE,'size':17},'row_height':40}
 lines=[['Protocol','Locked P1 V1.0 unchanged'],['Network','7 local Linux processes, two TCP forwarding proxies; NOT real SDN'],['Crypto','TLS1.3 X25519 → X25519MLKEM768; ECDSA P-256 cert'],['Primary measured proxy','Run-level p95 inter-successful-response gap (ms)'],['Design','500 paired blocks × (B4/P1) × (BMB/MBB)'],['Security','Verify certificate, group, new-service PING/PONG before MBB switch'],['Inference','Paired 95% bootstrap CI across trial blocks'],['Major limitation','No OpenFlow/OVS, WAN load, 1 GbE physical links or real SLA deadlines']]
 overview.get_range('A3:B10').values=lines
 overview.get_range('A3:A10').format={'fill':CREAM,'font':{'bold':True},'column_width':33}
 overview.get_range('B3:B10').format={'column_width':81,'wrap_text':True,'row_height':31}
 overview.get_range('A12:F12').merge();overview.get_range('A12').values=[['Key measured mechanism comparisons (MBB – BMB; negative favors MBB)']]
 overview.get_range('A12:F12').format={'fill':TEAL,'font':{'bold':True,'color':WHITE},'row_height':26}
 ke=[x for x in pairs if x['metric']=='p95_ack_gap_ms' and 'MBB minus BMB' in x['comparison']]
 kcols=['Policy','Trials','Mean gap Δ (ms)','CI lower (ms)','CI upper (ms)','% matched blocks improved']
 overview.get_range('A13:F13').values=[kcols];overview.get_range('A13:F13').format={'fill':CREAM,'font':{'bold':True},'row_height':24}
 for i,c in enumerate(ke):overview.get_range_by_indexes(13+i,0,1,6).values=[[c['comparison'].split(':')[0],int(c['n']),float(c['mean_diff_ms']),float(c['ci_low_ms']),float(c['ci_high_ms']),round(100*float(c['fraction_first_lower']),1)]]
 overview.get_range('A14:F18').format.column_width=22
 corecols=['policy','mode','n_trials','mean_run_p95_ack_gap_ms','mean_run_p95_excess_gap_ms','mean_run_batch_wall_ms_including_harness','mean_run_offline_attempts','total_offline_attempts','total_failed_attempts','total_verified_cutovers']
 sheet(wb,'Core Summary','500 Matched Blocks — P1 and B4, Both Migration Mechanisms',corecols,core,{'policy':12,'mode':13,'n_trials':13,'mean_run_p95_ack_gap_ms':24,'mean_run_p95_excess_gap_ms':24,'mean_run_batch_wall_ms_including_harness':30})
 if pilot:sheet(wb,'All Policy Pilot','30 Matched Blocks — B1, B2, B3, B4, P1',corecols,pilot)
 paircols=['comparison','metric','n','mean_diff_ms','median_diff_ms','ci_low_ms','ci_high_ms','fraction_first_lower']
 sheet(wb,'Paired CI','Trial-block Paired Bootstrap (95% confidence intervals)',paircols,pairs,{'comparison':32,'metric':29})
 runcols=['trial','policy','mode','parallel','p95_ack_gap_ms','mean_ack_gap_ms','p95_excess_gap_ms','mean_excess_gap_ms','batch_wall_ms_including_harness','offline_attempts','failed_attempts','hybrid_handshakes_verified','old_response_count','new_response_count','no_session_ms_mean']
 sheet(wb,'Core Run Data','2,000 complete core policy runs (for filtering and audit)',runcols,raw,{'policy':12,'mode':11,'batch_wall_ms_including_harness':29})
 neg=json.loads((R/'negative_test_unavailable_hybrid.json').read_text())
 sheet(wb,'Failure Tests','Unreachable hybrid endpoint; no unapproved fallback',
  ['mode','classical_verified','hybrid_verified','old_preserved_on_failure','old_responses','new_responses','unsafe_downgrade','stop_status'],neg)
 sources=wb.worksheets.add('Limitations and Sources');sources.get_range('A1:F1').merge();sources.get_range('A1').values=[['Scientific Reproducibility and Restrictions']]
 sources.get_range('A1:F1').format={'fill':BLUE,'font':{'bold':True,'color':WHITE,'size':15},'row_height':36}
 notes=[['Original source code','src/tls_app.c | exp09a.py | src/migration_scheduler.py'],['Raw measured core records','results/EXP09A_core_cap4_500blocks_service_events.csv'],['Raw measured pilot records','results/EXP09A_pilot_cap4_30blocks_service_events.csv'],['Statistics reproducibility','analyze_exp09a.py (paired block bootstrap)'],['Negative tests','negative_test_recovery.py and results/negative_test_unavailable_hybrid.json'],['Service gap definition','First hybrid successful response minus last classical successful response'],['Main scientific limitation','This experiment does not use ONOS/OpenFlow, privileged network namespaces, real physical H1.0 hardware, or controlled congestion.'],['Crypto boundary','Hybrid key establishment only; ECDSA P-256 certificate authentication is classical.'],['Superiority boundary','These tests isolate migration mechanisms, not a proof that P1 scheduling beats B4 or published systems.']]
 sources.get_range('A3:B11').values=notes
 sources.get_range('A3:A11').format={'column_width':32,'fill':CREAM,'font':{'bold':True},'row_height':35}
 sources.get_range('B3:B11').format={'column_width':90,'wrap_text':True,'row_height':35}
 out=ROOT/'EXP09A_Real_TLS_500_Trial_Results.xlsx';SpreadsheetFile.export_xlsx(wb).save(str(out))
 print('Exported',out, 'size',out.stat().st_size)
 print('Inspect',wb.inspect({'kind':'table','range':'Overview!A12:F16','include':'values,formulas','table_max_rows':5,'table_max_cols':6}).ndjson[:900])
if __name__=='__main__':build()
