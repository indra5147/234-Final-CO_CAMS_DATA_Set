# EXP-09B: Held-out MBB application-migration and deadline enforcement

**Status:** completed source-backed single-host experimental evaluation; **NOT** an ONOS/OpenFlow or H1.0 physical trial.

## Design

- Original P1 scheduler remains locked and unchanged; B4 strong baseline unchanged.
- Candidate P1-v1.1: EXP-07 development-selected LPT ordering, with its development-based predicted synthetic deadline-miss guard; no held-out-data tuning.
- Identical TLS 1.3 X25519 -> X25519MLKEM768, certificate/hostname verification, 12 persistent live application sessions across two TCP forwarding proxies, 4 migration workers, MBB verified preflight, same per-cutover deadline 750 ms for all.
- Distinct held-out application request cadences: fast=1.4 ms, slow=6.3 ms between periodic requests; these represent **request-rate variations, not verified link utilization or independent physical networks**.
- 500 matched trial blocks per held-out profile and 3 policies = 3000 runs/36000 real TLS cutovers (plus preflights). The 12 cutovers within a trial are not treated as independent for CIs.
- Endpoint hard deadline uses monotonic clock from MIGRATE command. On expiry, the verified old session is deactivated and closed; a late successful hybrid handshake is rejected. Before expiry, failed hybrid setup keeps old connection open as a transitional state; it is never marked as migrated.

## Run-level descriptive statistics

| Profile | Policy | Mean run p95 inter-ACK gap (ms) | Mean run p95 excess gap (ms) | Run wall including harness (ms) | Deadline expiries |
|---|---|---:|---:|---:|---:|
| fast_requests | B4 | 3.1645 | 0.9493 | 187.584 | 0 |
| fast_requests | P1 | 3.2818 | 1.0402 | 187.052 | 0 |
| fast_requests | P1_v1.1 | 3.1793 | 0.9640 | 186.423 | 0 |
| slow_requests | B4 | 7.9918 | 0.9058 | 196.311 | 0 |
| slow_requests | P1 | 7.9885 | 0.8554 | 196.579 | 0 |
| slow_requests | P1_v1.1 | 7.9388 | 0.8508 | 196.633 | 0 |

## Paired comparisons relative to B4 (P1/B4 negative means P1 is smaller)

| Profile | Candidate | Metric | Mean paired difference | Trial-block 95% bootstrap CI |
|---|---|---|---:|---:|
| fast_requests | P1 | p95_ack_gap_ms | +0.1173 | [-0.0217, +0.2646] |
| fast_requests | P1 | p95_excess_gap_ms | +0.0909 | [-0.0311, +0.2275] |
| fast_requests | P1 | batch_wall_ms_including_harness | -0.5323 | [-2.3621, +1.3035] |
| fast_requests | P1_v1.1 | p95_ack_gap_ms | +0.0148 | [-0.0898, +0.1104] |
| fast_requests | P1_v1.1 | p95_excess_gap_ms | +0.0147 | [-0.0830, +0.1096] |
| fast_requests | P1_v1.1 | batch_wall_ms_including_harness | -1.1608 | [-2.9636, +0.5267] |
| slow_requests | P1 | p95_ack_gap_ms | -0.0033 | [-0.1320, +0.1360] |
| slow_requests | P1 | p95_excess_gap_ms | -0.0503 | [-0.1651, +0.0786] |
| slow_requests | P1 | batch_wall_ms_including_harness | +0.2677 | [-1.1558, +1.6831] |
| slow_requests | P1_v1.1 | p95_ack_gap_ms | -0.0530 | [-0.1500, +0.0405] |
| slow_requests | P1_v1.1 | p95_excess_gap_ms | -0.0550 | [-0.1437, +0.0357] |
| slow_requests | P1_v1.1 | batch_wall_ms_including_harness | +0.3217 | [-1.0930, +1.8174] |

## Deadline-failure injection tests (see JSON)
- Normal verification and cutover under 250 ms: passed.
- Unavailable hybrid before 250 ms: old TLS preserved, migration unsuccessful: passed.
- Late verified hybrid with 85 ms injected preparation delay and 25 ms deadline: late hybrid rejected and old TLS fail-closed: passed.
- Late failed hybrid after deadline: old TLS fail-closed and migration unsuccessful: passed.
- No unauthorized fallback was recorded. This checks specific fault paths, not formal proof of security.

## Interpretation and limitations
- The metric `p95_ack_gap_ms` is the 95th percentile across 12 service inter-response intervals within each run. It is not verified end-to-end service downtime.
- `batch_wall_ms_including_harness` includes test startup/teardown and control overhead; it is not pure migration makespan.
- All tests use one Linux kernel, loopback network, Python HTTP agents and two TCP forwarding proxies; no ONOS/OVS, actual link congestion, independent VMs or physical seven-PC H1.0 network.
- Workload rates are distinct but priorities, synthetic service loads and service identifiers are the same; reproducibility in these two profiles does not establish generalization to arbitrary traffic.
- A uniform per-cutover deadline is enforced at the application endpoint; the locked common **global campaign migration deadline** has not yet been implemented.
- P1-v1.1 remains a development candidate until independent physical-network and deadline-aware campaign-level evaluation; no method is described as universally superior.
- Upstream external GitHub TLS timings were used to select a candidate earlier (EXP-07). No GitHub timings were substituted for the live TLS observations in EXP-09B.

## Reproduce
```bash
python3 exp09b.py --trials 500 --parallel 4 --scenario fast_requests --policies B4,P1,P1_v1.1
python3 exp09b.py --trials 500 --parallel 4 --scenario slow_requests --policies B4,P1,P1_v1.1
python3 test_deadlines.py
python3 analyze_exp09b.py
```

Research methods: all data observed with real OpenSSL TLS1.3 application sessions; exact source and run logs included.
