#!/usr/bin/env python3
"""Reproducible artifact_tool workbook (no openpyxl/pandas)."""
from pathlib import Path
import csv,json
from artifact_tool import Workbook, SpreadsheetFile
D=Path(__file__).resolve().parent;R=D/'results'
def read(name):
 with (R/name).open(newline='') as f:return list(csv.DictReader(f))
wb=Workbook.create()
BLUE='#122B47';TEAL='#007C85';LIGHT='#E8F4F6'

def sheet(name,title,description,headers,rows,widths=None):
 s=wb.worksheets.add(name)
 n=len(headers);last=chr(64+n)
 s.get_range(f'A1:{last}1').merge_cells() if False else None
 s.merge_cells(f'A1:{last}1')
 s.get_range('A1').values=[[title]]
 s.get_range(f'A1:{last}1').format={'fill':BLUE,'font':{'color':'#FFFFFF','bold':True,'size':16},'row_height':36}
 s.merge_cells(f'A2:{last}2');s.get_range('A2').values=[[description]]
 s.get_range(f'A2:{last}2').format={'fill':LIGHT,'font':{'color':'#23485A','size':10},'row_height':26}
 s.get_range_by_indexes(3,0,1,n).values=[headers]
 s.get_range_by_indexes(3,0,1,n).format={'fill':TEAL,'font':{'color':'#FFFFFF','bold':True},'row_height':26,'wrap_text':True}
 if rows:
  c=[[str(x) if isinstance(x,(dict,list)) else x for x in row] for row in rows]
  # write chunks to limit memory
  for j in range(0,len(c),300):s.get_range_by_indexes(4+j,0,len(c[j:j+300]),n).values=c[j:j+300]
 s.freeze_panes.freeze_rows(4)
 for col in range(n):
  s.get_range_by_indexes(0,col,1,1).format.column_width=(widths[col] if widths and col<len(widths) else 19)
 return s

def numeric(x):
 try:return float(x)
 except:return x
s=read('EXP09B_policy_summary.csv')
h=list(s[0]);r=[[numeric(a[k]) for k in h] for a in s]
sheet('Policy Summary','EXP-09B • Live TLS migration results','500 matched trial blocks per policy × profile; mean values are descriptive, not physical H1.0 performance.',h,r,[20,16,17,17]+[22]*(len(h)-4))
p=read('EXP09B_B4_paired_comparisons.csv');h=list(p[0]);r=[[numeric(a[k]) for k in h] for a in p]
sheet('Paired CI','B4 vs P1 / P1-v1.1','Paired block bootstrap (4,000 replicates). Differences = policy − B4; CI crossing zero means no supported directional improvement.',h,r,[21,17,14,25,23,23,23,26])
run=read('EXP09B_all_3000_policy_runs.csv');h=list(run[0]);r=[[numeric(a[k]) for k in h] for a in run]
sheet('Run-level 3000','Run-level observations','Data observed from real TLS 1.3 X25519→X25519MLKEM768 cutovers via two TCP proxies. Note harness time includes setup/stop.',h,r,[18]*len(h))
f=json.loads((R/'deadline_security_fault_tests.json').read_text());h=['case','hybrid_verified','deadline_expired','old_closed_at_deadline','late_hybrid_rejected','old_preserved_on_failure','unsafe_downgrade','client_returncode'];r=[[x[k] for k in h] for x in f]
sheet('Deadline Tests','Endpoint hard-deadline fault tests','All 4 cases were executed with a live TLS server. Late hybrid acceptance must be denied and expired old session fail-closed.',h,r,[25]+[21]*7)
meta=[['Original locked P1 code SHA256',__import__('hashlib').sha256((D/'src/migration_scheduler.py').read_bytes()).hexdigest()],
 ['Candidate selection','LPT order selected on EXP-07 development data; predicted synthetic deadline-miss guard retained'],
 ['MBB mechanism','Old TLS remains active until hybrid validated and application preflight passed'],
 ['Deadline budget','750 ms per cutover in positive benchmark; 25 ms in injected-expiry tests'],
 ['Fast workload','1.4 ms request cadence per active service'],['Slow workload','6.3 ms request cadence per active service'],
 ['SSL groups','X25519 → X25519MLKEM768; classical ECDSA P-256 authentication'],
 ['Units','Milliseconds except count fields'],
 ['Limitation','Single Linux host, 7 processes, two TCP proxies; no OVS, ONOS or separate machines'],
 ['Important','Inter-ACK gap is NOT literal service downtime; harness wall time includes startup/stop'],
 ['Campaign deadline','NOT implemented: only endpoint-level per-cutover deadline is enforced']]
sheet('Methods & Scope','Experimental scope and reproducibility','Methods, safety guardrails and non-claims', ['Item','Details'],meta,[34,110])
out=D/'EXP09B_Heldout_500x2_Results.xlsx'
SpreadsheetFile.export_xlsx(wb).save(str(out))
print('EXPORTED',str(out),out.stat().st_size)
print(wb.inspect({'kind':'table','range':'Policy Summary!A4:F10','include':'values','table_max_rows':7,'table_max_cols':6}).ndjson[:2200])
print(wb.inspect({'kind':'match','search_term':'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A','options':{'use_regex':True,'max_results':30}}).ndjson[:600])
