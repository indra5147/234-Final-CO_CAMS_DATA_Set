#!/usr/bin/env python3
"""EXP-09A live TLS application cutover; paired BMB vs verified MBB.
Not real ONOS, OpenFlow, Docker, isolated virtual machines, or physical SDN.
C0 orchestrates SW1,SW2 forwarding proxies, CL1/CL2 TLS clients, SR1/SR2 TLS servers.
Application downtime is measured between acknowledgements on persistent TLS sessions.
"""
import argparse, asyncio, csv, json, os, subprocess, sys, statistics, time, math, random, threading, http.server, urllib.request, socket, signal
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'src'))
from migration_scheduler import load_jobs, plan, ALGORITHMS, chunks
HOST={'C0':'127.0.0.10','SW1':'127.0.0.11','SW2':'127.0.0.12','CL1':'127.0.0.21','CL2':'127.0.0.22','SR1':'127.0.0.31','SR2':'127.0.0.32'}
# SW1 forwards to SW2; SW2 forwards to TLS service ports. Four real TCP routes.
ROUTES={
 'SW1':[(31101,HOST['SW2'],31201),(32101,HOST['SW2'],32201),(31102,HOST['SW2'],31202),(32102,HOST['SW2'],32202)],
 'SW2':[(31201,HOST['SR1'],31031),(32201,HOST['SR1'],32031),(31202,HOST['SR2'],31032),(32202,HOST['SR2'],32032)]}
AGENT_PORT={'CL1':35021,'CL2':35022}
POLICIES=('B4','P1','P1_v1.1')
HELDOUT_PERIODS={'fast_requests':1400,'slow_requests':6300}
DEADLINE_BUDGET_MS=750.0

def lpt_with_dev_guard(jobs,max_parallel):
    # Frozen candidate: LPT from EXP-07 development selection; no held-out tuning.
    # Synthetic job deadline predictions are a guard, not a real deadline certificate.
    ordered=sorted(jobs,key=lambda j:(-j.estimated_cutover_ms,j.id))
    original=[j for batch in plan(jobs,'P1',observed_network_load=.10,max_parallel=max_parallel) for j in batch]
    def misses(seq):
        workers=[0.0]*max_parallel;miss=0
        for j in seq:
            ix=min(range(len(workers)),key=lambda k:workers[k]);workers[ix]+=j.estimated_cutover_ms
            miss+=int(workers[ix]>j.deadline_ms)
        return miss
    return chunks(ordered if misses(ordered)<=misses(original) else original,max_parallel)


def make_bin():
 (ROOT/'bin').mkdir(exist_ok=True)
 subprocess.run(['cc','-O2','-std=c11','-Wall','-Wextra','-pthread',str(ROOT/'src/tls_app.c'),'-o',str(ROOT/'bin/tls_app'),'-lssl','-lcrypto'],check=True)
 if not ((ROOT/'certs/server.crt').exists() and (ROOT/'certs/server.key').exists()):
  subprocess.run(['openssl','req','-x509','-newkey','ec','-pkeyopt','ec_paramgen_curve:P-256','-nodes','-keyout',str(ROOT/'certs/server.key'),'-out',str(ROOT/'certs/server.crt'),'-days','14','-subj','/CN=sdn-pqc.local','-addext','subjectAltName=DNS:sdn-pqc.local'],check=True,capture_output=True)

def reachable(ip,port):
 try:
  with socket.create_connection((ip,port),timeout=.1):return True
 except OSError:return False
async def stream(sr,tw):
 try:
  while b:=await sr.read(65536):tw.write(b);await tw.drain()
 except (OSError,asyncio.CancelledError):pass
 finally:
  try:tw.write_eof()
  except (OSError,NotImplementedError):pass
async def run_proxy(role):
 async def handler(reader,writer,dip,dport):
  try:rr,rw=await asyncio.open_connection(dip,dport)
  except OSError:writer.close();await writer.wait_closed();return
  await asyncio.gather(stream(reader,rw),stream(rr,writer))
  for w in (writer,rw):
   w.close()
   try:await w.wait_closed()
   except OSError:pass
 ss=[await asyncio.start_server(lambda r,w,ip=dip,port=dport:handler(r,w,ip,port),HOST[role],pr) for pr,dip,dport in ROUTES[role]]
 print(json.dumps({'role':role,'ready':True,'routes':len(ss)}),flush=True)
 await asyncio.gather(*(s.serve_forever() for s in ss))

class Agent(http.server.BaseHTTPRequestHandler):
 role='';sessions={};lock=threading.Lock()
 def log_message(self,*args):pass
 def answer(self,d,status=200):
  raw=json.dumps(d).encode();self.send_response(status);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
 def do_GET(self):
  self.answer({'role':self.role,'healthy':True})
 def do_POST(self):
  try:
   n=int(self.headers.get('Content-Length','0'));data=json.loads(self.rfile.read(n));op=self.path;ident=data['id'];
   with self.lock:
    if op=='/start':
     if ident in self.sessions:raise RuntimeError('duplicate '+ident)
     k=1 if self.role=='CL1' else 2
     cmd=[str(ROOT/'bin/tls_app'),'client','--host',HOST['SW1'],'--old-port',str(31100+k),'--new-port',str(32100+k),'--ca',str(ROOT/'certs/server.crt'),'--mode',data.get('mode','mbb'),'--deadline-ms',str(data.get('deadline_ms',DEADLINE_BUDGET_MS)),'--period-us',str(data.get('period_us',2500))]
     p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,bufsize=1)
     ready=p.stdout.readline().strip()
     if not ready.startswith('READY classical_verified=1'):raise RuntimeError('TLS startup failed: '+ready+' '+p.stderr.read()[:200])
     self.sessions[ident]=p;self.answer({'ready':True,'id':ident,'old_tls_verified':True});return
    p=self.sessions[ident]
    if op=='/migrate':
     p.stdin.write('MIGRATE\n');p.stdin.flush();line=p.stdout.readline().strip()
     if not line.startswith('MIGRATED ok=1'):raise RuntimeError('hybrid failed '+line)
     self.answer({'id':ident,'hybrid_tls_verified':True});return
    if op=='/stop':
     p.stdin.write('STOP\n');p.stdin.flush();line=p.stdout.readline().strip()
     p.stdin.close();rc=p.wait(timeout=3)
     if not line.startswith('RESULT ') or rc!=0:raise RuntimeError('bad service stop '+line+' rc='+str(rc))
     del self.sessions[ident];v=json.loads(line[len('RESULT '):]);v['id']=ident;self.answer(v);return
   self.answer({'error':'bad operation'},404)
  except Exception as e:self.answer({'error':str(e)},500)
def run_agent(role):
 cls=type('RoleAgent',(Agent,),{'role':role,'sessions':{},'lock':threading.Lock()})
 print(json.dumps({'role':role,'ready':True}),flush=True)
 http.server.ThreadingHTTPServer((HOST[role],AGENT_PORT[role]),cls).serve_forever()

def agent(job):return 'CL1' if int(job[1:])%2 else 'CL2'
def post(service,method,mode="mbb",period_us=2500):
 role=agent(service);raw=json.dumps({'id':service,'mode':mode,'period_us':period_us,'deadline_ms':DEADLINE_BUDGET_MS}).encode();req=urllib.request.Request(f'http://{HOST[role]}:{AGENT_PORT[role]}/{method}',data=raw,headers={'Content-Type':'application/json'})
 try:
  response=urllib.request.urlopen(req,timeout=8)
 except urllib.error.HTTPError as e:
  raise RuntimeError(f"HTTP {e.code} {service}/{method}: {e.read().decode(errors='replace')[:300]}") from e
 with response as resp:
  d=json.load(resp)
  if 'error' in d:raise RuntimeError(f'{service}:{method}:{d["error"]}')
  return d

def spawn(role):
 f=(ROOT/'logs'/f'{role}.log').open('w')
 if role.startswith('SR'):
  k=1 if role=='SR1' else 2
  cmd=[str(ROOT/'bin/tls_app'),'server','--bind',HOST[role],'--old-port',str(31030+k),'--new-port',str(32030+k),'--cert',str(ROOT/'certs/server.crt'),'--key',str(ROOT/'certs/server.key')]
 else:cmd=[sys.executable,str(ROOT/'exp09b.py'),'--role',role]
 return subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT,start_new_session=True),f

def percentile(xs,p):
 v=sorted(xs);k=(len(v)-1)*(p/100);a=int(k);b=min(a+1,len(v)-1);return v[a]+(v[b]-v[a])*(k-a)

def main_experiment(trials,parallel=4,scenario='fast_requests',seed=20261028,policy_names=POLICIES):
 assert 1<=parallel<=4
 make_bin();(ROOT/'results').mkdir(exist_ok=True);(ROOT/'logs').mkdir(exist_ok=True)
 procs={r:spawn(r) for r in ('SR1','SR2','SW2','SW1','CL1','CL2')}
 events=[]; runs=[]; rng=random.Random(seed);jobs=load_jobs();ids=[j.id for j in jobs]
 conditions=[(p,'mbb') for p in policy_names]
 assert scenario in HELDOUT_PERIODS
 period_us=HELDOUT_PERIODS[scenario]
 try:
  for t in range(150):
   if all(reachable(HOST[r],p) for r,p in [('SR1',31031),('SR1',32031),('SR2',31032),('SR2',32032),('SW1',31101),('SW1',32101),('SW1',31102),('SW1',32102),('CL1',35021),('CL2',35022)]):break
   time.sleep(.03)
  else:raise RuntimeError('role connectivity not ready')
  nodepids={'C0':os.getpid(),**{r:p.pid for r,(p,f) in procs.items()}}
  assert len(set(nodepids.values()))==7
  print('SEVEN ROLES READY '+json.dumps(nodepids),flush=True)
  # Both routes and both migration mechanisms, with real TLS app requests.
  for mode in ('mbb',):
   for sid in ('S01','S02'):
    post(sid,'start',mode,period_us);time.sleep(.018)
    post(sid,'migrate',mode);time.sleep(.009)
    r=post(sid,'stop',mode)
    if not all([r['classical_verified'],r['hybrid_verified'],r['new_preflight_ok'],r['old_responses']>0,r['new_responses']>0]):
     raise RuntimeError('failed preflight '+str(r))
  print('PREFLIGHT PASSED: 2 paths × BMB and verified MBB',flush=True)
  for trial in range(1,trials+1):
   cond=list(conditions);rng.shuffle(cond)
   for policy,mode in cond:
    t0=time.monotonic()
    with ThreadPoolExecutor(max_workers=12) as pool:
     list(pool.map(lambda sid:post(sid,'start',mode,period_us),ids))
    time.sleep(.013)
    batches=lpt_with_dev_guard(jobs,parallel) if policy=='P1_v1.1' else plan(jobs,policy,observed_network_load=.1,max_parallel=parallel,fixed_batch=2)
    for bi,b in enumerate(batches):
     with ThreadPoolExecutor(max_workers=parallel) as pool:
      list(pool.map(lambda j:post(j.id,'migrate',mode),b))
     if bi<len(batches)-1 and policy in ('B2','B3'):
      time.sleep(.008 if policy=='B2' else .005)
    time.sleep(.010)
    with ThreadPoolExecutor(max_workers=12) as pool:
     items=list(pool.map(lambda sid:post(sid,'stop',mode),ids))
    wall=(time.monotonic()-t0)*1000
    valid=all(q['classical_verified'] and q['hybrid_verified'] and q['new_preflight_ok']
        and q['old_responses']>=1 and q['new_responses']>=1 and q['ack_gap_ms']>=0
        and q['baseline_gap_ms']>0 and q['excess_gap_ms']>=0
        and not q['unsafe_downgrade'] and not q['deadline_expired'] and q['migration_elapsed_ms']<=DEADLINE_BUDGET_MS and q['hybrid_ready_before_old_close']
        for q in items)
    if not valid:raise RuntimeError('failed app/session validation '+str(items))
    for q in items:
     q.update({'trial':trial,'policy':policy,'mode':mode,'parallel':parallel,
       'environment':'SINGLE_HOST_REAL_TLS_TWO_TCP_PROXIES_NO_OPENFLOW',
       'measured_endpoint':'INTER_ACK_GAP_NOT_NETWORK_AVAILABILITY', 'workload_profile':scenario})
    events.extend(items)
    ag=[x['ack_gap_ms'] for x in items]
    excess=[x['excess_gap_ms'] for x in items]
    runs.append({'trial':trial,'policy':policy,'mode':mode,'parallel':parallel,
       'workload_profile':scenario,'p95_ack_gap_ms':percentile(ag,95),'mean_ack_gap_ms':statistics.mean(ag),
       'p95_excess_gap_ms':percentile(excess,95),'mean_excess_gap_ms':statistics.mean(excess),
       'batch_wall_ms_including_harness':wall,'offline_attempts':sum(x['offline_attempts'] for x in items),
       'failed_attempts':sum(x['failed_attempts'] for x in items),
       'hybrid_handshakes_verified':sum(x['hybrid_verified'] for x in items),
       'old_response_count':sum(x['old_responses'] for x in items),
       'new_response_count':sum(x['new_responses'] for x in items),
       'no_session_ms_mean':statistics.mean(x['no_verified_session_ms'] for x in items),
       'deadline_expired_count':sum(x['deadline_expired'] for x in items),
       'migration_elapsed_ms_p95':percentile([x['migration_elapsed_ms'] for x in items],95)})
   if trial==1 or trial%10==0:
    print(f'COMPLETED {trial}/{trials} blocks: {len(conditions)*trial} runs, {12*len(conditions)*trial} TLS migrations',flush=True)
  prefix=f'EXP09A_{scenario}_cap{parallel}_{trials}blocks';target=ROOT/'results'
  def write(rows,suffix):
   with (target/(prefix+suffix)).open('w',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
  write(events,'_service_events.csv');write(runs,'_policy_runs.csv')
  summary=[]
  for policy in policy_names:
   for mode in ('mbb',):
    rs=[r for r in runs if r['policy']==policy and r['mode']==mode]
    summary.append({'policy':policy,'mode':mode,'runs':len(rs),
     'mean_run_p95_ack_gap_ms':statistics.mean(r['p95_ack_gap_ms'] for r in rs),
     'mean_run_p95_excess_gap_ms':statistics.mean(r['p95_excess_gap_ms'] for r in rs),
     'mean_batch_wall_including_harness_ms':statistics.mean(r['batch_wall_ms_including_harness'] for r in rs),
     'offline_attempts':sum(r['offline_attempts'] for r in rs),
     'failed_attempts':sum(r['failed_attempts'] for r in rs)})
  write(summary,'_summary.csv')
  meta={'experiment':'EXP-09A','trial_blocks':trials,'mechanisms':['bmb','mbb'],
    'policies':list(policy_names),'total_policy_runs':len(runs),'total_cutovers':len(events),
    'workload_period_us':period_us,'deadline_budget_ms_per_cutover':DEADLINE_BUDGET_MS,
    'candidate':'EXP07 DEV-FROZEN LPT ordering with predicted deadline-miss guard',
    'encryption':'TLS 1.3 X25519 -> X25519MLKEM768, ECDSA P-256 certificate',
    'source_protocol':'locked V1.0 P1 scheduler unchanged; candidate exploratory only',
    'strict_limitations':['One Linux kernel + local TCP proxies, not ONOS or OVS',
      'No controlled WAN latency, congestion, SDN-controller load or physical link',
      'Inter-ACK gap is service-continuity proxy, not formal end-to-end downtime',
      'HTTP control agent overhead and server thread scheduling may affect results',
      'Policy priority and loads are fixed synthetic smoke-test inputs',
      'Two held-out workload profiles change per-session request cadence; not real link load',
      'Per-cutover deadline is enforced in the endpoint, not an overall migration campaign deadline',
      'This experiment cannot establish superiority of P1 over published SDN systems'],
    'testbed_node_process_ids':nodepids,
    'openssl':subprocess.check_output(['openssl','version'],text=True).strip()}
  (target/(prefix+'_metadata.json')).write_text(json.dumps(meta,indent=2))
  print('DONE '+json.dumps({'runs':len(runs),'cutovers':len(events),'summary':summary}),flush=True)
 finally:
  for p,f in procs.values():
   if p.poll() is None:p.terminate()
  for p,f in procs.values():
   try:p.wait(timeout=3)
   except subprocess.TimeoutExpired:p.kill();p.wait()
   f.close()

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--role',choices=['SW1','SW2','CL1','CL2']);parser.add_argument('--trials',type=int,default=3);parser.add_argument('--parallel',type=int,default=4);parser.add_argument('--scenario',default='fast_requests');parser.add_argument('--policies',default=','.join(POLICIES));args=parser.parse_args()
 if args.role in ('SW1','SW2'):asyncio.run(run_proxy(args.role))
 elif args.role:run_agent(args.role)
 else:
  names=tuple(args.policies.split(','))
  if not names or any(p not in POLICIES for p in names) or len(set(names))!=len(names):raise SystemExit('Invalid --policies')
  main_experiment(args.trials,args.parallel,args.scenario,policy_names=names)
