#!/usr/bin/env bash
set -euo pipefail
D=/mnt/data/EXP09B_MBB_Deadline_Heldout
PID=1121367
while kill -0 "$PID" 2>/dev/null && ! grep -q '^DONE ' "$D/results/fast_requests_exec.log"; do sleep 2; done
if ! grep -q '^DONE ' "$D/results/fast_requests_exec.log"; then
 echo 'FAST_PROFILE_INCOMPLETE; slow not started' > "$D/results/slow_requests_exec.log";exit 2
fi
sleep 2
python "$D/exp09b.py" --trials 500 --parallel 4 --scenario slow_requests --policies B4,P1,P1_v1.1 > "$D/results/slow_requests_exec.log" 2>&1
