#!/usr/bin/env python3
"""Run-level paired 95% bootstrap comparisons: never count 12 services as independent trials."""
import csv,hashlib,json,statistics,random,math
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
D=Path(__file__).resolve().parent;R=D/'results';P=D/'plots'
PROFILES=['fast_requests','slow_requests'];POLICIES=['B4','P1','P1_v1.1'];METRICS=['p95_ack_gap_ms','p95_excess_gap_ms','batch_wall_ms_including_harness','migration_elapsed_ms_p95','offline_attempts','deadline_expired_count']

def readcsv(p):
 with p.open(newline='') as f:return list(csv.DictReader(f))
def writecsv(p,rows):
 with p.open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def ci(d,seed):
 rg=np.random.default_rng(seed);a=np.array(d,dtype=float)
 # bounded-memory bootstrap (paired trial block), 4000 replicates
 r=np.empty(4000)
 for i in range(4000):r[i]=float(np.mean(a[rg.integers(0,len(a),size=len(a))]))
 return np.percentile(r,[2.5,97.5]).tolist()
runall=[];eventall=[];summ=[];pairs=[];checks=[]
for pi,profile in enumerate(PROFILES):
 prefix=f'EXP09A_{profile}_cap4_500blocks'
 runs=readcsv(R/(prefix+'_policy_runs.csv'))
 events=readcsv(R/(prefix+'_service_events.csv'))
 assert len(runs)==1500,(profile,len(runs))
 assert len(events)==18000,(profile,len(events))
 assert {r['policy'] for r in runs}==set(POLICIES)
 assert {r['mode'] for r in runs}=={'mbb'}
 for pol in POLICIES:
  sub=[r for r in runs if r['policy']==pol]
  assert len(sub)==500 and len({int(r['trial']) for r in sub})==500
 for k in ('classical_verified','hybrid_verified','new_preflight_ok','hybrid_ready_before_old_close'):
  assert all(int(x[k])==1 for x in events),(profile,k)
 for k in ('deadline_expired','old_closed_at_deadline','late_hybrid_rejected','unsafe_downgrade','offline_attempts','failed_attempts'):
  assert all(int(x[k])==0 for x in events),(profile,k)
 assert all(float(x['migration_elapsed_ms'])>0 and float(x['migration_elapsed_ms'])<=750 for x in events)
 assert all(int(x['old_responses'])>0 and int(x['new_responses'])>0 for x in events)
 for r in runs:r['profile']=profile
 for e in events:e['profile']=profile
 runall.extend(runs);eventall.extend(events)
 for pol in POLICIES:
  sub=[r for r in runs if r['policy']==pol]
  row={'profile':profile,'policy':pol,'n_run_blocks':len(sub),'n_cutovers':len(sub)*12}
  for m in METRICS:
   row['mean_'+m]=round(statistics.mean(float(x[m]) for x in sub),6)
  row['median_p95_ack_gap_ms']=round(statistics.median(float(x['p95_ack_gap_ms']) for x in sub),6)
  summ.append(row)
 b={int(r['trial']):r for r in runs if r['policy']=='B4'}
 for pol in ['P1','P1_v1.1']:
  p={int(r['trial']):r for r in runs if r['policy']==pol}
  assert sorted(b)==sorted(p)==list(range(1,501))
  for im,m in enumerate(METRICS):
   d=[float(p[t][m])-float(b[t][m]) for t in range(1,501)]
   lo,hi=ci(d,20261028+pi*100+im*17+len(pol))
   pairs.append({'profile':profile,'policy':pol,'reference':'B4','metric':m,'n_matched_trial_blocks':500,'mean_paired_delta':round(statistics.mean(d),6),'bootstrap_CI95_lower':round(lo,6),'bootstrap_CI95_upper':round(hi,6),'percent_trials_candidate_lower':round(100*sum(z<0 for z in d)/len(d),2)})
 checks.append({'profile':profile,'policy_runs':len(runs),'cutovers':len(events),'successes':sum(int(e['hybrid_verified']) for e in events),'unsafe_downgrades':sum(int(e['unsafe_downgrade']) for e in events),'deadline_expiries':sum(int(e['deadline_expired']) for e in events),'offline_attempts':sum(int(e['offline_attempts']) for e in events),'min_pre_cutover_responses':min(int(e['old_responses']) for e in events),'min_post_cutover_responses':min(int(e['new_responses']) for e in events)})
writecsv(R/'EXP09B_all_3000_policy_runs.csv',runall)
writecsv(R/'EXP09B_all_36000_service_events.csv',eventall)
writecsv(R/'EXP09B_policy_summary.csv',summ)
writecsv(R/'EXP09B_B4_paired_comparisons.csv',pairs)
(R/'EXP09B_integrity_checks.json').write_text(json.dumps(checks,indent=2))
# plot use default matplotlib styles/colors (no customized colors)
fig,axes=plt.subplots(1,2,figsize=(11.6,4.6))
for ax,pf in zip(axes,PROFILES):
 ss=[r for r in summ if r['profile']==pf]
 ax.bar([r['policy'] for r in ss],[r['mean_p95_ack_gap_ms'] for r in ss])
 ax.set_title('Fast request cadence' if pf=='fast_requests' else 'Slow request cadence')
 ax.set_ylabel('Mean run-level p95 inter-ACK gap (ms)')
 ax.set_ylim(0,None)
 ax.grid(axis='y',alpha=.2)
fig.suptitle('EXP-09B: Live TLS make-before-break migration, 500 blocks/profile')
fig.tight_layout();fig.savefig(P/'EXP09B_interack_gap_500blocks.png',dpi=300);plt.close(fig)
fig,axes=plt.subplots(1,2,figsize=(11.6,4.6))
for ax,pf in zip(axes,PROFILES):
 ss=[r for r in summ if r['profile']==pf]
 ax.bar([r['policy'] for r in ss],[r['mean_batch_wall_ms_including_harness'] for r in ss]);ax.set_ylabel('Mean run wall time incl. harness (ms)');ax.set_title(pf.replace('_',' ').title());ax.grid(axis='y',alpha=.2)
fig.tight_layout();fig.savefig(P/'EXP09B_run_wall_time_500blocks.png',dpi=300);plt.close(fig)
report=['# EXP-09B: Held-out MBB application-migration and deadline enforcement','',
 '**Status:** completed source-backed single-host experimental evaluation; **NOT** an ONOS/OpenFlow or H1.0 physical trial.','',
 '## Design','',
 '- Original P1 scheduler remains locked and unchanged; B4 strong baseline unchanged.',
 '- Candidate P1-v1.1: EXP-07 development-selected LPT ordering, with its development-based predicted synthetic deadline-miss guard; no held-out-data tuning.',
 '- Identical TLS 1.3 X25519 -> X25519MLKEM768, certificate/hostname verification, 12 persistent live application sessions across two TCP forwarding proxies, 4 migration workers, MBB verified preflight, same per-cutover deadline 750 ms for all.',
 '- Distinct held-out application request cadences: fast=1.4 ms, slow=6.3 ms between periodic requests; these represent **request-rate variations, not verified link utilization or independent physical networks**.',
 '- 500 matched trial blocks per held-out profile and 3 policies = 3000 runs/36000 real TLS cutovers (plus preflights). The 12 cutovers within a trial are not treated as independent for CIs.',
 '- Endpoint hard deadline uses monotonic clock from MIGRATE command. On expiry, the verified old session is deactivated and closed; a late successful hybrid handshake is rejected. Before expiry, failed hybrid setup keeps old connection open as a transitional state; it is never marked as migrated.',
 '', '## Run-level descriptive statistics','',
 '| Profile | Policy | Mean run p95 inter-ACK gap (ms) | Mean run p95 excess gap (ms) | Run wall including harness (ms) | Deadline expiries |', '|---|---|---:|---:|---:|---:|']
for r in summ:
 report.append(f"| {r['profile']} | {r['policy']} | {r['mean_p95_ack_gap_ms']:.4f} | {r['mean_p95_excess_gap_ms']:.4f} | {r['mean_batch_wall_ms_including_harness']:.3f} | {r['mean_deadline_expired_count']:.0f} |")
report.extend(['','## Paired comparisons relative to B4 (P1/B4 negative means P1 is smaller)','',
 '| Profile | Candidate | Metric | Mean paired difference | Trial-block 95% bootstrap CI |','|---|---|---|---:|---:|'])
for p in pairs:
 if p['metric'] in ('p95_ack_gap_ms','p95_excess_gap_ms','batch_wall_ms_including_harness'):
  report.append(f"| {p['profile']} | {p['policy']} | {p['metric']} | {p['mean_paired_delta']:+.4f} | [{p['bootstrap_CI95_lower']:+.4f}, {p['bootstrap_CI95_upper']:+.4f}] |")
report.extend(['','## Deadline-failure injection tests (see JSON)',
 '- Normal verification and cutover under 250 ms: passed.',
 '- Unavailable hybrid before 250 ms: old TLS preserved, migration unsuccessful: passed.',
 '- Late verified hybrid with 85 ms injected preparation delay and 25 ms deadline: late hybrid rejected and old TLS fail-closed: passed.',
 '- Late failed hybrid after deadline: old TLS fail-closed and migration unsuccessful: passed.',
 '- No unauthorized fallback was recorded. This checks specific fault paths, not formal proof of security.',
 '', '## Interpretation and limitations',
 '- The metric `p95_ack_gap_ms` is the 95th percentile across 12 service inter-response intervals within each run. It is not verified end-to-end service downtime.',
 '- `batch_wall_ms_including_harness` includes test startup/teardown and control overhead; it is not pure migration makespan.',
 '- All tests use one Linux kernel, loopback network, Python HTTP agents and two TCP forwarding proxies; no ONOS/OVS, actual link congestion, independent VMs or physical seven-PC H1.0 network.',
 '- Workload rates are distinct but priorities, synthetic service loads and service identifiers are the same; reproducibility in these two profiles does not establish generalization to arbitrary traffic.',
 '- A uniform per-cutover deadline is enforced at the application endpoint; the locked common **global campaign migration deadline** has not yet been implemented.',
 '- P1-v1.1 remains a development candidate until independent physical-network and deadline-aware campaign-level evaluation; no method is described as universally superior.',
 '- Upstream external GitHub TLS timings were used to select a candidate earlier (EXP-07). No GitHub timings were substituted for the live TLS observations in EXP-09B.',
 '', '## Reproduce',
 '```bash', 'python3 exp09b.py --trials 500 --parallel 4 --scenario fast_requests --policies B4,P1,P1_v1.1',
 'python3 exp09b.py --trials 500 --parallel 4 --scenario slow_requests --policies B4,P1,P1_v1.1',
 'python3 test_deadlines.py', 'python3 analyze_exp09b.py', '```',
 '', 'Research methods: all data observed with real OpenSSL TLS1.3 application sessions; exact source and run logs included.'])
(R/'EXP09B_REPORT.md').write_text('\n'.join(report)+'\n')
files=sorted(p for p in D.rglob('*') if p.is_file() and '__pycache__' not in str(p) and p.name!='MANIFEST_SHA256.json')
(D/'MANIFEST_SHA256.json').write_text(json.dumps({str(p.relative_to(D)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2))
print('ANALYSIS COMPLETE',json.dumps({'checks':checks,'summary':summ,'key_pairs':[p for p in pairs if p['metric']=='p95_ack_gap_ms']},indent=2))
