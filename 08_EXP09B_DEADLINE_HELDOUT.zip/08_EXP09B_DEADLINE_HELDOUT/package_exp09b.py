from pathlib import Path
import zipfile,hashlib,json,platform,subprocess,csv
D=Path(__file__).resolve().parent
out=D.parent/'EXP09B_Real_TLS_Heldout_500x2_Deadline_Executed.zip'
allowed={'README.md','exp09b.py','test_deadlines.py','test_group_rejection.py','analyze_exp09b.py','build_exp09b_workbook.py','EXP09B_Heldout_500x2_Results.xlsx'}
parts=[]
for p in sorted(D.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(D)
 if len(rel.parts)==1 and rel.name in allowed:parts.append(p)
 elif rel.parts[0]=='src' and p.suffix in ('.py','.c'):parts.append(p)
 elif rel.parts[0]=='certs' and rel.name=='server.crt':parts.append(p)
 elif rel.parts[0] in ('results','plots','logs') and not rel.name.endswith('.pid'):
  parts.append(p)
assert (D/'results/EXP09B_all_3000_policy_runs.csv') in parts
assert (D/'results/EXP09B_all_36000_service_events.csv') in parts
checks={str(p.relative_to(D)):hashlib.sha256(p.read_bytes()).hexdigest() for p in parts}
meta={
 'experiment':'EXP09B','type':'SINGLE_HOST_7_ROLE_REAL_TLS_MBB_WITH_ENDPOINT_DEADLINES',
 'total_matched_trials_per_profile':500,'profiles':['fast_requests','slow_requests'],
 'n_policy_runs':3000,'n_service_cutovers':36000,
 'policy_order':['B4','P1','P1_v1.1'],'mode':'mbb','concurrency_cap':4,
 'per_cutover_deadline_ms':750,'fault_test_deadline_ms':25,
 'locked_P1_source_sha256':hashlib.sha256((D/'src/migration_scheduler.py').read_bytes()).hexdigest(),
 'openssl_version':subprocess.check_output(['openssl','version'],text=True).strip(),
 'python_version':platform.python_version(),
 'c_compiler_version':subprocess.check_output(['cc','--version'],text=True).splitlines()[0],
 'trustworthiness_note':'Real TLS sessions over loopback TCP proxies, not physical or actual OpenFlow/SDN measurement',
 'code_and_result_sha256':checks}
(D/'PACKAGE_MANIFEST_SHA256.json').write_text(json.dumps(meta,indent=2))
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in parts:z.write(p,arcname=str(Path('EXP09B_MBB_Deadline_Heldout')/p.relative_to(D)))
 z.write(D/'PACKAGE_MANIFEST_SHA256.json',arcname='EXP09B_MBB_Deadline_Heldout/PACKAGE_MANIFEST_SHA256.json')
with zipfile.ZipFile(out) as z:
 for n,h in checks.items():
  data=z.read('EXP09B_MBB_Deadline_Heldout/'+n)
  assert hashlib.sha256(data).hexdigest()==h,n
  if n.endswith('EXP09B_all_3000_policy_runs.csv'):
   assert len(list(csv.DictReader(data.decode('utf8').splitlines())))==3000
  if n.endswith('EXP09B_all_36000_service_events.csv'):
   assert len(list(csv.DictReader(data.decode('utf8').splitlines())))==36000
 assert z.testzip() is None
print('PACKAGE VERIFIED',out,'bytes',out.stat().st_size,'files',len(checks),'36K events and 3K runs')
