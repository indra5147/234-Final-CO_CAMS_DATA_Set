#!/usr/bin/env python3
"""Separate port test for non-overlapping TLS key exchange policy. No production credentials."""
import json,subprocess
from pathlib import Path
D=Path(__file__).resolve().parent;b=str(D/'bin/tls_app');cert=str(D/'certs/server.crt');key=str(D/'certs/server.key')
srv=subprocess.Popen([b,'server','--bind','127.0.0.39','--old-port','31339','--new-port','32339','--cert',cert,'--key',key],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
try:
 assert srv.stdout.readline().startswith('READY')
 out=[]
 for name,port,g in [('hybrid_client_to_classical_only',31339,'X25519MLKEM768'),('classical_client_to_hybrid_only',32339,'X25519')]:
  cmd=['openssl','s_client','-connect',f'127.0.0.39:{port}','-tls1_3','-groups',g,'-CAfile',cert,'-verify_hostname','sdn-pqc.local','-verify_return_error','-quiet']
  p=subprocess.run(cmd,input=b'PING\n',capture_output=True,timeout=6)
  row={'case':name,'attempted_group':g,'server_port':port,'exit_code':p.returncode,'rejected':p.returncode!=0 and b'handshake failure' in p.stderr,'stderr_excerpt':p.stderr.decode('utf8','replace')[:300]}
  assert row['rejected'],row
  out.append(row)
 (D/'results/group_mismatch_security_tests.json').write_text(json.dumps(out,indent=2))
 print('TLS mismatch rejection PASSED:',[x['case'] for x in out])
finally:
 srv.terminate();srv.wait(timeout=3)
