# EXP-09B: Deadline-Enforced, Make-Before-Break PQC Migration

**Title of ongoing research (locked):** Controller-Orchestrated Crypto-Agile Post-Quantum Migration for Scalable Software-Defined Networks.

This reproducible experimental package uses **seven independent Linux processes on one machine** (C0, CL1/CL2, SW1/SW2 TCP proxies, SR1/SR2), and **actual OpenSSL TLS 1.3 authenticated connections**. It does **not** instantiate seven virtual machines, Open vSwitch, OpenFlow, ONOS, controlled WAN congestion, or the physical H1.0 testbed. The data are local application-level observations, not physical-network experiments.

## Compared policies

- **B4:** locked strong load-aware greedy baseline.
- **P1:** original locked security-aware urgency heuristic, source preserved unmodified from EXP-09A.
- **P1_v1.1:** experimental development-selected LPT ordering plus a calibration-based predicted synthetic-deadline guard from EXP-07. Its selection was made *before* the EXP-09B held-out experiments; the code is not tuned on EXP-09B results.

Identical parameters for all: 12 simultaneously active real TLS applications per policy run; four concurrent workers; verified make-before-break mechanism; group X25519 to X25519MLKEM768; certificate and hostname validation; classical ECDSA P-256 authentication; uniform **750 ms per-cutover hard deadline**. No measured data are substituted or synthesized.

## Held-out request-rate profiles

- `fast_requests`: 1,400 microseconds between periodic application requests.
- `slow_requests`: 6,300 microseconds between periodic application requests.

These profiles change application request cadence (not network bandwidth, traffic burstiness, packet loss or true device CPU load). They do not by themselves establish generalization to external networks. Conditions are randomly interleaved within each 500-block profile.

## Actual deadline enforcement in C

The endpoint starts a monotonic deadline clock at receipt of `MIGRATE`. During MBB, old verified TLS remains in use while hybrid TLS is negotiated. If hybrid verification and application preflight pass before expiry, cutover may occur. If an attempt fails before deadline, old TLS remains active *temporarily* and migration is not reported as successful. If the deadline expires, the old connection is closed fail-closed, and no late hybrid handshake is accepted. This is **endpoint per-cutover enforcement** only, not a controller-wide migration campaign deadline or formal cryptographic security proof.

Four fault tests plus two negative mismatched-TLS-group tests are included. Forced 85-ms hybrid preparation delay with a 25-ms deadline is **controlled fault injection**, not a network-delay measurement.

## Reproduce (Ubuntu, GCC, OpenSSL >=3.5 with X25519MLKEM768)

```bash
python3 exp09b.py --trials 500 --parallel 4 --scenario fast_requests --policies B4,P1,P1_v1.1
python3 exp09b.py --trials 500 --parallel 4 --scenario slow_requests --policies B4,P1,P1_v1.1
python3 test_deadlines.py
python3 test_group_rejection.py
python3 analyze_exp09b.py
python3 build_exp09b_workbook.py
```

Run the two profiles sequentially to avoid network-port collisions. `exp09b.py` compiles its own `src/tls_app.c` and, if needed, creates *test-only* self-signed certificates. Do not use test credentials in production.

## How to interpret results

`p95_ack_gap_ms` is the 95th percentile of the 12 within-run gaps between last classical and first hybrid successful PONG; it is a service-continuity proxy, **not verified network availability/downtime**. `p95_excess_gap_ms` is gap beyond typical pre-migration acknowledgement interval. `batch_wall_ms_including_harness` contains harness startup/stop and must not be called pure migration makespan. Endpoint deadlines are real, but the per-job priority/load/deadline inputs in the scheduler remain synthetic. Paired bootstrap CIs resample **500 run blocks**, not the 12 within-run services, and reflect conditional variability on this single host only.

Any comparative performance advantage in EXP-09B does not support claims about physical H1.0 throughput or superiority to previously published SDN systems. The locked P1 remains unchanged; P1-v1.1 is an unpromoted exploratory candidate.

**Preflight log erratum:** The inherited `exp09b.py` preflight log line says "2 paths × BMB and verified MBB", but EXP-09B preflight loops over `('mbb',)` only, as inspection of the executable source confirms. Only MBB is evaluated in the EXP-09B policy-comparison runs. This message does not alter the experimental operations.
