Original data source identified:
https://github.com/usama0print/pqc-tls-benchmarking

Repository states that results/ contains raw CSV measurements from 1000 handshakes per algorithm across three network scenarios. This has been verified only from the publicly readable project README, not from successful file transfer into this ChatGPT runtime.

The ChatGPT execution container could not resolve github.com, and a separate download attempt also failed. No original GitHub raw files have been downloaded in this environment. The previous benchmark-informed study used reported aggregate means, not original traces.

To download on a computer with working GitHub internet access:
  bash download_original_pqc_tls_github.sh

The script clones at a pinned git commit, enumerates CSVs and records SHA256 checksums. Please upload the resulting results/ folder or ZIP to the conversation if you would like exact original-trace analysis here.

To obtain the second journal authors' framework separately:
https://github.com/montenegro-montes/TLS-PQ
(This is not the source of the localhost/broadband/intercontinental summary numbers.)
