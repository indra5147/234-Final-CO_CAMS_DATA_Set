# User-space OpenFlow13 SDN experiment — controlled_30blocks_5policies_2mechanisms

**Actual executions:** 300 policy runs, 3600 authenticated TLS cutovers across 30 paired blocks.

## Environment and interpretation
- OpenFlow 1.3 HELLO, FEATURES, FLOW_MOD (OXM), BARRIER are real binary wire messages over TCP.
- C0 controller programs SW1/SW2 restricted Python user-space virtual forwarding tables. They gate two-hop connections with default deny.
- Endpoints exchange actual OpenSSL 3.5.5 TLS 1.3 X25519 and X25519MLKEM768 PING/PONG payloads.
- **This is not ONOS/OVS, Mininet, kernel/ASIC Ethernet packet switching, real link congestion, seven independent VMs, or H1.0 physical hardware.**
- No flow statistics via OFPMP, no Ethernet packet parsing: flow route matches use restricted virtual TCP destination labels and output ports. The dataplane TCP relays preserve end-to-end TLS bytes.
- Policy input load is configured, not an observed physical utilization measurement.
- Per-service response gap is between last old and first hybrid acknowledgment, not full service-unavailable duration.
- Repeated runs share a machine; results are local exploratory evidence only.

## Mean run-level measured outcomes

| Mode | Policy | Runs | Mean run-p95 response gap (ms) | Mean cutover batch (ms) | Controller staging (ms) |
|---|---|---:|---:|---:|---:|
| bmb | B1 | 30 | 54.000 | 241.16 | 0.414 |
| bmb | B2 | 30 | 53.992 | 246.56 | 0.427 |
| bmb | B3 | 30 | 53.834 | 389.46 | 0.385 |
| bmb | B4 | 30 | 58.565 | 256.14 | 0.339 |
| bmb | P1 | 30 | 54.279 | 254.73 | 0.456 |
| mbb | B1 | 30 | 4.225 | 242.15 | 0.394 |
| mbb | B2 | 30 | 4.019 | 252.41 | 0.373 |
| mbb | B3 | 30 | 4.671 | 405.38 | 0.481 |
| mbb | B4 | 30 | 4.834 | 258.74 | 0.586 |
| mbb | P1 | 30 | 4.250 | 243.83 | 0.403 |

## Paired comparisons (block bootstrap, 95% CI)

| Comparison | Mode/policy | Mean difference (ms) | 95% CI (ms) |
|---|---|---:|---|
| P1 minus B4 | mbb | -0.584 | -1.804 to +0.187 |
| P1 minus B4 | bmb | -4.286 | -14.611 to +1.199 |
| MBB minus BMB | B1 | -49.775 | -50.532 to -49.067 |
| MBB minus BMB | B2 | -49.973 | -50.746 to -49.296 |
| MBB minus BMB | B3 | -49.164 | -50.373 to -47.401 |
| MBB minus BMB | B4 | -53.731 | -65.660 to -47.135 |
| MBB minus BMB | P1 | -50.029 | -51.715 to -48.922 |

## Proof of programmed forwarding
- Controller logged 2410 flow and switch-lifecycle events.
- Final switch 1: {'dpid': 1, 'routes': {}, 'stats': {'connection_attempts': 7806, 'flow_drops': 606, 'flow_mods': 1204, 'accepted_connections': 7200, 'bytes_up': 16881201, 'bytes_down': 19948385}}
- Final switch 2: {'dpid': 2, 'routes': {}, 'stats': {'connection_attempts': 7201, 'forwarding_errors': 1, 'flow_mods': 1204, 'accepted_connections': 7200, 'bytes_up': 16881201, 'bytes_down': 19948385}}
- Before FLOW_MOD, hybrid route attempts dropped; when rules were installed, verified hybrid TLS worked; after delete, hybrid routes again dropped.
- No unauthorized downgrade or deadline expiry in complete runs.
- These are not comparisons against an externally published SDN implementation.
- Controller staging time is measured separately from TLS cutover batch time, and application response gaps should not be interpreted as full network downtime.
