# User-space OpenFlow13 SDN experiment — high_signal_10blocks_mbb_B4_P1

**Actual executions:** 20 policy runs, 240 authenticated TLS cutovers across 10 paired blocks.

## Environment and interpretation
- OpenFlow 1.3 HELLO, FEATURES, FLOW_MOD (OXM), BARRIER are real binary wire messages over TCP.
- C0 controller programs SW1/SW2 restricted Python user-space virtual forwarding tables. They gate two-hop connections with default deny.
- Endpoints exchange actual OpenSSL 3.5.5 TLS 1.3 X25519 and X25519MLKEM768 PING/PONG payloads.
- **This is not ONOS/OVS, Mininet, kernel/ASIC Ethernet packet switching, real link congestion, seven independent VMs, or H1.0 physical hardware.**
- No flow statistics via OFPMP, no Ethernet packet parsing: flow route matches use restricted virtual TCP destination labels and output ports. The dataplane TCP relays preserve end-to-end TLS bytes.
- Policy input load is configured, not an observed physical utilization measurement.
- Per-service response gap is between last old and first hybrid acknowledgment, not full service-unavailable duration.
- Repeated runs share a machine; results are local exploratory evidence only.

## Mean run-level measured outcomes

| Mode | Policy | Runs | Mean run-p95 response gap (ms) | Mean cutover batch (ms) | Controller staging (ms) |
|---|---|---:|---:|---:|---:|
| mbb | B4 | 10 | 3.258 | 236.07 | 0.855 |
| mbb | P1 | 10 | 2.844 | 393.08 | 0.364 |

## Paired comparisons (block bootstrap, 95% CI)

| Comparison | Mode/policy | Mean difference (ms) | 95% CI (ms) |
|---|---|---:|---|
| P1 minus B4 | mbb | -0.414 | -0.969 to +0.093 |

## Proof of programmed forwarding
- Controller logged 170 flow and switch-lifecycle events.
- Final switch 1: {'dpid': 1, 'routes': {}, 'stats': {'connection_attempts': 526, 'flow_drops': 46, 'flow_mods': 84, 'accepted_connections': 480, 'bytes_up': 1657011, 'bytes_down': 1861487}}
- Final switch 2: {'dpid': 2, 'routes': {}, 'stats': {'connection_attempts': 481, 'forwarding_errors': 1, 'flow_mods': 84, 'accepted_connections': 480, 'bytes_up': 1657011, 'bytes_down': 1861487}}
- Before FLOW_MOD, hybrid route attempts dropped; when rules were installed, verified hybrid TLS worked; after delete, hybrid routes again dropped.
- No unauthorized downgrade or deadline expiry in complete runs.
- These are not comparisons against an externally published SDN implementation.
- Controller staging time is measured separately from TLS cutover batch time, and application response gaps should not be interpreted as full network downtime.
