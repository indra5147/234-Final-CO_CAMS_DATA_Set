import unittest,sys,struct
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from openflow13 import make_flow_mod,decode_flow_mod,packmsg
class TestOF13(unittest.TestCase):
 def test_flow_add(self):self.assertEqual(decode_flow_mod(make_flow_mod(22101,3)),(0,22101,3))
 def test_flow_delete(self):self.assertEqual(decode_flow_mod(make_flow_mod(21102,2,False)),(4,21102,None))
 def test_header(self):self.assertEqual(packmsg(20,9),bytes.fromhex('0414000800000009'))
 def test_deny_invalid(self):
  data=bytearray(make_flow_mod(22102,3));data[47]=0
  with self.assertRaises(ValueError):decode_flow_mod(bytes(data))
 def test_policy_immutability(self):
  from migration_scheduler import load_jobs,plan
  jobs=load_jobs();self.assertEqual(len(jobs),12)
  self.assertEqual(sum(len(b) for b in plan(jobs,'P1',.25,4)),12)
if __name__=='__main__':unittest.main()
