# EXP-10U — OpenFlow 1.3 wire-controlled two-hop user-space SDN prototype

**Research title remains locked:** Controller-Orchestrated Crypto-Agile Post-Quantum Migration for Scalable Software-Defined Networks.

## What was really executed

The Python `C0` controller connects to independent `SW1` and `SW2` user-space switch processes and uses actual **OpenFlow 1.3 binary wire messages** over TCP (HELLO, FEATURES_REQUEST/REPLY, FLOW_MOD with OXM IPv4/TCP_DST and APPLY_ACTIONS/OUTPUT, BARRIER_REQUEST/REPLY). Switches gate *new* virtual service connections using their flow tables. Their data plane uses bidirectional real TCP byte relays over two software hops rather than native OVS Ethernet packet processing. `SR1` and `SR2` are C/OpenSSL TLS servers. `CL1`/`CL2` are client-pool processes that start live C TLS application sessions. There are seven independent logical-role processes and additional short-lived C worker processes.

All actual TLS sessions use TLS 1.3, X25519 classical followed by X25519MLKEM768 hybrid key exchange, ECDSA P-256 server authentication, and certificate verification against an experiment-only certificate. The server responds to actual encrypted PING/PONG application requests. Migration is performed through break-before-make or verified make-before-break.

A complete controller-driven program sequence includes a **default deny proof** for unconfigured hybrid routes, installation of new hybrid route permissions by OpenFlow FLOW_MOD and BARRIER, authenticated TLS cutover, hybrid flow deletion, and a second proof that an unconfigured route is rejected. Flow staging and actual migration timings are independently recorded.

## What this is *not*

**This is not ONOS, Open vSwitch, real OpenFlow Ethernet packet forwarding, or a privileged Linux network namespace network.** These userspace switches implement a limited OpenFlow 1.3 subset; they are not spec-complete and do not parse raw Ethernet/IP packets. The OpenFlow TCP_DST OXM encodes a restricted **virtual connection route label**, and the flow table gates creation of a new TCP relay connection, not Ethernet frames. Traffic stays on a single host's loopback sockets. There is no actual 1GbE link bandwidth, inter-device propagation latency, real network congestion, packet loss, or physical H1.0 hardware; do not describe results as ONOS/OVS or seven-VM measurements. Successful barrier acknowledgements prove only switch-side rule processing in this prototype, not full real-hardware OpenFlow correctness. User-space relay counters are not real OVS switch flow counters.

The same ordinary 12-service jobs are reused across trial blocks; trials are correlated by shared host and workload. The configured policy load signal is not real measured link utilization. Individual inter-response gaps are observed last-classical-to-first-hybrid acknowledgement intervals, not direct continuous-service-unavailability ground truth. There is no end-to-end hard campaign deadline and no controller rollback of already-migrated endpoint sessions. This is functional and exploratory evidence, **not a final result for the locked SDN H1.0 study or a claim of P1 superiority**.

## Layout

```
C0 controller       -- OpenFlow 1.3 (tcp/26653) --> SW1, SW2
CL1 TLS client --SW1 (old 21101/new 22101) --SW2:23000--> SR1 TLS server
CL2 TLS client --SW1 (old 21102/new 22102) --SW2:23000--> SR2 TLS server
```

## Requirements and reproduction

Works without sudo, network namespaces, Docker, Mininet, or Open vSwitch, using Python 3.10+, GCC, libssl development files, and **OpenSSL 3.5.x**. Requires loopback ports 26653, 21101–21102, 22101–22102, 23000, 24201–24202, 24301–24302, and local server addresses 127.0.0.31/.32. Never use on production systems; test keys are generated at run time and not included in the distributable archive.

```bash
python3 -m unittest discover -s tests -v
python3 src/experiment.py --name my_smoke --trials 2 --policies B4,P1 --modes mbb --smoke
python3 src/experiment.py --name my_benchmark --trials 30 \
  --policies B1,B2,B3,B4,P1 --modes mbb,bmb --workers 4
python3 src/analyze.py results/my_benchmark
```

Output folders are exclusive: reusing a study name fails rather than overwriting existing data. The result completion marker is written only when all configured runs and session validation pass. Use `execution_audit.json` for the exact machine/process count, runtime, OpenSSL version, switch counters and control flow events; `policy_runs.csv` contains one row per scheduling/mode trial; `service_events.csv` contains individual observed session gaps; `openflow_events.jsonl` logs flow programming/barriers. `src/analyze.py` rejects incomplete data and constructs trial-block paired bootstrap 95% CIs, without treating 12 sessions as 12 independent experiments.

## Cryptographic and methodological cautions

The hybrid TLS key exchange is post-quantum-classical hybrid, but ECDSA P-256 authentication is **classical**, so the system must never be described as fully post-quantum authenticated. Source code uses certified development keys only for functional testing. All result tables must report B4/P1 comparisons even if the proposed scheduler is worse. The locked P1 algorithm is copied unchanged from the EXP-09B reference source, and P1-v1.1 remains separate/optional.

## Road to actual ONOS/OVS SDN

Use the separate EXP-10 V3 Ubuntu kit on a privileged Ubuntu 24.04 host; switch out the restricted user-space relays for actual OVS OpenFlow switches, and exercise ONOS REST flow-rule lifecycle with real virtual Ethernet and independent traffic counters. Until that is executed and checked, this EXP-10U result supports only a user-space SDN **functional** contribution.
