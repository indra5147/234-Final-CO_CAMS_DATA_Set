import csv,json,re
from pathlib import Path
from artifact_tool import Workbook,SpreadsheetFile
ROOT=Path(__file__).resolve().parents[1]
MAIN=ROOT/'results/controlled_30blocks_5policies_2mechanisms'
HIGH=ROOT/'results/high_signal_10blocks_mbb_B4_P1'
wb=Workbook.create()
NAVY='#16324E';TEAL='#087E8B';PAL='#E6F5F7';WHITE='#FFFFFF'

def put_sheet(name,title,rows,widths=None):
 s=wb.worksheets.add(name)
 w=len(rows[0]);col=lambda i:chr(65+i) if i<26 else 'A'+chr(65+i-26)
 last=col(w-1)
 s.merge_cells(f'A1:{last}1');s.get_range('A1').values=[[title]]
 s.get_range(f'A1:{last}1').format={'fill':NAVY,'font':{'bold':True,'color':WHITE,'size':16},'row_height':34,'vertical_alignment':'center'}
 s.get_range_by_indexes(2,0,len(rows),w).values=rows
 s.get_range_by_indexes(2,0,1,w).format={'fill':TEAL,'font':{'bold':True,'color':WHITE},'row_height':26,'wrap_text':True}
 s.get_range_by_indexes(3,0,max(1,len(rows)-1),w).format.row_height=20
 for i in range(w):s.get_range_by_indexes(0,i,len(rows)+3,1).format.column_width=(widths[i] if widths and i<len(widths) else 20)
 s.freeze_panes.freeze_rows(3)
 return s

def readcsv(p):
 with p.open(newline='') as f:data=list(csv.reader(f))
 def coerce(v):
  if re.fullmatch(r'-?\d+',v):return int(v)
  if re.fullmatch(r'-?(?:\d+\.\d*|\d*\.\d+)(?:[eE][+-]?\d+)?',v):return float(v)
  return v
 return [data[0]]+[[coerce(v) for v in row] for row in data[1:]]

summary=readcsv(MAIN/'summary.csv')
S=put_sheet('Policy Summary','EXP-10U | Measured TLS Response Gaps (30 matched blocks)',summary,[17,17,12,27,27,24,28,22,20])
# format main numeric columns
for cl in ['D','E','F','G']:
 S.get_range(f'{cl}4:{cl}{len(summary)+2}').set_number_format('0.000')
pairs=readcsv(MAIN/'paired_95CI.csv')
P=put_sheet('Paired Statistics','Paired Trial-Block Bootstrap | 95% Confidence Intervals',pairs,[24,20,44,22,22,22,12])
for cl in ['D','E','F']:P.get_range(f'{cl}4:{cl}{len(pairs)+2}').set_number_format('0.000')

hi=readcsv(HIGH/'summary.csv')
H=put_sheet('High Signal Pilot','High Policy-Signal Sensitivity | 10 Trials | Not Measured Link Congestion',hi,[17,16,12,27,25,25,26,24,19])
for cl in ['D','E','F','G']:H.get_range(f'{cl}4:{cl}{len(hi)+2}').set_number_format('0.000')

runs=readcsv(MAIN/'policy_runs.csv')
R=put_sheet('Policy Runs 300','Raw Run-Level Results | Complete 300 Executed Runs',runs,[37,11,15,17,11,11,25,25,25,24,24,22,24,20,20,20,20,20])

au=json.load((MAIN/'execution_audit.json').open())
aud=[['Evidence field','Actual recorded value']]
for key in ['study','type','version','trials','policy_runs','service_cutovers','all_tls_verified','openssl','control_flow_event_count','elapsed_s']:
 aud.append([key,json.dumps(au[key]) if isinstance(au[key],(list,dict)) else str(au[key])])
for node in ['1','2']:
 st=au['switch_status_after'][node]
 aud+=[[f'SW{node} flow mods',str(st['stats'].get('flow_mods',0))],[f'SW{node} accepted connections',str(st['stats'].get('accepted_connections',0))],[f'SW{node} dropped pre/post flow attempts',str(st['stats'].get('flow_drops',0))],[f'SW{node} forwarded bytes up',str(st['stats'].get('bytes_up',0))]]
A=put_sheet('Evidence Audit','Controller and Switch Evidence (User-Space OpenFlow Subset)',aud,[42,92])

notes=[['Category','Explanation'],
 ['Status','Real OpenFlow1.3 wire messages controlling restricted Python forwarding tables; local TLS measured.'],
 ['Not verified','NOT genuine ONOS, OVS, Mininet, virtual Ethernet, physical H1.0 seven PCs.'],
 ['Data plane','Two TCP relays preserving encrypted TLS bytes; route rules match virtual connection labels, not decoded Ethernet frames.'],
 ['Primary metric','Last-classical to first-hybrid application response gap; not full service unavailability.'],
 ['Performance','System loads share one host; no network congestion, link speed or propagation measurements.'],
 ['P1','Locked scheduler version untouched from EXP-09B.'],
 ['Policy load','Configured 0.25 (main) and 0.80 (pilot); not measured actual link utilization.'],
 ['Sensitivity','High-policy-signal pilot uses 10 blocks: B4 vs P1, MBB only, shorter 1400-us request cadence.'],
 ['Certificates','ECDSA P-256 classical authentication; hybrid X25519MLKEM768 key exchange, not fully PQ authentication.'],
 ['Statistics','Paired bootstrap by 30 blocks; 12 services are not 12 independent trials.'],
 ['Claims','No statistically supported P1 superiority over B4 in 30-block primary experiment.'],
 ['Real integration','Genuine ONOS/OVS testing still requires privileged Ubuntu 24.04.']]
N=put_sheet('Method Notes','Mandatory Scientific Limitations and Reproduction Notes',notes,[27,105]);N.get_range('B4:B16').format.wrap_text=True
out=ROOT/'EXP10U_Executed_Results_320_Runs.xlsx'
print(wb.inspect({'kind':'table','range':'Policy Summary!A3:I7','include':'values','table_max_rows':5,'table_max_cols':9}).ndjson[:2000])
print('WRITE',out)
SpreadsheetFile.export_xlsx(wb).save(str(out))
print('BYTES',out.stat().st_size)
