#!/usr/bin/env python3
"""Unprivileged user-space SDN: *actual* OpenFlow1.3 control-plane frames
and controller-gated forwarding of real TLS traffic through two TCP proxies.
Experimental and educational; NO ONOS, NO OVS, NO Ethernet forwarding,
NO 1 GbE congestion emulation, NO physical H1.0 claim.
"""
import argparse,os,sys,json,time,socket,subprocess,signal,statistics,random,csv,hashlib,math
import urllib.request,urllib.error
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'))
from openflow13 import Controller
from migration_scheduler import load_jobs,plan,chunks
POLICIES=('B1','B2','B3','B4','P1','P1_v1.1')
ROUTES=(21101,21102,22101,22102)

def status(dpid):
    with socket.create_connection(('127.0.0.1',24200+dpid),timeout=2) as s:
        return json.loads(s.recv(40000).decode())

def wait_port(port,host='127.0.0.1',timeout=7):
    until=time.monotonic()+timeout
    while time.monotonic()<until:
        try:
            with socket.create_connection((host,port),timeout=.15):return True
        except OSError:time.sleep(.03)
    raise RuntimeError(f'port unavailable {host}:{port}')

def post(key,action,mode,period_us,deadline_ms):
    node=1 if int(key[1:])%2 else 2
    raw=json.dumps({'id':key,'mode':mode,'period_us':period_us,'deadline_ms':deadline_ms}).encode()
    req=urllib.request.Request(f'http://127.0.0.1:{24300+node}/{action}',data=raw,headers={'Content-Type':'application/json'})
    try:
        with urllib.request.urlopen(req,timeout=7) as r:data=json.load(r)
    except urllib.error.HTTPError as e:raise RuntimeError(f'{key}/{action} {e.read().decode()[:250]}') from e
    if 'error' in data:raise RuntimeError(f'{key}/{action} {data["error"]}')
    return data

def pct(xs,p):
    xs=sorted(xs);k=(len(xs)-1)*p/100;lo=int(k);hi=min(lo+1,len(xs)-1)
    return xs[lo]+(xs[hi]-xs[lo])*(k-lo)

def plan_jobs(jobs,policy,parallel,observed_load):
    if policy!='P1_v1.1':return plan(jobs,policy,observed_network_load=observed_load,max_parallel=parallel)
    ranked=sorted(jobs,key=lambda j:(-j.estimated_cutover_ms,j.id))
    original=[j for group in plan(jobs,'P1',observed_network_load=observed_load,max_parallel=parallel) for j in group]
    def miss(jlist):
        v=[0.]*parallel;n=0
        for j in jlist:
            i=min(range(parallel),key=lambda x:v[x]);v[i]+=j.estimated_cutover_ms;n+=int(v[i]>j.deadline_ms)
        return n
    return chunks(ranked if miss(ranked)<=miss(original) else original,parallel)

def run_cmd(*args):
    return subprocess.run(args,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)

def gen_cert():
    (ROOT/'certs').mkdir(exist_ok=True)
    run_cmd('openssl','req','-x509','-newkey','ec','-pkeyopt','ec_paramgen_curve:P-256','-nodes','-keyout',str(ROOT/'certs/server.key'),'-out',str(ROOT/'certs/server.crt'),'-days','1','-subj','/CN=sdn-pqc.local','-addext','subjectAltName=DNS:sdn-pqc.local')
    os.chmod(ROOT/'certs/server.key',0o600)

def build():
    (ROOT/'bin').mkdir(exist_ok=True)
    run_cmd('gcc','-O2','-std=c11','-Wall','-Wextra','-pthread',str(ROOT/'src/tls_app.c'),'-o',str(ROOT/'bin/tls_app'),'-lssl','-lcrypto')
    gen_cert()

def spawn(name,cmd):
    (ROOT/'logs').mkdir(exist_ok=True)
    f=open(ROOT/'logs'/f'{name}.log','w');p=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
    return p,f

def check_route_drop(route):
    # SW1 accepts TCP but MUST immediately drop non-authorized flow.
    with socket.create_connection(('127.0.0.1',route),timeout=2) as s:
        s.settimeout(1.5)
        try:return s.recv(1)==b''
        except ConnectionResetError:return True

def execute(args):
    (ROOT/'results').mkdir(exist_ok=True)
    study=ROOT/'results'/args.name
    study.mkdir(exist_ok=False)
    build()
    controller=Controller();procs={};rows=[];events=[];r=random.Random(args.seed);deadline_ms=800
    try:
        for ix in (1,2):
            procs[f'SW{ix}']=spawn(f'SW{ix}',[sys.executable,str(ROOT/'src/switch.py'),str(ix)])
        for ix in (1,2):
            procs[f'SR{ix}']=spawn(f'SR{ix}',[str(ROOT/'bin/tls_app'),'server','--bind',f'127.0.0.{30+ix}','--old-port',str(31030+ix),'--new-port',str(32030+ix),'--cert',str(ROOT/'certs/server.crt'),'--key',str(ROOT/'certs/server.key')])
        for ix in (1,2):
            procs[f'CL{ix}']=spawn(f'CL{ix}',[sys.executable,str(ROOT/'src/client_agent.py'),f'CL{ix}'])
        controller.wait_for(2)
        for port in [21101,21102,22101,22102,23000,24301,24302]:wait_port(port)
        for ix in (1,2):
            for base in (31030,32030):wait_port(base+ix,f"127.0.0.{30+ix}")
        pids={'C0':os.getpid(),**{n:v[0].pid for n,v in procs.items()}}
        assert len(pids)==7 and len(set(pids.values()))==7
        # Default-deny on two unprogrammed switches: a live data-path probe.
        assert check_route_drop(22101),'unprogrammed hybrid path was accepted'
        for route in (21101,21102):
            for dpid,out in [(2,1 if route%100==1 else 2),(1,3)]:controller.flow(dpid,route,out,True)
        assert set(map(int,status(1)['routes']))=={21101,21102}
        status_before={str(i):status(i) for i in [1,2]}
        if args.smoke:
            for route in (21101,21102):
                with socket.create_connection(('127.0.0.1',route),timeout=2) as s:pass
        jobs=load_jobs();policies=list(args.policies.split(','));modes=list(args.modes.split(','))
        for policy in policies:
            if policy not in POLICIES:raise ValueError('unknown policy')
        for mode in modes:
            if mode not in ('mbb','bmb'):raise ValueError('unknown cutover mode')
        protocol_start=time.time()
        for block in range(1,args.trials+1):
            configs=[(p,m) for m in modes for p in policies];r.shuffle(configs)
            for policy,mode in configs:
                ident=f'{args.name}-B{block:04d}-{policy}-{mode}'
                period=args.request_period_us
                # Start actual live classical sessions before hybrid-path provisioning.
                start=time.perf_counter()
                with ThreadPoolExecutor(max_workers=12) as pool:
                    ready=list(pool.map(lambda j:post(j.id,'start',mode,period,deadline_ms),jobs))
                warm_ms=(time.perf_counter()-start)*1000
                old_count_before=status(1)['stats'].get('bytes_up',0)
                time.sleep(.008)
                # Hybrid path is closed at the beginning of *each* campaign.
                assert check_route_drop(22102),'hybrid path admitted before OF FLOW_MOD'
                stg=time.perf_counter()
                for route in (22101,22102):
                    for dpid,out in [(2,1 if route%100==1 else 2),(1,3)]:controller.flow(dpid,route,out,True)
                controller_stage_ms=(time.perf_counter()-stg)*1000
                assert {22101,22102}.issubset(set(map(int,status(1)['routes'])))
                observed_bytes=max(0,status(1)['stats'].get('bytes_up',0)-old_count_before)
                # Local per-route traffic byte counts are not measured 1GbE utilization.
                used_load=args.policy_load
                batchlist=plan_jobs(jobs,policy,args.workers,used_load)
                migrate_start=time.perf_counter()
                with ThreadPoolExecutor(max_workers=args.workers) as pool:
                    for batch in batchlist:
                        list(pool.map(lambda j:post(j.id,'migrate',mode,period,deadline_ms),batch))
                cutover_ms=(time.perf_counter()-migrate_start)*1000
                time.sleep(.012)
                with ThreadPoolExecutor(max_workers=12) as pool:
                    outcomes=list(pool.map(lambda j:post(j.id,'stop',mode,period,deadline_ms),jobs))
                # End campaign before removal; remove hybrid rules and verify deny.
                rm=time.perf_counter()
                for route in (22101,22102):
                    for dpid,out in [(1,3),(2,1 if route%100==1 else 2)]:controller.flow(dpid,route,out,False)
                remove_ms=(time.perf_counter()-rm)*1000
                assert check_route_drop(22101),'post-removal path did not deny'
                all_ok=all(a['classical_verified']==1 and a['hybrid_verified']==1 and a['unsafe_downgrade']==0 and a['deadline_expired']==0 and a['new_preflight_ok']==1 and a['old_responses']>0 and a['new_responses']>0 for a in outcomes)
                gaps=[a['ack_gap_ms'] for a in outcomes]
                if not all_ok or any(g<=0 for g in gaps):raise AssertionError(f'{ident}: TLS/response validation failed')
                row={'run_id':ident,'trial':block,'policy':policy,'mechanism':mode,'sessions':len(outcomes), 'success':int(all_ok),'run_p95_response_gap_ms':pct(gaps,95),'mean_response_gap_ms':statistics.mean(gaps),'cutover_batch_ms':cutover_ms,'flow_stage_ms':controller_stage_ms,'flow_remove_ms':remove_ms,'classical_startup_ms':warm_ms,'local_proxy_bytes_during_warmup':observed_bytes,'offline_attempts':sum(a['offline_attempts'] for a in outcomes),'deadline_expiries':sum(a['deadline_expired'] for a in outcomes),'unsafe_downgrades':sum(a['unsafe_downgrade'] for a in outcomes),'worker_ceiling':args.workers,'policy_signal_load':used_load}
                rows.append(row)
                for j,v in zip(jobs,outcomes):
                    events.append(dict({'run_id':ident,'trial':block,'policy':policy,'mechanism':mode,'job':j.id},**v))
                if block==1 or block%10==0:print(f"DONE trial={block}/{args.trials} policy={policy} mode={mode} p95_gap_ms={row['run_p95_response_gap_ms']:.3f}",flush=True)
        for route in (21101,21102):
            for dpid,out in [(1,3),(2,1 if route%100==1 else 2)]:controller.flow(dpid,route,out,False)
        assert check_route_drop(21101),'old path should be denied after flow removal'
        with (study/'policy_runs.csv').open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
        with (study/'service_events.csv').open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(events[0]));w.writeheader();w.writerows(events)
        with (study/'openflow_events.jsonl').open('w') as f:
            for event in controller.log:f.write(json.dumps(event)+'\n')
        observed={'study':args.name,'type':'user-space OpenFlow 1.3 control TCP and two-hop TLS forwarding, not ONOS/OVS','version':'OpenFlow 1.3 wire version 0x04, restricted custom implementation','trials':args.trials,'policies':policies,'mechanisms':modes,'policy_runs':len(rows),'service_cutovers':len(events),'all_tls_verified':True,'pids':pids,'openssl':run_cmd('openssl','version').stdout.strip(),'control_flow_event_count':len(controller.log),'switch_status_before':status_before,'switch_status_after':{str(i):status(i) for i in [1,2]},'elapsed_s':time.time()-protocol_start,'limitations':['No ONOS or OVS','No kernel packet forwarding or Ethernet/veth namespaces','Local user-space TCP relay; OpenFlow flow matches are evaluated against virtual connection route metadata, not parsed Ethernet/IP packets','No physical/link-bandwidth utilization, packet loss, SDN hardware or congestion','No independent resource-isolated VMs','Controller flow staging outside per-service deadline','Workload policy load signal is configured, not measured physical utilization','P1 is locked unchanged; candidate is exploratory','Response gaps not entire app unavailability']}
        (study/'execution_audit.json').write_text(json.dumps(observed,indent=2))
        (study/'EXP10U_COMPLETED.json').write_text(json.dumps({'success':True,'policy_runs':len(rows),'service_cutovers':len(events),'note':'Unprivileged OpenFlow protocol subset SDN functional test, NOT ONOS/OVS'},indent=2))
        print('COMPLETE '+json.dumps({'policy_runs':len(rows),'cutovers':len(events),'study':str(study)}),flush=True)
    except Exception as e:
        (study/'EXECUTION_FAILED.json').write_text(json.dumps({'error':repr(e),'completed_policy_rows':len(rows),'completed_service_events':len(events)},indent=2))
        raise
    finally:
        controller.close()
        for k,(p,f) in procs.items():
            try:os.killpg(p.pid,signal.SIGTERM)
            except ProcessLookupError:pass
            f.close()

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--name',default='smoke');ap.add_argument('--trials',type=int,default=2);ap.add_argument('--workers',type=int,default=4);ap.add_argument('--policies',default='B4,P1,P1_v1.1');ap.add_argument('--modes',default='mbb');ap.add_argument('--request-period-us',type=int,default=2400);ap.add_argument('--policy-load',type=float,default=.25);ap.add_argument('--seed',type=int,default=20261029);ap.add_argument('--smoke',action='store_true');args=ap.parse_args();execute(args)
