"""Restricted OpenFlow 1.3 wire-protocol subset used in an unprivileged
user-space SDN *functional* experiment. Not a complete OpenFlow switch.
Supported: HELLO, FEATURES, FLOW_MOD with ETH_TYPE/IP_PROTO/TCP_DST OXM,
APPLY_ACTIONS/OUTPUT, BARRIER. Fails closed on malformed/unmatched flows.
No PacketIn/PacketOut, flooding, OVS, port-statistic support or ONOS.
"""
import socket,struct,threading,collections
VERSION=4
HELLO,ERROR,ECHO_REQUEST,ECHO_REPLY,FEATURES_REQUEST,FEATURES_REPLY,FLOW_MOD,BARRIER_REQUEST,BARRIER_REPLY=0,1,2,3,5,6,14,20,21
OFP_NO_BUFFER=0xffffffff
OFPP_ANY=0xffffffff
OFP_MATCH_OXM=1

def packmsg(kind,xid=0,payload=b''):
    return struct.pack('!BBHI',VERSION,kind,8+len(payload),xid)+payload

def recv_exact(sock,n):
    b=bytearray()
    while len(b)<n:
        a=sock.recv(n-len(b))
        if not a: raise EOFError('peer closed')
        b.extend(a)
    return bytes(b)

def recvmsg(sock):
    raw=recv_exact(sock,8)
    ver,typ,length,xid=struct.unpack('!BBHI',raw)
    if ver!=VERSION or length<8 or length>16384:raise ValueError('invalid OF1.3 header')
    return typ,xid,recv_exact(sock,length-8)

def oxm(field,raw):return struct.pack('!HBB',0x8000,field<<1,len(raw))+raw

def make_flow_mod(route,port,add=True):
    # OpenFlow v1.3 standard flow_mod + OXM (eth_type/IP_PROTO/TCP_DST)
    fields=oxm(5,struct.pack('!H',0x0800))+oxm(10,b'\x06')+oxm(14,struct.pack('!H',route))
    m=struct.pack('!HH',1,4+len(fields))+fields
    m+=b'\x00'*((-len(m))%8)
    command=0 if add else 4  # OFPFC_ADD / OFPFC_DELETE_STRICT
    base=struct.pack('!QQBBHHHIIIH2x',route,0,0,command,0,0,100,OFP_NO_BUFFER,OFPP_ANY,OFPP_ANY,0)
    action=struct.pack('!HHIH6x',0,16,port,0)
    inst=struct.pack('!HH4x',4,8+len(action))+action
    return base+m+(inst if add else b'')

def decode_flow_mod(raw):
    if len(raw)<40:raise ValueError('truncated flow_mod')
    cookie,cookie_mask,table_id,cmd,idle,hard,priority,buf,outport,outgroup,flags=struct.unpack('!QQBBHHHIIIH2x',raw[:40])
    mt,mlen=struct.unpack('!HH',raw[40:44])
    if mt!=1 or mlen<4 or 40+mlen>len(raw):raise ValueError('bad OXM match')
    k=44; end=40+mlen; fields={}
    while k<end:
        if k+4>end:raise ValueError('truncated OXM')
        cls,f,lenv=struct.unpack('!HBB',raw[k:k+4]);k+=4
        if cls!=0x8000 or f&1 or k+lenv>end:raise ValueError('invalid OXM')
        fields[f>>1]=raw[k:k+lenv];k+=lenv
    if fields.get(5)!=b'\x08\x00' or fields.get(10)!=b'\x06' or len(fields.get(14,b''))!=2:raise ValueError('not IPv4 TCP destination match')
    route=struct.unpack('!H',fields[14])[0]
    if cmd==4:return cmd,route,None
    if cmd!=0:raise ValueError('unsupported flow command')
    off=40+((mlen+7)//8)*8
    if len(raw)<off+24:raise ValueError('missing output action')
    typ,ilen=struct.unpack('!HH',raw[off:off+4]);at,alen,port=struct.unpack('!HHI',raw[off+8:off+16]);
    if typ!=4 or ilen!=24 or at!=0 or alen!=16:raise ValueError('invalid apply/output action')
    return cmd,route,port

class Controller:
    def __init__(self,host='127.0.0.1',port=26653):
        self.server=socket.socket();self.server.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);self.server.bind((host,port));self.server.listen(8)
        self.peers={};self.xid=100;self.log=[];self.lock=threading.Lock();self.alive=True
        self.thread=threading.Thread(target=self._accept,daemon=True);self.thread.start()
    def record(self,event,**kwargs):
        with self.lock:self.log.append({'event':event,**kwargs})
    def _accept(self):
        while self.alive:
            try:s,_=self.server.accept();s.setsockopt(socket.IPPROTO_TCP,socket.TCP_NODELAY,1);s.settimeout(4);threading.Thread(target=self._setup,args=(s,),daemon=True).start()
            except (OSError,EOFError):break
    def _setup(self,s):
        try:
            typ,xid,data=recvmsg(s)
            if typ!=HELLO:raise ValueError('switch did not send HELLO')
            s.sendall(packmsg(HELLO,1))
            s.sendall(packmsg(FEATURES_REQUEST,2))
            typ,xid,data=recvmsg(s)
            if typ!=FEATURES_REPLY or len(data)!=24:raise ValueError('invalid FEATURES_REPLY')
            dpid=struct.unpack('!Q',data[:8])[0]
            with self.lock:self.peers[dpid]=s
            self.record('switch_up',dpid=dpid,feature_len=len(data))
        except Exception as e:
            self.record('switch_error',error=str(e))
            s.close()
    def wait_for(self,n=2,timeout=7):
        import time
        t=time.monotonic()+timeout
        while time.monotonic()<t:
            with self.lock:
                if len(self.peers)>=n:return True
            time.sleep(.02)
        raise TimeoutError('OpenFlow switch registration failed')
    def flow(self,dpid,route,port,add=True):
        with self.lock:
            s=self.peers[dpid];self.xid+=1;f_xid=self.xid;self.xid+=1;b_xid=self.xid
        s.sendall(packmsg(FLOW_MOD,f_xid,make_flow_mod(route,port,add)))
        s.sendall(packmsg(BARRIER_REQUEST,b_xid))
        typ,xid,data=recvmsg(s)
        if typ!=BARRIER_REPLY or xid!=b_xid:raise RuntimeError(f'barrier failed dpid={dpid} route={route} got={(typ,xid)}')
        self.record('flow_'+('add' if add else 'delete'),dpid=dpid,tcp_dst=route,output_port=port,barrier_xid=b_xid,barrier_confirmed=True)
    def close(self):
        self.alive=False
        for s in self.peers.values():
            try:s.close()
            except:pass
        self.server.close()

class UserSwitch:
    def __init__(self,dpid):
        self.dpid=dpid;self.routes={};self.lock=threading.Lock();self.stats=collections.Counter();self.alive=True;self.sockets=[]
    def record(self,key,value=1):
        with self.lock:self.stats[key]+=value
    def route(self,route):
        with self.lock:return self.routes.get(route)
    def control(self):
        import time
        s=socket.create_connection(('127.0.0.1',26653),timeout=5);s.setsockopt(socket.IPPROTO_TCP,socket.TCP_NODELAY,1);s.settimeout(None)
        self.sockets.append(s);s.sendall(packmsg(HELLO,1))
        while self.alive:
            typ,xid,data=recvmsg(s)
            if typ==HELLO:continue
            if typ==FEATURES_REQUEST:
                payload=struct.pack('!QIBB2xII',self.dpid,256,1,0,0,0)
                s.sendall(packmsg(FEATURES_REPLY,xid,payload))
            elif typ==FLOW_MOD:
                try:
                    cmd,route,port=decode_flow_mod(data)
                    if route not in [21101,22101,21102,22102]:raise ValueError('unapproved flow destination')
                    if cmd==0:
                        if port != (3 if self.dpid==1 else (1 if route%100==1 else 2)):raise ValueError('unapproved output port')
                        with self.lock:self.routes[route]=port
                    else:
                        with self.lock:self.routes.pop(route,None)
                    self.record('flow_mods')
                except Exception:
                    self.record('flow_rejects')
                    s.sendall(packmsg(ERROR,xid,struct.pack('!HH',3,0)))
            elif typ==BARRIER_REQUEST:s.sendall(packmsg(BARRIER_REPLY,xid))
            elif typ==ECHO_REQUEST:s.sendall(packmsg(ECHO_REPLY,xid,data))
            else:self.record('unsupported_of_messages')
    def listen(self,port,handle):
        s=socket.socket();s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);s.bind(('127.0.0.1',port));s.listen(128);s.settimeout(.5);self.sockets.append(s)
        while self.alive:
            try:conn,_=s.accept();threading.Thread(target=handle,args=(conn,port),daemon=True).start()
            except socket.timeout:continue
            except OSError:break
    def pump(self,a,b):
        import select
        pair=[a,b]
        try:
            while self.alive:
                ready,_,_=select.select(pair,[],[],.3)
                for s in ready:
                    try:data=s.recv(65536)
                    except OSError:return
                    if not data:return
                    peer=b if s is a else a;peer.sendall(data)
                    self.record('bytes_up' if s is a else 'bytes_down',len(data))
        except (OSError,BrokenPipeError):pass
        finally:
            for s in pair:
                try:s.close()
                except:pass
    def on_sw1(self,conn,port):
        self.record('connection_attempts')
        if self.route(port)!=3:
            self.record('flow_drops');conn.close();return
        try:
            peer=socket.create_connection(('127.0.0.1',23000),timeout=3)
            peer.sendall(struct.pack('!H',port));self.record('accepted_connections')
            self.pump(conn,peer)
        except OSError:
            self.record('forwarding_errors');conn.close()
    def on_sw2(self,conn,_port):
        self.record('connection_attempts')
        try:
            conn.settimeout(3);route=struct.unpack('!H',recv_exact(conn,2))[0];conn.settimeout(None)
            action=self.route(route)
            if action is None:
                self.record('flow_drops');conn.close();return
            is_hybrid=route>=22000;port=(32031 if action==1 else 32032) if is_hybrid else (31031 if action==1 else 31032)
            bindip='127.0.0.31' if action==1 else '127.0.0.32'
            peer=socket.create_connection((bindip,port),timeout=3)
            self.record('accepted_connections');self.pump(conn,peer)
        except (OSError,EOFError,struct.error):
            self.record('forwarding_errors');conn.close()
    def status(self,conn,_):
        import json
        try:
            with self.lock:r=dict(self.routes);s=dict(self.stats)
            conn.sendall((json.dumps({'dpid':self.dpid,'routes':r,'stats':s})+'\n').encode())
        finally:conn.close()
    def serve(self):
        threading.Thread(target=self.control,daemon=True).start()
        targets=[(p,self.on_sw1) for p in [21101,22101,21102,22102]] if self.dpid==1 else [(23000,self.on_sw2)]
        targets.append((24200+self.dpid,self.status))
        for port,cb in targets:threading.Thread(target=self.listen,args=(port,cb),daemon=True).start()
        import time
        while True:time.sleep(1)
