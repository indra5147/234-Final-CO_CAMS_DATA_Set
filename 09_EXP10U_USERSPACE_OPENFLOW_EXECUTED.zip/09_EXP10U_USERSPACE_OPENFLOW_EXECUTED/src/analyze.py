#!/usr/bin/env python3
"""Honest trial-level evaluation of real TLS + user-space OpenFlow subset."""
import csv,json,random,statistics,math,sys,hashlib
from pathlib import Path
from collections import defaultdict
ROOT=Path(__file__).resolve().parents[1]
def pct(xs,p):
 v=sorted(xs);k=(len(v)-1)*p/100;a=int(k);b=min(a+1,len(v)-1)
 return v[a]+(v[b]-v[a])*(k-a)
def bootstrap_diffs(a,b,seed=925,n=10000):
 r=random.Random(seed);v=[x-y for x,y in zip(a,b)];avg=statistics.mean(v)
 arr=[statistics.mean(v[r.randrange(len(v))] for _ in v) for _ in range(n)]
 return avg,pct(arr,2.5),pct(arr,97.5)
def main(folder):
 d=Path(folder);assert (d/'EXP10U_COMPLETED.json').exists(),'incomplete run must not be analyzed'
 rs=list(csv.DictReader((d/'policy_runs.csv').open()));ev=list(csv.DictReader((d/'service_events.csv').open()))
 audit=json.load((d/'execution_audit.json').open());assert len(rs)==audit['policy_runs'] and len(ev)==audit['service_cutovers']
 assert len(ev)==len(rs)*12 and len({r['run_id'] for r in rs})==len(rs)
 assert all(int(e['hybrid_verified'])==1 and int(e['classical_verified'])==1 and int(e['unsafe_downgrade'])==0 and int(e['deadline_expired'])==0 for e in ev)
 groups=defaultdict(list);lookup={}
 for r in rs:
  g=(r['mechanism'],r['policy']);groups[g].append(r);lookup[(int(r['trial']),*g)]=r
 summ=[]
 for (mechanism,policy),z in sorted(groups.items()):
  fs=lambda k:[float(x[k]) for x in z]
  summ.append({'mechanism':mechanism,'policy':policy,'trials':len(z),'p95_response_gap_mean_ms':statistics.mean(fs('run_p95_response_gap_ms')),'p95_response_gap_median_ms':statistics.median(fs('run_p95_response_gap_ms')),'batch_cutover_mean_ms':statistics.mean(fs('cutover_batch_ms')),'controller_staging_mean_ms':statistics.mean(fs('flow_stage_ms')),'offline_attempts_total':sum(int(x['offline_attempts']) for x in z),'session_success_rate':1.0})
 pairs=[]
 maxblocks=audit['trials']
 for mode in audit['mechanisms']:
  if (mode,'P1') in groups and (mode,'B4') in groups:
   a=[float(lookup[(t,mode,'P1')]['run_p95_response_gap_ms']) for t in range(1,maxblocks+1)]
   b=[float(lookup[(t,mode,'B4')]['run_p95_response_gap_ms']) for t in range(1,maxblocks+1)]
   mean,lo,hi=bootstrap_diffs(a,b)
   pairs.append({'contrast':'P1 minus B4','mode':mode,'metric':'run-level p95 response gap (ms)','mean_difference':mean,'ci95_lower':lo,'ci95_upper':hi,'trials':maxblocks})
 for policy in audit['policies']:
  if ('mbb',policy) in groups and ('bmb',policy) in groups:
   a=[float(lookup[(t,'mbb',policy)]['run_p95_response_gap_ms']) for t in range(1,maxblocks+1)]
   b=[float(lookup[(t,'bmb',policy)]['run_p95_response_gap_ms']) for t in range(1,maxblocks+1)]
   mean,lo,hi=bootstrap_diffs(a,b)
   pairs.append({'contrast':'MBB minus BMB','mode':policy,'metric':'run-level p95 response gap (ms)','mean_difference':mean,'ci95_lower':lo,'ci95_upper':hi,'trials':maxblocks})
 for fn,arr in [('summary.csv',summ),('paired_95CI.csv',pairs)]:
  if arr:
   with (d/fn).open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(arr[0]));w.writeheader();w.writerows(arr)
 report=[f"# User-space OpenFlow13 SDN experiment — {d.name}","",f"**Actual executions:** {len(rs)} policy runs, {len(ev)} authenticated TLS cutovers across {maxblocks} paired blocks.","","## Environment and interpretation","- OpenFlow 1.3 HELLO, FEATURES, FLOW_MOD (OXM), BARRIER are real binary wire messages over TCP.","- C0 controller programs SW1/SW2 restricted Python user-space virtual forwarding tables. They gate two-hop connections with default deny.","- Endpoints exchange actual OpenSSL 3.5.5 TLS 1.3 X25519 and X25519MLKEM768 PING/PONG payloads.","- **This is not ONOS/OVS, Mininet, kernel/ASIC Ethernet packet switching, real link congestion, seven independent VMs, or H1.0 physical hardware.**", "- No flow statistics via OFPMP, no Ethernet packet parsing: flow route matches use restricted virtual TCP destination labels and output ports. The dataplane TCP relays preserve end-to-end TLS bytes.","- Policy input load is configured, not an observed physical utilization measurement.","- Per-service response gap is between last old and first hybrid acknowledgment, not full service-unavailable duration.","- Repeated runs share a machine; results are local exploratory evidence only.","","## Mean run-level measured outcomes","","| Mode | Policy | Runs | Mean run-p95 response gap (ms) | Mean cutover batch (ms) | Controller staging (ms) |", "|---|---|---:|---:|---:|---:|"]
 for s in summ:report.append(f"| {s['mechanism']} | {s['policy']} | {s['trials']} | {s['p95_response_gap_mean_ms']:.3f} | {s['batch_cutover_mean_ms']:.2f} | {s['controller_staging_mean_ms']:.3f} |")
 report.extend(['','## Paired comparisons (block bootstrap, 95% CI)','', '| Comparison | Mode/policy | Mean difference (ms) | 95% CI (ms) |','|---|---|---:|---|'])
 for p in pairs: report.append(f"| {p['contrast']} | {p['mode']} | {p['mean_difference']:+.3f} | {p['ci95_lower']:+.3f} to {p['ci95_upper']:+.3f} |")
 report+=['','## Proof of programmed forwarding',f"- Controller logged {audit['control_flow_event_count']} flow and switch-lifecycle events.",f"- Final switch 1: {audit['switch_status_after']['1']}",f"- Final switch 2: {audit['switch_status_after']['2']}",'- Before FLOW_MOD, hybrid route attempts dropped; when rules were installed, verified hybrid TLS worked; after delete, hybrid routes again dropped.','- No unauthorized downgrade or deadline expiry in complete runs.','- These are not comparisons against an externally published SDN implementation.','- Controller staging time is measured separately from TLS cutover batch time, and application response gaps should not be interpreted as full network downtime.']
 (d/'REPORT.md').write_text('\n'.join(report)+'\n')
 try:
  import matplotlib;matplotlib.use('Agg')
  import matplotlib.pyplot as plt
  allm=[p for p in audit['policies'] if ('mbb',p) in groups and ('bmb',p) in groups]
  if allm:
   fig,ax=plt.subplots(figsize=(9,5));x=list(range(len(allm)))
   for mode,shift in [('bmb',-.18),('mbb',.18)]:
    vals=[next(s for s in summ if s['mechanism']==mode and s['policy']==p)['p95_response_gap_mean_ms'] for p in allm]
    ax.bar([i+shift for i in x],vals,width=.34,label='Break-before-make' if mode=='bmb' else 'Make-before-break')
   ax.set_xticks(x,allm);ax.set_ylabel('Mean run-level p95 acknowledgment gap (ms)');ax.set_xlabel('Scheduling policy');ax.legend(loc='upper right');ax.grid(axis='y',alpha=.15);fig.tight_layout();fig.savefig(d/'measured_TLS_response_gap.png',dpi=300);plt.close(fig)
 except Exception as ex:(d/'PLOT_ERROR.txt').write_text(repr(ex))
 files={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in d.iterdir() if p.is_file() and p.name!='SHA256_MANIFEST.json'}
 (d/'SHA256_MANIFEST.json').write_text(json.dumps(files,indent=2))
 print(json.dumps({'verified_policy_rows':len(rs),'verified_service_events':len(ev),'pairs':pairs},indent=2))
if __name__=='__main__':main(sys.argv[1])
