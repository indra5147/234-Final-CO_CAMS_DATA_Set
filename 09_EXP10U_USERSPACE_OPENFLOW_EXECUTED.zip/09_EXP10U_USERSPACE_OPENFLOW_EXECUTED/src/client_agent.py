"""One CL1/CL2 user-space client-pool role controlling live C/OpenSSL workers."""
import sys,json,subprocess,threading,http.server,os
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
ROLE=sys.argv[1];IDX=1 if ROLE=='CL1' else 2
class H(http.server.BaseHTTPRequestHandler):
    sessions={};lock=threading.Lock()
    def log_message(self,*args):pass
    def reply(self,status,value):
        s=json.dumps(value).encode();self.send_response(status);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(s)));self.end_headers();self.wfile.write(s)
    def do_POST(self):
        import time
        try:
            n=int(self.headers.get('Content-Length','0'));d=json.loads(self.rfile.read(n));key=d['id']
            with self.lock:
                if self.path=='/start':
                    if key in self.sessions:raise ValueError('duplicate id')
                    cmd=[str(ROOT/'bin/tls_app'),'client','--host','127.0.0.1','--old-port',str(21100+IDX),'--new-port',str(22100+IDX),'--ca',str(ROOT/'certs/server.crt'),'--mode',d.get('mode','mbb'),'--period-us',str(d.get('period_us',2400)),'--deadline-ms',str(d.get('deadline_ms',800))]
                    p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,bufsize=1)
                    ready=p.stdout.readline().strip()
                    if not ready.startswith('READY classical_verified=1'):
                        err=p.stderr.read(300);p.kill();raise RuntimeError('classical TLS failed '+ready+' '+err)
                    self.sessions[key]=p;self.reply(200,{'ready':True,'id':key});return
                p=self.sessions[key]
                if self.path=='/migrate':
                    p.stdin.write('MIGRATE\n');p.stdin.flush();line=p.stdout.readline().strip()
                    if not line.startswith('MIGRATED ok=1'):
                        raise RuntimeError('hybrid cutover failed '+line)
                    self.reply(200,{'hybrid_verified':True,'id':key});return
                if self.path=='/stop':
                    p.stdin.write('STOP\n');p.stdin.flush();line=p.stdout.readline().strip();p.stdin.close();rc=p.wait(timeout=4)
                    del self.sessions[key]
                    if not line.startswith('RESULT ') or rc!=0:raise RuntimeError(f'stop error {rc}: {line}')
                    self.reply(200,dict(json.loads(line[7:]),id=key));return
            self.reply(404,{'error':'unknown path'})
        except Exception as e:self.reply(500,{'error':str(e)})
if __name__=='__main__':
    print(json.dumps({'role':ROLE,'ready':True,'pid':os.getpid()}),flush=True)
    http.server.ThreadingHTTPServer(('127.0.0.1',24300+IDX),H).serve_forever()
