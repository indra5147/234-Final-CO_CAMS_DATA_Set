from pathlib import Path
import zipfile,hashlib,json,datetime,subprocess
R=Path(__file__).resolve().parent
out=R.parent/'EXP10U_Actual_UserSpace_OpenFlow13_TLS_Executed_320Runs.zip'
include=[]
for p in [R/'README.md',R/'run_tests.sh',R/'EXP10U_Executed_Results_320_Runs.xlsx']:
 include.append(p)
for p in (R/'src').glob('*.py'):include.append(p)
include.append(R/'src/tls_app.c')
for p in (R/'tests').glob('test_*.py'):include.append(p)
for trial in ['controlled_30blocks_5policies_2mechanisms','high_signal_10blocks_mbb_B4_P1','smoke_nodelay']:
 folder=R/'results'/trial
 assert (folder/'EXP10U_COMPLETED.json').exists(),f'incomplete {trial}'
 for p in folder.iterdir():
  if p.is_file():include.append(p)
for name in ['main_30blocks.log','main_30blocks.exit','high_signal_10blocks.log','high_signal_analysis.log','analysis_30blocks.json','unit_tests.log','smoke_nodelay.log']:
 p=R/'logs'/name
 if p.exists():include.append(p)
manifest={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in include}
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for p in sorted(include):z.write(p,'EXP10U_UserSpace_OpenFlow13_Executed/'+str(p.relative_to(R)))
 z.writestr('EXP10U_UserSpace_OpenFlow13_Executed/ARTIFACT_MANIFEST_SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(include)+1
 errors=[]
 for member, sha in manifest.items():
  data=z.read('EXP10U_UserSpace_OpenFlow13_Executed/'+member)
  if hashlib.sha256(data).hexdigest()!=sha:errors.append(member)
 assert not errors
print(json.dumps({'zip':str(out),'size_bytes':out.stat().st_size,'files_verified':len(include),'sha256':hashlib.sha256(out.read_bytes()).hexdigest()},indent=2))
