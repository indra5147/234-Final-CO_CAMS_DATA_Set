# Original GitHub TLS Data: Verified Analysis and Offline SDN–PQC Migration Scheduling Replay
**Research:** Controller-Orchestrated Crypto-Agile Post-Quantum Migration for Scalable Software-Defined Networks
**Status:** External dataset verification completed; offline model-based trace replay completed. **No physical SDN hardware, actual live-service cutover, or security validation was performed in this replay.**

## 1. Source provenance and integrity
- Repository: https://github.com/usama0print/pqc-tls-benchmarking
- Pinned commit: `7a74485a533da9ec7f4adccc644d05c69cf2ddae`
- Uploaded archive includes 18 original CSV files, six cryptographic groups and three scenario labels, each containing 1,000 positive observed latency measurements (18,000 original records).
- All 18 file byte lengths and Git blob SHA-1 values match the pinned GitHub repository. Two typographical SHA-1 errors in the **earlier downloader kit inventory** were corrected against the actual GitHub tree: `results_20260309_190101.csv` and `results_20260309_204513.csv`; source CSV bytes were not changed.
- `source_csv/` retains byte-for-byte matching original CSV measurements. `external_raw_normalized_18000.csv` is a normalized copy with source scenario and group fields.
- The original benchmark measures elapsed time around a shell command invoking `openssl s_client`, so observations include command/process overhead; **they are not isolated handshake latency measured at the TLS API**. The authors describe localhost/broadband/intercontinental scenario groups, but the raw CSV files do not provide timestamps for individual packet transfers or live service migrations.
- Source is a public academic-project GitHub repository, *not* the Montenegro et al. journal paper dataset and *not* an SDN migration ground-truth dataset.

## 2. Original TLS observations (from 1,000 records per group/scenario)
| Scenario | X25519 mean (ms) | Hybrid mean (ms) | Hybrid minus classical (ms) | Relative overhead | Hybrid p95 (ms) |
|---|---:|---:|---:|---:|---:|
| localhost | 21.87 | 29.76 | +7.89 | +36.1% | 45.26 |
| broadband | 60.87 | 74.54 | +13.67 | +22.5% | 98.74 |
| intercontinental | 328.24 | 342.95 | +14.71 | +4.5% | 369.59 |

## 3. Replay design: trace-driven counterfactual, not live measured superiority
1. Every original algorithm/scenario dataset is seeded-shuffled and separated into 200 calibration records and 800 held-out records. Calibration is used only to estimate the hybrid cutover duration for scheduler ordering; replay durations are selected from held-out original observations.
2. A replay contains 12 modeled services. Four profiles were tested: 12 localhost services, 12 broadband services, 12 intercontinental services, and a mixed profile with four of each.
3. For each profile, 500 matched bootstrap workload draws were evaluated with B1/B2/B3/B4/P1, plus an explicit concurrency-equalized P1 ordering ablation. Every method within each draw receives the **exact same source observation assigned to each job**.
4. Original 800 held-out observations per source are reused across the 500 draws; replay blocks are **not independent physical experiments** and percentile ranges below are descriptive dispersions, *not inferential real-hardware confidence intervals*.
5. A modeled job duration equals a sampled original hybrid TLS command-latency observation. Batch finish is the maximum duration in a concurrent wave. Job finish is batch start plus the sampled duration; no network interference or resource contention is represented.
6. Frozen workload-only inputs not in GitHub: each job has synthetic priority `1+(i%5)`, synthetic load `(.13*i)%1`, and synthetic deadline `700+31*i ms` for job IDs S01–S12; global scheduling load signal is set to 0.62 (not measured link utilization).
7. Policies: B1 uses fixed input order/4-concurrent waves, B2 fixed batch 2 plus 10 ms between waves, B3 fixed rate 1 plus 8 ms between jobs, B4 synthetic service-load-sorted/4-concurrent, P1 synthetic deadline/priority-based/2-concurrent under the fixed load signal. The P1_ORDER4_ABLATION runs the same P1 ordering with 4-concurrent waves to isolate the concurrency penalty.
8. The primary locked scientific endpoint **p95 actual application service disruption cannot be computed from these GitHub CSVs**. The replay reports only model-based schedule makespan, job completion from global start, priority-weighted finish, and synthetic deadline violations, and these MUST NOT be relabeled as actual downtime or service SLO performance.

## 4. Mixed-profile modeled result (500 matched replay draws per method)
| Method | Mean schedule makespan (ms) | Mean per-draw p95 job finish (ms) | Priority-weighted finish (ms) | Synthetic deadline misses / draw | Operating concurrency |
|---|---:|---:|---:|---:|---:|
| B1 | 489.18 | 479.45 | 192.14 | 0.000 | 4 |
| B2 | 984.70 | 975.30 | 333.12 | 0.088 | 2 |
| B3 | 1876.67 | 1683.59 | 550.81 | 3.004 | 1 |
| B4 | 1036.90 | 895.73 | 436.62 | 0.154 | 4 |
| P1 | 1267.68 | 1259.81 | 907.49 | 6.194 | 2 |
| P1_ORDER4_ABLATION | 785.66 | 778.55 | 532.91 | 0.056 | 4 |

## 5. P1 versus B4 interpretation
- Modeled schedule makespan: mean P1−B4 = **+230.78 ms**; between-replay 2.5th–97.5th percentile range of differences: [+184.34, +298.45] ms.
- Synthetic priority-weighted job finish: mean P1−B4 = **+470.86 ms**; between-replay 2.5th–97.5th percentile range of differences: [+445.47, +518.48] ms.
- Modeled p95 job finish: mean P1−B4 = **+364.08 ms**; between-replay 2.5th–97.5th percentile range of differences: [+328.77, +407.79] ms.
- P1 ordering with 4 concurrency: modeled makespan: mean P1−B4 = **-251.24 ms**; between-replay 2.5th–97.5th percentile range of differences: [-278.62, -206.56] ms.
- Under the locked *replay* operating rules (P1 concurrency=2 versus B4 concurrency=4), P1 did not outperform B4. P1 ordering alone at concurrency 4 achieves a faster modeled makespan than B4 under this specific cost/ordering assumption, but has worse modeled priority-weighted completion. This illustrates a **trade-off**, not verified superiority.
- The original source offers latency observations only; it cannot validate real application disruption, migration correctness, security-policy enforcement, hardware utilization, or fault-recovery behavior.

## 6. Files and reproduction
`source_csv/` (unaltered GitHub originals); `verified_source_inventory_corrected.csv`; `results/external_raw_normalized_18000.csv`; `results/external_tls_summary_18.csv`; `results/trace_replay_policy_runs_12000.csv`; `results/trace_replay_job_events_144000.csv`; `results/matched_P1_B4_differences_2000.csv`; `results/trace_replay_policy_summary_24.csv`; graphs; source script.

Recompute from the delivered package source CSV files: `python3 scripts/replay_original.py` followed by `python3 scripts/create_report.py`. Python requires NumPy/Matplotlib for reporting. No external network requests required.

**Research next steps:** Implement live cutover with endpoint migration agents, equalize measured operating limits, instrument actual service downtime, and repeat on ONOS/OVS physical H1.0. Do not use replay outputs as measured journal-performance results.
