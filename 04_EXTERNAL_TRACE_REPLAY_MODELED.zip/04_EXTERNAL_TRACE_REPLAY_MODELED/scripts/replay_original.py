#!/usr/bin/env python3
"""Reproducible OFFLINE trace-driven scheduling using uploaded third-party TLS latency CSVs.
NOT a real SDN, runtime migration, outage, or hardware experiment. No fabricated measurements.
"""
import csv, io, hashlib, json, math, random, shutil, statistics, zipfile
from pathlib import Path
from collections import defaultdict
import numpy as np

ROOT=Path(__file__).resolve().parent.parent
SRC_ZIP=Path('/mnt/data/pqc-tls-benchmarking-7a74485a533da9ec7f4adccc644d05c69cf2ddae.zip')
INVENTORY=ROOT/'verified_source_inventory_corrected.csv'
# Enable replay from delivered bundle without /mnt/data upstream files
if not INVENTORY.exists(): INVENTORY=ROOT/'verified_source_inventory.csv'
SEED=20261028
N_TRIALS=500
PROFILES=('localhost','broadband','intercontinental','mixed')
POLICIES=('B1','B2','B3','B4','P1','P1_ORDER4_ABLATION')
COST_GROUP='X25519MLKEM768'

def write_csv(path, rows, fields):
    with Path(path).open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(rows)

def read_csv(path):
    with Path(path).open(newline='',encoding='utf-8') as f:return list(csv.DictReader(f))

def digest_git(b):
    return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()

def read_originals():
    inventory=read_csv(INVENTORY)
    z=zipfile.ZipFile(SRC_ZIP) if SRC_ZIP.exists() else None
    data=defaultdict(list); sums=[]; normalized=[]; verified=0
    for rec in inventory:
        path=rec['path']; output=ROOT/'source_csv'/Path(path).name
        if z is not None:
            names=[n for n in z.namelist() if n.endswith('/'+path)]
            if len(names)!=1:raise RuntimeError('Missing / ambiguous ZIP member '+path)
            b=z.read(names[0]);output.write_bytes(b)
        else:b=output.read_bytes()
        sha=digest_git(b)
        if sha!=rec['git_blob_sha1'] or len(b)!=int(rec['expected_bytes']):
            raise RuntimeError(f'Git data integrity failed: {path}; {sha}')
        verified+=1
        rows=list(csv.DictReader(io.StringIO(b.decode('utf-8-sig'))))
        if len(rows)!=1000:raise RuntimeError(f'Wrong row count {path}: {len(rows)}')
        vals=[]
        for i,r in enumerate(rows,1):
            if r['group']!=rec['algorithm']:raise RuntimeError('Group mismatch in '+path)
            if int(r['id'])!=i:raise RuntimeError('ID mismatch '+path)
            latency=float(r['latency_ms'])
            if not math.isfinite(latency) or latency<=0:raise RuntimeError('Invalid latency in '+path)
            vals.append(latency)
            normalized.append({'scenario':rec['scenario'],'group':rec['algorithm'],'id':i,'latency_ms':latency,'original_file':Path(path).name})
        data[(rec['scenario'],rec['algorithm'])]=vals
        q=np.percentile(vals,[50,95,99]);sums.append({'scenario':rec['scenario'],'group':rec['algorithm'],'n':len(vals),'mean_ms':round(statistics.mean(vals),5),'median_ms':round(float(q[0]),5),'p95_ms':round(float(q[1]),5),'p99_ms':round(float(q[2]),5),'min_ms':min(vals),'max_ms':max(vals),'std_ms':round(statistics.stdev(vals),5),'source_blob_sha1':sha,'file':Path(path).name})
    if verified!=18 or len(normalized)!=18000:raise RuntimeError(f'Bad inventory: {verified} {len(normalized)}')
    write_csv(ROOT/'results'/'external_raw_normalized_18000.csv',normalized,['scenario','group','id','latency_ms','original_file'])
    write_csv(ROOT/'results'/'external_tls_summary_18.csv',sums,list(sums[0]))
    write_csv(ROOT/'verified_source_inventory.csv',inventory,list(inventory[0]))
    return data,sums,verified

def jobs_layout(profile,means):
    # Same fixed 12-service topology and synthetic job attributes for all policies.
    scenarios=([profile]*12 if profile!='mixed' else ['localhost']*4+['broadband']*4+['intercontinental']*4)
    jobs=[]
    for i,s in enumerate(scenarios,1):
        jobs.append({'id':f'S{i:02d}','scenario':s,'priority':1+(i%5),'service_load':(.13*i)%1,'deadline_ms':700+31*i,'estimated_cutover_ms':round(means[s],3)})
    return jobs

def to_batches(jobs,policy, load_signal=0.62, max_parallel=4):
    if policy=='B1': ranked=jobs; n=4; pace=0
    elif policy=='B2':ranked=jobs; n=2;pace=10
    elif policy=='B3':ranked=jobs; n=1;pace=8
    elif policy=='B4':ranked=sorted(jobs,key=lambda j:(j['service_load'],j['id']));n=4;pace=0
    elif policy.startswith('P1'):
        ranked=sorted(jobs,key=lambda j:(j['deadline_ms']-j['estimated_cutover_ms'],-j['priority'],j['service_load'],j['id']))
        n=4 if policy=='P1_ORDER4_ABLATION' else (1 if load_signal>=.75 else 2 if load_signal>=.50 else 4)
        pace=0
    else:raise ValueError(policy)
    return [ranked[i:i+n] for i in range(0,len(ranked),n)], pace,n

def simulate(jobs, durations, policy):
    batches,pace,window=to_batches(jobs,policy)
    events=[];t=0.0
    for bix,batch in enumerate(batches,1):
        start=t
        for j in batch:
            d=durations[j['id']]
            events.append({'job':j['id'],'scenario':j['scenario'],'priority':j['priority'],'service_load_input':round(j['service_load'],5),'synthetic_deadline_ms':j['deadline_ms'],'observed_source_tls_latency_ms':d,'modeled_start_ms':round(start,5),'modeled_finish_ms':round(start+d,5),'modeled_deadline_miss':int(start+d>j['deadline_ms']),'batch_number':bix})
        t+=max(durations[j['id']] for j in batch)
        if bix<len(batches):t+=pace
    ps=np.array([e['modeled_finish_ms'] for e in events]);pri=np.array([e['priority'] for e in events]);p95=float(np.percentile(ps,95))
    results={'modeled_makespan_ms':round(t,5),'modeled_p95_job_finish_ms':round(p95,5),'modeled_priority_weighted_finish_ms':round(float(np.average(ps,weights=pri)),5),'modeled_deadline_miss_count':sum(e['modeled_deadline_miss'] for e in events),'scheduler_window':window,'batch_count':len(batches),'batch_pacing_ms':pace}
    return results,events

def percentile_mean_ci(diffs):
    a=np.asarray(diffs,dtype=float)
    return round(float(np.mean(a)),5),round(float(np.percentile(a,2.5)),5),round(float(np.percentile(a,97.5)),5)

def execute():
    data,source_summary,verified=read_originals()
    # First 200 shuffled per source dataset calibration; remaining 800 held-out.
    rng_split=random.Random(SEED+17)
    cal={};test={};means={}
    for (sc,g),values in data.items():
        indexes=list(range(len(values)));rng_split.shuffle(indexes)
        cal[(sc,g)]=[values[k] for k in indexes[:200]]
        test[(sc,g)]=[values[k] for k in indexes[200:]]
    for sc in PROFILES[:3]:means[sc]=statistics.mean(cal[(sc,COST_GROUP)])
    rng=random.Random(SEED)
    run_rows=[];event_rows=[];pairs=[]
    for profile in PROFILES:
        template=jobs_layout(profile,means)
        for trial in range(1,N_TRIALS+1):
            # Same 12 sampled source observations for B1,B2,B3,B4,P1 and ablation.
            duration={j['id']:rng.choice(test[(j['scenario'],COST_GROUP)]) for j in template}
            # Classical context separately sampled; not taken as paired per-connection difference.
            classical={j['id']:rng.choice(test[(j['scenario'],'X25519')]) for j in template}
            outcomes={}
            for p in POLICIES:
                m,es=simulate(template,duration,p);outcomes[p]=m
                run_rows.append({'scenario_profile':profile,'trace_trial':trial,'policy':p,'n_services':len(template),'source_measurement_group':COST_GROUP,'external_held_out_pool_size_per_scenario':800,**m})
                for ev in es:event_rows.append({'scenario_profile':profile,'trace_trial':trial,'policy':p,**ev,'classical_unpaired_reference_ms':classical[ev['job']]})
            b=outcomes['B4'];p=outcomes['P1'];p4=outcomes['P1_ORDER4_ABLATION']
            pairs.append({'scenario_profile':profile,'trace_trial':trial,
              'P1_minus_B4_makespan_ms':round(p['modeled_makespan_ms']-b['modeled_makespan_ms'],5),
              'P1_minus_B4_priority_finish_ms':round(p['modeled_priority_weighted_finish_ms']-b['modeled_priority_weighted_finish_ms'],5),
              'P1_minus_B4_p95_finish_ms':round(p['modeled_p95_job_finish_ms']-b['modeled_p95_job_finish_ms'],5),
              'P1_minus_B4_deadline_misses':p['modeled_deadline_miss_count']-b['modeled_deadline_miss_count'],
              'P1_Order4_minus_B4_makespan_ms':round(p4['modeled_makespan_ms']-b['modeled_makespan_ms'],5),
              'P1_Order4_minus_B4_priority_finish_ms':round(p4['modeled_priority_weighted_finish_ms']-b['modeled_priority_weighted_finish_ms'],5)})
    write_csv(ROOT/'results'/'trace_replay_policy_runs_12000.csv',run_rows,list(run_rows[0]))
    write_csv(ROOT/'results'/'trace_replay_job_events_144000.csv',event_rows,list(event_rows[0]))
    write_csv(ROOT/'results'/'matched_P1_B4_differences_2000.csv',pairs,list(pairs[0]))
    summary=[]
    for profile in PROFILES:
        for p in POLICIES:
            rr=[r for r in run_rows if r['scenario_profile']==profile and r['policy']==p]
            summary.append({'scenario_profile':profile,'policy':p,'replay_trials':len(rr),
               'mean_modeled_makespan_ms':round(statistics.mean(r['modeled_makespan_ms'] for r in rr),4),
               'mean_modeled_p95_job_finish_ms':round(statistics.mean(r['modeled_p95_job_finish_ms'] for r in rr),4),
               'mean_modeled_priority_finish_ms':round(statistics.mean(r['modeled_priority_weighted_finish_ms'] for r in rr),4),
               'mean_modeled_deadline_misses':round(statistics.mean(r['modeled_deadline_miss_count'] for r in rr),4),
               'max_concurrent_jobs':rr[0]['scheduler_window']})
    write_csv(ROOT/'results'/'trace_replay_policy_summary_24.csv',summary,list(summary[0]))
    pairedsummary=[]
    for profile in PROFILES:
        sub=[p for p in pairs if p['scenario_profile']==profile]
        for metric in [k for k in pairs[0] if k not in ('scenario_profile','trace_trial')]:
            vals=[r[metric] for r in sub];m,qlo,qhi=percentile_mean_ci(vals)
            pairedsummary.append({'scenario_profile':profile,'metric':metric,'mean_paired_diff_ms_or_count':m,'trial_difference_q2_5':qlo,'trial_difference_q97_5':qhi,'n_matched_replay_trials':len(vals)})
    write_csv(ROOT/'results'/'paired_differences_descriptive_24.csv',pairedsummary,list(pairedsummary[0]))
    metadata={'source_repository':'https://github.com/usama0print/pqc-tls-benchmarking','commit':'7a74485a533da9ec7f4adccc644d05c69cf2ddae','verified_git_blob_sha_file_count':verified,'source_csv':18,'source_record_count':sum(len(v) for v in data.values()),'random_seed':SEED,'calibration_rows_per_original_csv':200,'held_out_rows_per_original_csv':800,'latency_group_replayed':COST_GROUP,'trials_per_profile':N_TRIALS,'profiles':PROFILES,'policies':POLICIES,'total_replay_policy_runs':len(run_rows),'total_replay_job_rows':len(event_rows),'scheduling_load_signal':0.62,'data_status':'EXTERNAL_RECORDED_TLS_LATENCY_INPUTS__OFFLINE_COUNTERFACTUAL_SCHEDULING_OUTPUT','critical_limits':['Source measures full openssl s_client shell execution time, NOT isolated handshake time','No true service migration; no actual SDN OpenFlow, OVS, ONOS, physical H1.0, link load, security enforcement or downtime','500 replay draws reuse held-out 800 observed latencies; they are not new independent experimental samples','No source-derived SLA priorities, service loads, or deadlines: these are frozen synthetic job assumptions','No modeled concurrency contention or link latency; individual TLS durations are used as if they were job costs','P1 operating concurrency 2 at artificial load signal 0.62 while B4 uses 4; P1_ORDER4_ABLATION equalizes concurrency for sensitivity only','Classical and hybrid measurements were from different independent runs and cannot be treated as paired timings','Quoted paired percentiles are empirical dispersion across replay samples, not confidence intervals for real-world impact']}
    (ROOT/'results'/'replay_metadata.json').write_text(json.dumps(metadata,indent=2))
    print(json.dumps({'metadata':metadata,'mixed_summary':[r for r in summary if r['scenario_profile']=='mixed'],'mixed_pairs':[r for r in pairedsummary if r['scenario_profile']=='mixed']},indent=2))

if __name__=='__main__':execute()
