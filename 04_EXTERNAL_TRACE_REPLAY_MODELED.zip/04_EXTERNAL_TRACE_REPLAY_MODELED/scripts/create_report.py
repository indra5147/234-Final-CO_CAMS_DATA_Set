from pathlib import Path
import csv,json,collections,statistics,hashlib
import numpy as np
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent.parent
D=ROOT/'results'

def data(name):
 with (D/name).open(newline='',encoding='utf-8') as f:return list(csv.DictReader(f))
orig=data('external_tls_summary_18.csv'); runs=data('trace_replay_policy_summary_24.csv');paired=data('paired_differences_descriptive_24.csv');metadata=json.loads((D/'replay_metadata.json').read_text())
# Figure 1: independent external TLS latency results
scs=['localhost','broadband','intercontinental']; names=['X25519','X25519MLKEM768']
values=np.array([[float(next(r['mean_ms'] for r in orig if r['scenario']==sc and r['group']==g)) for sc in scs] for g in names]);
fig,ax=plt.subplots(figsize=(9.0,5.0));idx=np.arange(3);width=.34
for i,g in enumerate(names):
 b=ax.bar(idx+(i-.5)*width,values[i],width,label=g)
 ax.bar_label(b,fmt='%.1f',padding=2,fontsize=9)
ax.set_xticks(idx,labels=['Localhost','Broadband','Intercontinental']);ax.set_ylabel('Observed command-level TLS latency (ms)');ax.set_title('Original GitHub measurements — 1,000 records per group and scenario');ax.legend();ax.grid(axis='y',alpha=.15);fig.tight_layout();fig.savefig(D/'external_original_means.png',dpi=240,bbox_inches='tight');plt.close(fig)
# Figure2: model-only replay under mixed source
sub=[r for r in runs if r['scenario_profile']=='mixed' and r['policy']!='P1_ORDER4_ABLATION']
labels=[r['policy'] for r in sub]; vals=[float(r['mean_modeled_makespan_ms']) for r in sub]
fig,ax=plt.subplots(figsize=(9,5));bars=ax.bar(labels,vals);ax.bar_label(bars,fmt='%.1f',padding=3,fontsize=9);ax.set_ylabel('Modeled schedule makespan (ms)');ax.set_title('Mixed external-latency trace replay — 500 draws per strategy');ax.grid(axis='y',alpha=.15);fig.tight_layout();fig.savefig(D/'modeled_makespan_comparison.png',dpi=240,bbox_inches='tight');plt.close(fig)
# Figure3: test explain fairness factor concurrency
sub=[r for r in runs if r['scenario_profile']=='mixed' and r['policy'] in ['B4','P1','P1_ORDER4_ABLATION']]
fig,ax=plt.subplots(figsize=(8,4.5));bars=ax.bar(['B4 (4 parallel)','P1 (2 parallel)','P1 order only (4 parallel)'],[float(r['mean_modeled_makespan_ms']) for r in sub]);ax.bar_label(bars,fmt='%.1f',padding=3,fontsize=9);ax.set_ylabel('Modeled schedule makespan (ms)');ax.set_title('Concurrency sensitivity: scheduling order versus operating window');ax.grid(axis='y',alpha=.15);fig.tight_layout();fig.savefig(D/'concurrency_sensitivity.png',dpi=240,bbox_inches='tight');plt.close(fig)
lines=[]
lines.append('# Original GitHub TLS Data: Verified Analysis and Offline SDN–PQC Migration Scheduling Replay')
lines.append('**Research:** Controller-Orchestrated Crypto-Agile Post-Quantum Migration for Scalable Software-Defined Networks')
lines.append('**Status:** External dataset verification completed; offline model-based trace replay completed. **No physical SDN hardware, actual live-service cutover, or security validation was performed in this replay.**')
lines.append('')
lines.append('## 1. Source provenance and integrity')
lines.append('- Repository: https://github.com/usama0print/pqc-tls-benchmarking')
lines.append('- Pinned commit: `7a74485a533da9ec7f4adccc644d05c69cf2ddae`')
lines.append('- Uploaded archive includes 18 original CSV files, six cryptographic groups and three scenario labels, each containing 1,000 positive observed latency measurements (18,000 original records).')
lines.append('- All 18 file byte lengths and Git blob SHA-1 values match the pinned GitHub repository. Two typographical SHA-1 errors in the **earlier downloader kit inventory** were corrected against the actual GitHub tree: `results_20260309_190101.csv` and `results_20260309_204513.csv`; source CSV bytes were not changed.')
lines.append('- `source_csv/` retains byte-for-byte matching original CSV measurements. `external_raw_normalized_18000.csv` is a normalized copy with source scenario and group fields.')
lines.append('- The original benchmark measures elapsed time around a shell command invoking `openssl s_client`, so observations include command/process overhead; **they are not isolated handshake latency measured at the TLS API**. The authors describe localhost/broadband/intercontinental scenario groups, but the raw CSV files do not provide timestamps for individual packet transfers or live service migrations.')
lines.append('- Source is a public academic-project GitHub repository, *not* the Montenegro et al. journal paper dataset and *not* an SDN migration ground-truth dataset.')
lines.append('')
lines.append('## 2. Original TLS observations (from 1,000 records per group/scenario)')
lines.append('| Scenario | X25519 mean (ms) | Hybrid mean (ms) | Hybrid minus classical (ms) | Relative overhead | Hybrid p95 (ms) |')
lines.append('|---|---:|---:|---:|---:|---:|')
for sc in scs:
 a=next(r for r in orig if r['scenario']==sc and r['group']=='X25519');b=next(r for r in orig if r['scenario']==sc and r['group']=='X25519MLKEM768')
 x=float(a['mean_ms']);y=float(b['mean_ms']);lines.append(f'| {sc} | {x:.2f} | {y:.2f} | {y-x:+.2f} | {(y/x-1)*100:+.1f}% | {float(b["p95_ms"]):.2f} |')
lines.append('')
lines.append('## 3. Replay design: trace-driven counterfactual, not live measured superiority')
lines.append('1. Every original algorithm/scenario dataset is seeded-shuffled and separated into 200 calibration records and 800 held-out records. Calibration is used only to estimate the hybrid cutover duration for scheduler ordering; replay durations are selected from held-out original observations.')
lines.append('2. A replay contains 12 modeled services. Four profiles were tested: 12 localhost services, 12 broadband services, 12 intercontinental services, and a mixed profile with four of each.')
lines.append('3. For each profile, 500 matched bootstrap workload draws were evaluated with B1/B2/B3/B4/P1, plus an explicit concurrency-equalized P1 ordering ablation. Every method within each draw receives the **exact same source observation assigned to each job**.')
lines.append('4. Original 800 held-out observations per source are reused across the 500 draws; replay blocks are **not independent physical experiments** and percentile ranges below are descriptive dispersions, *not inferential real-hardware confidence intervals*.')
lines.append('5. A modeled job duration equals a sampled original hybrid TLS command-latency observation. Batch finish is the maximum duration in a concurrent wave. Job finish is batch start plus the sampled duration; no network interference or resource contention is represented.')
lines.append('6. Frozen workload-only inputs not in GitHub: each job has synthetic priority `1+(i%5)`, synthetic load `(.13*i)%1`, and synthetic deadline `700+31*i ms` for job IDs S01–S12; global scheduling load signal is set to 0.62 (not measured link utilization).')
lines.append('7. Policies: B1 uses fixed input order/4-concurrent waves, B2 fixed batch 2 plus 10 ms between waves, B3 fixed rate 1 plus 8 ms between jobs, B4 synthetic service-load-sorted/4-concurrent, P1 synthetic deadline/priority-based/2-concurrent under the fixed load signal. The P1_ORDER4_ABLATION runs the same P1 ordering with 4-concurrent waves to isolate the concurrency penalty.')
lines.append('8. The primary locked scientific endpoint **p95 actual application service disruption cannot be computed from these GitHub CSVs**. The replay reports only model-based schedule makespan, job completion from global start, priority-weighted finish, and synthetic deadline violations, and these MUST NOT be relabeled as actual downtime or service SLO performance.')
lines.append('')
lines.append('## 4. Mixed-profile modeled result (500 matched replay draws per method)')
lines.append('| Method | Mean schedule makespan (ms) | Mean per-draw p95 job finish (ms) | Priority-weighted finish (ms) | Synthetic deadline misses / draw | Operating concurrency |')
lines.append('|---|---:|---:|---:|---:|---:|')
for r in runs:
 if r['scenario_profile']=='mixed':
  lines.append('| {policy} | {mean_modeled_makespan_ms:.2f} | {mean_modeled_p95_job_finish_ms:.2f} | {mean_modeled_priority_finish_ms:.2f} | {mean_modeled_deadline_misses:.3f} | {max_concurrent_jobs} |'.format(**{**r,**{k:float(v) for k,v in r.items() if k.startswith('mean_')}}))
lines.append('')
lines.append('## 5. P1 versus B4 interpretation')
for met,label in [('P1_minus_B4_makespan_ms','Modeled schedule makespan'),('P1_minus_B4_priority_finish_ms','Synthetic priority-weighted job finish'),('P1_minus_B4_p95_finish_ms','Modeled p95 job finish'),('P1_Order4_minus_B4_makespan_ms','P1 ordering with 4 concurrency: modeled makespan')]:
 r=next(x for x in paired if x['scenario_profile']=='mixed' and x['metric']==met)
 lines.append(f'- {label}: mean P1−B4 = **{float(r["mean_paired_diff_ms_or_count"]):+.2f} ms**; between-replay 2.5th–97.5th percentile range of differences: [{float(r["trial_difference_q2_5"]):+.2f}, {float(r["trial_difference_q97_5"]):+.2f}] ms.')
lines.append('- Under the locked *replay* operating rules (P1 concurrency=2 versus B4 concurrency=4), P1 did not outperform B4. P1 ordering alone at concurrency 4 achieves a faster modeled makespan than B4 under this specific cost/ordering assumption, but has worse modeled priority-weighted completion. This illustrates a **trade-off**, not verified superiority.')
lines.append('- The original source offers latency observations only; it cannot validate real application disruption, migration correctness, security-policy enforcement, hardware utilization, or fault-recovery behavior.')
lines.append('')
lines.append('## 6. Files and reproduction')
lines.append('`source_csv/` (unaltered GitHub originals); `verified_source_inventory_corrected.csv`; `results/external_raw_normalized_18000.csv`; `results/external_tls_summary_18.csv`; `results/trace_replay_policy_runs_12000.csv`; `results/trace_replay_job_events_144000.csv`; `results/matched_P1_B4_differences_2000.csv`; `results/trace_replay_policy_summary_24.csv`; graphs; source script.')
lines.append('')
lines.append('Recompute from the delivered package source CSV files: `python3 scripts/replay_original.py` followed by `python3 scripts/create_report.py`. Python requires NumPy/Matplotlib for reporting. No external network requests required.')
lines.append('')
lines.append('**Research next steps:** Implement live cutover with endpoint migration agents, equalize measured operating limits, instrument actual service downtime, and repeat on ONOS/OVS physical H1.0. Do not use replay outputs as measured journal-performance results.')
(D/'EXTERNAL_GITHUB_TRACE_REPLAY_REPORT.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print('Report pages written, plots:', [f.name for f in D.glob('*.png')])
