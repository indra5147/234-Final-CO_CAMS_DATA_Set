from pathlib import Path
import csv
from artifact_tool import Workbook, SpreadsheetFile
ROOT=Path(__file__).resolve().parent.parent
D=ROOT/'results'

def get(n):
 with (D/n).open(newline='',encoding='utf-8') as f:return list(csv.DictReader(f))

wb=Workbook.create()
NAVY='#10233E';BLUE='#19619A';LIGHT='#EAF2FA';TEXT='#263648';WARN='#FFF3DC'

def tab(name, rows, headers, widths, title=None, notes=None, chunk=800):
 sh=wb.worksheets.add(name)
 row=1
 if title:
  end=chr(ord('A')+len(headers)-1)
  sh.merge_cells(f'A1:{end}1');sh.get_range('A1').values=[[title]]
  sh.get_range(f'A1:{end}1').format={'fill':NAVY,'font':{'bold':True,'color':'#FFFFFF','size':14},'row_height':38,'vertical_alignment':'center'}
  row=3
  if notes:
   sh.merge_cells(f'A2:{end}2');sh.get_range('A2').values=[[notes]]
   sh.get_range(f'A2:{end}2').format={'fill':WARN,'font':{'color':'#7D4D13','size':10},'row_height':29,'wrap_text':True}
 sh.get_range_by_indexes(row-1,0,1,len(headers)).values=[headers]
 sh.get_range_by_indexes(row-1,0,1,len(headers)).format={'fill':BLUE,'font':{'bold':True,'color':'#FFFFFF','size':10},'wrap_text':True,'vertical_alignment':'center','row_height':28}
 start=row
 for i in range(0,len(rows),chunk):
  sh.get_range_by_indexes(start+i,0,len(rows[i:i+chunk]),len(headers)).values=rows[i:i+chunk]
 if rows:
  sh.get_range_by_indexes(row,0,len(rows),len(headers)).format.row_height=20
  sh.get_range_by_indexes(row,0,len(rows),len(headers)).format.font.size=10
 for i,w in enumerate(widths):
  sh.get_range_by_indexes(0,i,start+len(rows),1).format.column_width=w
 sh.freeze_panes.freeze_rows(row)
 return sh

intro=[
 ['Research','Controller-Orchestrated Crypto-Agile Post-Quantum Migration for Scalable Software-Defined Networks'],
 ['Evidence status','18,000 ORIGINAL GitHub measured command-level TLS latencies, plus OFFLINE trace-driven modeled scheduling. Not real migration downtime.'],
 ['Source','https://github.com/usama0print/pqc-tls-benchmarking'],
 ['Pinned commit','7a74485a533da9ec7f4adccc644d05c69cf2ddae'],
 ['Original files','18 CSV files × 1,000 observations = 18,000 real recorded latencies'],
 ['Verification','All 18 actual Git blob SHA-1 values checked against pinned GitHub tree; 2 earlier downloader-manifest SHA typos corrected'],
 ['Replay approach','200 calibration + 800 held-out per group/scenario; 500 bootstrap draws per profile'],
 ['Profiles','Localhost, broadband, intercontinental, mixed (4+4+4 services)'],
 ['Policy methods','B1 bulk, B2 fixed batch, B3 fixed rate, B4 greedy load aware, P1 controller scheduling, P1 4-wide ordering sensitivity'],
 ['Workload inputs','Hybrid measured costs from original source; source has NO SDN migration trace or service downtime'],
 ['Synthetic assumptions','Deadlines, service priorities, loads, 0.62 scheduling-load signal, fixed stage pacing and concurrency caps'],
 ['Primary locked endpoint','Measured p95 application service disruption: NOT AVAILABLE in these GitHub CSV files'],
 ['Important conclusion','P1 NOT shown superior. Mixed trace-replay P1 slower than B4 for modeled batch completion with concurrency 2 versus 4.'],
 ['Independent trials?','500 bootstrap trace draws per profile reuse external held-out data; NOT 500 independent hardware experiments'],
 ['Complete data','See zipped package: originals, normalized 18k CSV, 12k run rows, 144k modeled job rows, code, graphs'],
]
tab('START HERE',intro,['Item','Definition / verified limitation'],[26,113],title='External TLS GitHub Data — Verified Replay V1.0',notes='Measured dataset and modeled scheduling outcomes are intentionally separated. No physical H1.0 or ONOS experiment performed.')

source=get('external_tls_summary_18.csv')
header=['Scenario','Cryptographic group','Observations','Mean (ms)','Median (ms)','p95 (ms)','p99 (ms)','Min (ms)','Max (ms)','Std dev (ms)','Git blob SHA1','Original filename']
cols=['scenario','group','n','mean_ms','median_ms','p95_ms','p99_ms','min_ms','max_ms','std_ms','source_blob_sha1','file']
rows=[[v if key in ('scenario','group','source_blob_sha1','file') else int(v) if key=='n' else float(v) for key,v in [(k,r[k]) for k in cols]] for r in source]
tab('ORIGINAL TLS 18',rows,header,[20,23,16,17,17,15,15,14,14,16,44,29],title='Original benchmark — 18,000 recorded observations',notes='Source script times shell openssl s_client invocation, not exclusively handshake internals. Values are unchanged from the uploaded GitHub CSV.')

summary=get('trace_replay_policy_summary_24.csv')
cols=['scenario_profile','policy','replay_trials','mean_modeled_makespan_ms','mean_modeled_p95_job_finish_ms','mean_modeled_priority_finish_ms','mean_modeled_deadline_misses','max_concurrent_jobs']
headers=['Workload profile','Method','Replay draws','Modeled makespan (ms)','Modeled p95 job finish (ms)','Modeled priority finish (ms)','Synthetic deadline misses / draw','Parallel job cap']
rs=[[r[c] if c in ('scenario_profile','policy') else int(r[c]) if c in ('replay_trials','max_concurrent_jobs') else float(r[c]) for c in cols] for r in summary]
tab('REPLAY SUMMARY',rs,headers,[22,26,16,25,27,28,32,19],title='Modeled offline replay — four 500-draw workload profiles',notes='Do not cite these simulated schedule results as actual SDN service disruption or live migration performance.')

paired=get('paired_differences_descriptive_24.csv')
cols=['scenario_profile','metric','mean_paired_diff_ms_or_count','trial_difference_q2_5','trial_difference_q97_5','n_matched_replay_trials']
headers=['Profile','Difference (P1 − B4)','Mean difference','Replay distribution 2.5%','Replay distribution 97.5%','Matched draws']
rs=[[r[c] if c in ('scenario_profile','metric') else int(r[c]) if c=='n_matched_replay_trials' else float(r[c]) for c in cols] for r in paired]
tab('PAIRED P1 vs B4',rs,headers,[22,58,23,26,26,18],title='Matched input trace-replay differences',notes='Ranges describe variability across modeled draws; they are NOT physical-system confidence intervals.')

runs=get('trace_replay_policy_runs_12000.csv')
sub=[r for r in runs if r['scenario_profile']=='mixed']
cols=['trace_trial','policy','modeled_makespan_ms','modeled_p95_job_finish_ms','modeled_priority_weighted_finish_ms','modeled_deadline_miss_count','scheduler_window','batch_count','batch_pacing_ms']
headers=['Draw','Policy','Modeled makespan (ms)','Modeled p95 finish (ms)','Modeled priority finish (ms)','Synthetic misses','Operating concurrency','Waves','Configured pacing (ms)']
rs=[[r[c] if c=='policy' else int(r[c]) if c in ('trace_trial','modeled_deadline_miss_count','scheduler_window','batch_count','batch_pacing_ms') else float(r[c]) for c in cols] for r in sub]
tab('MIXED 3000 DRAWS',rs,headers,[12,24,22,23,26,20,24,12,24],title='Mixed-profile matched trace-replay rows',notes='Six policies × 500 matched draws, including optional P1 fixed-4-concurrency ordering ablation.')

manifest=get('..'+ '/verified_source_inventory.csv') if False else []
with (ROOT/'verified_source_inventory_corrected.csv').open(newline='') as f:manifest=list(csv.DictReader(f))
headers=['Scenario','Group','Original path','Bytes','GitHub blob SHA1','Pinned source URL']
cols=['scenario','algorithm','path','expected_bytes','git_blob_sha1','pinned_raw_url']
rs=[[int(r[c]) if c=='expected_bytes' else r[c] for c in cols] for r in manifest]
tab('SOURCE MANIFEST',rs,headers,[20,22,78,14,46,100],title='GitHub file identity: pinned original repository commit',notes='Earlier auxiliary downloader inventory had two SHA1 transcription mistakes, corrected here using GitHub Git tree and uploaded original file bytes.')

out=ROOT/'SDN_PQC_Original_GitHub_Trace_Replay_Comparison.xlsx'
SpreadsheetFile.export_xlsx(wb).save(str(out))
print(out,out.stat().st_size)
print(wb.inspect({'kind':'table','range':'REPLAY SUMMARY!A4:H10','include':'values,formulas','table_max_rows':8,'table_max_cols':9}).ndjson[:1000])
