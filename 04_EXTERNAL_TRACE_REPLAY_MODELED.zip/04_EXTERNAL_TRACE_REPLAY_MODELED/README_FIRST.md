# Verified GitHub TLS Latency Data + Locked SDN–PQC Scheduling Replay

**Manuscript:** Controller-Orchestrated Crypto-Agile Post-Quantum Migration for Scalable Software-Defined Networks

## Read this distinction before citing any results

- **Actual external empirical data:** 18,000 original `latency_ms` records in 18 source CSV files, downloaded by the user from the public `usama0print/pqc-tls-benchmarking` repository at pinned commit `7a74485a533da9ec7f4adccc644d05c69cf2ddae`. All 18 files verified byte-for-byte by Git blob SHA1 against the pinned GitHub file tree.
- **Derived but not measured outcomes:** B1, B2, B3, B4 and P1 offline **trace-driven scheduling calculations** derived from the original hybrid-TLS timings. **Not** an actual network migration, ONOS/OpenFlow/OVS run, packet-level emulation, or physically measured application downtime.
- **Source limitation:** The original shell benchmark measured entire `openssl s_client` command duration, including startup/shell overhead, rather than isolated handshake timing. No original service-priority, controller CPU, link utilization, QoS/SLA, or migration downtime is available.
- **Replay limitation:** Each of four scenario profiles has 500 resampled matched trial blocks from the 800 held-out timing records per original CSV. This is 12,000 modeled policy executions, including 2,000 P1 ablation runs. NOT 12,000 independent measured SDN trials.
- **Result:** The proposed locked P1 policy does NOT show overall superiority over B4 in this replay. The mixed profile's modeled batch completion is 1,267.68 ms (P1, 2 parallel) versus 1,036.90 ms (B4, 4 parallel). This comparison includes an inherent operating concurrency difference by design. P1 order-only with 4 parallel jobs produces 785.66 ms in this counterfactual scheduler, but that cannot establish real migration performance.

## Files

1. `source_csv/` — all 18 exact, original CSV files.
2. `verified_source_inventory_corrected.csv` — SHA1/blob provenance and pinned source URLs. The prior independent downloader-kit inventory had two typos, corrected against GitHub's actual tree: original source files are unchanged.
3. `results/external_raw_normalized_18000.csv` — non-destructive normalized source dataset.
4. `results/external_tls_summary_18.csv` — original source descriptive statistics.
5. `results/trace_replay_policy_runs_12000.csv` — modeled scheduling output, 4 profiles × 500 draws × 6 policies.
6. `results/trace_replay_job_events_144000.csv` — detailed modeled job completion records, **not** recorded per-service SDN event telemetry.
7. `results/matched_P1_B4_differences_2000.csv`, `results/paired_differences_descriptive_24.csv`.
8. `results/EXTERNAL_GITHUB_TRACE_REPLAY_REPORT.md` and 3 PNG plots.
9. `SDN_PQC_Original_GitHub_Trace_Replay_Comparison.xlsx` — polished summary workbook with a provenance sheet.
10. `scripts/replay_original.py` and `scripts/create_report.py` — reproducible data processing and replay, requiring Python, NumPy and Matplotlib.

Run offline: `python3 scripts/replay_original.py` then `python3 scripts/create_report.py` (from the root directory on a system with NumPy + Matplotlib). The script uses the bundled original source CSV files if the original user-uploaded ZIP isn't mounted. The Excel workbook has already been generated; it is not required to reproduce the CSV results.

**Appropriate manuscript label:** *Exploratory external TLS latency trace-driven scheduling sensitivity analysis*. It cannot replace hardware-based validation of the locked primary outcome (p95 actual application service disruption).
