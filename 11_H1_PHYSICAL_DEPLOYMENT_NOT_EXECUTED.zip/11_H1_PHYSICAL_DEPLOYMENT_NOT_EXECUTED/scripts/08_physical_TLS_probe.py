#!/usr/bin/env python3
"""Real H1.0 data-plane TLS probes from a physical CL1/CL2 ONLY.
Do NOT run outside verified physical endpoint network. This measures handshakes
only; it does not claim migration, SDN control, or P1 superiority.
"""
import argparse,csv,datetime as dt,os,random,re,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--node',required=True,choices=['CL1','CL2'])
    p.add_argument('--server',required=True,choices=['SR1','SR2'])
    p.add_argument('--pairs',type=int,default=100)
    p.add_argument('--run',action='store_true',help='Execute only on verified physical H1.0 CL1/CL2')
    a=p.parse_args()
    endpoints={'CL1':'10.10.10.11','CL2':'10.10.10.12','SR1':'10.10.10.21','SR2':'10.10.10.22'}
    if not a.run:
        print('DRY-RUN: target',a.node,'->',a.server, 'number of pairs',a.pairs)
        print('Requires real Ethernet, a hybrid and classical TLS server, demo CA copied to client. Add --run on genuine client node.')
        return 0
    if a.pairs<1 or a.pairs>10000:raise SystemExit('Invalid pair count')
    out=subprocess.check_output(['ip','-o','-4','addr','show'],text=True)
    if f'inet {endpoints[a.node]}/24' not in out:raise SystemExit('BLOCKED: not genuine H1.0 physical client data IP')
    server_ip=endpoints[a.server]
    binary=ROOT/'bin'/'tlsprobe';cert=ROOT/'certs'/'server.crt'
    if not binary.exists() or not cert.exists():raise SystemExit('Binary or CA file absent')
    result=ROOT/'results'/f'{a.node}_to_{a.server}_physical_tls.csv';result.parent.mkdir(exist_ok=True)
    rows=[];rng=random.Random(20261028)
    for i in range(a.pairs):
        gs=['X25519','X25519MLKEM768'];rng.shuffle(gs)
        for group in gs:
            port='8443' if group=='X25519' else '8444'
            cmd=[str(binary),'client','--host',server_ip,'--port',port,'--group',group,'--ca',str(cert),'--server-name','sdn-pqc.local','--tag','H1_physical_TLS_only','--trial',str(i+1)]
            p=subprocess.run(cmd,capture_output=True,text=True,timeout=14)
            field=next(csv.reader([p.stdout.strip()])) if p.stdout.strip() else []
            success=p.returncode==0 and len(field)==13 and field[5]==group and field[6]=='1' and field[10]=='1'
            rows.append([dt.datetime.now(dt.timezone.utc).isoformat(),a.node,a.server,group,port,i+1,success,field[7] if len(field)==13 else '',p.stderr.strip()[-150:]])
            if not success:raise RuntimeError('TLS validation failed; raw event:'+repr(rows[-1]))
    with result.open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['timestamp_utc','client','server','requested_group','port','trial','success','handshake_ms','stderr']);w.writerows(rows)
    print('PASS',len(rows),'physical data-plane verified TLS handshakes. FILE:',result)
    print('NOTE: no SDN migration or P1 superiority has been tested by this script.')
    return 0
if __name__=='__main__':sys.exit(main())
