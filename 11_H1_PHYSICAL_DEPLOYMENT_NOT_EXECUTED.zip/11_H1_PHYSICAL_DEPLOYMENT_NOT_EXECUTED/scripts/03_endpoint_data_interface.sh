#!/usr/bin/env bash
# Run locally on CL1 CL2 SR1 SR2 using console or mgmt SSH. Does not modify mgmt NIC.
set -euo pipefail
if [[ $# -lt 2 ]]; then echo 'Usage: 03_endpoint_data_interface.sh CL1|CL2|SR1|SR2 dataNic [--apply]';exit 2;fi
NODE="$1"; NIC="$2"; MODE="${3:---dry-run}"
case "$NODE" in CL1) IP=10.10.10.11;; CL2) IP=10.10.10.12;; SR1) IP=10.10.10.21;; SR2) IP=10.10.10.22;; *) echo 'Invalid node';exit 2;; esac
[[ "$MODE" == --apply || "$MODE" == --dry-run ]] || exit 2
ip link show dev "$NIC" >/dev/null || { echo "No such interface: $NIC";exit 3; }
if ip -o -4 addr show dev "$NIC" | grep -q '192\.168\.50\.';then echo 'BLOCKED: interface is on management LAN';exit 4;fi
if ip -4 route show default | grep -qw "dev $NIC"; then echo 'BLOCKED: current default route uses interface';exit 5;fi
printf 'Node %s: assign %s/24 to %s (mode %s)\n' "$NODE" "$IP" "$NIC" "$MODE"
if [[ "$MODE" == --dry-run ]];then exit 0;fi
[[ "$(id -u)" -eq 0 ]] || { echo 'Use sudo';exit 3; }
ip link set "$NIC" up
ip address replace "$IP/24" dev "$NIC"
ip -br addr show dev "$NIC"
echo 'NOTE: runtime interface state only. Create a persistent netplan configuration after validating; never mix management and data subnets.'
