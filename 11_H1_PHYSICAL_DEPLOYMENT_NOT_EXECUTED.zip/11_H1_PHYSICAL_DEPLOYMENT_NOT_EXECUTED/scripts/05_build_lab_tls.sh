#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
mkdir -p "$ROOT/bin" "$ROOT/certs"
cc -O2 -Wall -Wextra -std=c11 -pthread -o "$ROOT/bin/tlsprobe" "$ROOT/src/tlsprobe.c" -lssl -lcrypto
VERSION="$(openssl version)"
[[ "$VERSION" =~ OpenSSL\ 3\.[5-9]\. ]] || { echo "Requires OpenSSL 3.5+; observed $VERSION";exit 2; }
openssl list -tls1_3 -tls-groups | grep -q 'X25519MLKEM768' || { echo 'Missing hybrid group';exit 3; }
if [[ ! -e "$ROOT/certs/server.crt" ]]; then
  echo 'Creating disposable LAB ONLY demonstration certificate; regenerate in a secured lab.'
  openssl req -x509 -newkey ec -pkeyopt ec_paramgen_curve:P-256 -nodes -sha256 -days 14 \
    -subj '/CN=sdn-pqc.local' -addext 'subjectAltName=DNS:sdn-pqc.local' \
    -keyout "$ROOT/certs/server.key" -out "$ROOT/certs/server.crt" >/dev/null 2>&1
  chmod 600 "$ROOT/certs/server.key"
fi
printf 'OK %s, binary: %s\n' "$VERSION" "$ROOT/bin/tlsprobe"
echo 'CAUTION: Do not share server.key or use lab demo cert in production.'
