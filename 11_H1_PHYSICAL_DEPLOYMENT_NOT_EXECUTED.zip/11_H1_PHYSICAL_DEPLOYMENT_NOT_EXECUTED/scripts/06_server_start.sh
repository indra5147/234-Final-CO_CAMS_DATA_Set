#!/usr/bin/env bash
# Run on SR1 or SR2. Requires lab-only keys created on that server.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
NODE="${1:-}"; ACTION="${2:---dry-run}"
case "$NODE" in SR1) IP=10.10.10.21;; SR2) IP=10.10.10.22;; *) echo 'Usage: 06_server_start.sh SR1|SR2 [--dry-run|--apply]';exit 2;;esac
[[ "$ACTION" == --dry-run || "$ACTION" == --apply ]] || exit 2
printf 'Start TLS servers on %s, ports 8443 (classical) / 8444 (hybrid), mode %s\n' "$IP" "$ACTION"
if [[ "$ACTION" == --dry-run ]];then exit 0;fi
ip -o -4 addr show | grep -Fq "inet ${IP}/24" || { echo "BLOCKED: $NODE data NIC IP absent";exit 4; }
[[ -f "$ROOT/certs/server.key" && -f "$ROOT/certs/server.crt" && -x "$ROOT/bin/tlsprobe" ]] || { echo 'Run 05_build_lab_tls.sh and manage lab demo certificates first'; exit 3;}
mkdir -p "$ROOT/logs"
"$ROOT/bin/tlsprobe" server --bind "$IP" --port 8443 --group X25519 --cert "$ROOT/certs/server.crt" --key "$ROOT/certs/server.key" > "$ROOT/logs/${NODE}_classical.log" 2>&1 & echo $! > "$ROOT/logs/${NODE}_classical.pid"
"$ROOT/bin/tlsprobe" server --bind "$IP" --port 8444 --group X25519MLKEM768 --cert "$ROOT/certs/server.crt" --key "$ROOT/certs/server.key" > "$ROOT/logs/${NODE}_hybrid.log" 2>&1 & echo $! > "$ROOT/logs/${NODE}_hybrid.pid"
sleep 0.5
kill -0 "$(cat "$ROOT/logs/${NODE}_classical.pid")" && kill -0 "$(cat "$ROOT/logs/${NODE}_hybrid.pid")" && echo 'Both test servers started. Validate actual application response from CL1 and CL2.'
