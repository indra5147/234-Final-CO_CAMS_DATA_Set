#!/usr/bin/env python3
"""Real OpenSSL handshake-only SMOKE for five schedulers, on Linux loopback.
NOT real session migration. NO ONOS/OVS control. NO superiority evidence.
"""
import csv,datetime as dt,os,subprocess,sys,time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from migration_scheduler import plan,load_jobs,ALGORITHMS

def ready(port):
    import socket
    with socket.socket() as s:
        s.settimeout(0.3)
        return s.connect_ex(('127.0.0.1',port))==0

def once(job,method,round_id,port):
    cmd=[str(ROOT/'bin'/'tlsprobe'),'client','--host','127.0.0.1','--port',str(port),'--group','X25519MLKEM768','--ca',str(ROOT/'certs'/'server.crt'),'--server-name','sdn-pqc.local','--tag',method,'--trial',f'{round_id}-{job.id}']
    start=time.monotonic_ns()
    p=subprocess.run(cmd,capture_output=True,text=True,timeout=12)
    elapsed=(time.monotonic_ns()-start)/1e6
    fields=next(csv.reader([p.stdout.strip()])) if p.stdout.strip() else []
    success=p.returncode==0 and len(fields)==13 and fields[5]=='X25519MLKEM768' and fields[6]=='1' and fields[10]=='1'
    return [dt.datetime.now(dt.timezone.utc).isoformat(),'LOCAL_LOOPBACK_HANDSHAKE_SMOKE_NOT_MIGRATION',method,round_id,job.id,'X25519MLKEM768',success,round(elapsed,5),fields[7] if len(fields)==13 else '',p.stderr.strip()[-180:]]

def main():
    binary=ROOT/'bin'/'tlsprobe'; cert=ROOT/'certs'/'server.crt'; key=ROOT/'certs'/'server.key'
    if not binary.exists():raise SystemExit('Build TLS probe first: bash scripts/05_build_lab_tls.sh')
    port=19444
    logfile=(ROOT/'logs'/'local_strategy_tls_server.log').open('w')
    server=subprocess.Popen([str(binary),'server','--bind','127.0.0.1','--port',str(port),'--group','X25519MLKEM768','--cert',str(cert),'--key',str(key)],stdout=logfile,stderr=subprocess.STDOUT,start_new_session=True)
    try:
        for _ in range(100):
            if ready(port):break
            time.sleep(.03)
        else:raise RuntimeError('Loopback test server unavailable')
        records=[]
        for method in ALGORITHMS:
            for batch in plan(load_jobs(),method,observed_network_load=.62,max_parallel=4,fixed_batch=2):
                with ThreadPoolExecutor(max_workers=4) as pool:
                    records.extend(pool.map(lambda j:once(j,method,1,port),batch))
        assert len(records)==60 and all(r[6] for r in records), 'TLS smoke validation failed'
        output=ROOT/'results'/'local_B1_B4_P1_policy_handshake_SMOKE.csv'; output.parent.mkdir(parents=True,exist_ok=True)
        with output.open('w',newline='') as f:
            w=csv.writer(f)
            w.writerow(['timestamp_utc','environment','algorithm','trial','service_id','negotiated_group','tls_verified','wall_duration_ms','handshake_ms','error'])
            w.writerows(records)
        print('PASS: 60 verified real OpenSSL hybrid handshakes across B1, B2, B3, B4, P1 batch orderings (12 per policy)')
        print('This is a scheduling + TLS handshake functional smoke test on localhost. It is NOT active-session migration, NOT SDN, NOT a superiority evaluation.')
        print('Output:',output)
    finally:
        server.terminate()
        try:server.wait(timeout=3)
        except subprocess.TimeoutExpired:server.kill()
        logfile.close()

if __name__=='__main__':main()
