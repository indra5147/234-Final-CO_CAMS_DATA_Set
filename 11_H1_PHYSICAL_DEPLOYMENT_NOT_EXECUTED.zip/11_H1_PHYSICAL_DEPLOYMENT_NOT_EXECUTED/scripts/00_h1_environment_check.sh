#!/usr/bin/env bash
# Local read-only H1.0 diagnostics. Exits 2 if outside the directly attached H1.0 LAN.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
mkdir -p "$ROOT/results"
LOG="$ROOT/results/h1_environment_check.txt"
{
  echo "H1.0 management LAN preflight"
  date -u +"UTC timestamp: %Y-%m-%dT%H:%M:%SZ"
  echo "Host: $(hostname)"
  echo "Current addresses:"; ip -br -4 address
  echo "Routes:"; ip -4 route
  for x in ssh ovs-vsctl ovs-ofctl docker curl openssl ip; do
    printf '%-12s' "$x"; command -v "$x" || echo 'NOT INSTALLED'
  done
  echo "OpenSSL:"; openssl version
  echo "Direct H1.0 management LAN:"
  if ip -o -4 addr show | grep -Eq 'inet 192\.168\.50\.[0-9]+/24'; then
    echo 'YES: direct 192.168.50.0/24 interface';
  else
    echo 'NO: lab H1.0 192.168.50.0/24 interface absent; remote network test BLOCKED'
    exit 2
  fi
} | tee "$LOG"
