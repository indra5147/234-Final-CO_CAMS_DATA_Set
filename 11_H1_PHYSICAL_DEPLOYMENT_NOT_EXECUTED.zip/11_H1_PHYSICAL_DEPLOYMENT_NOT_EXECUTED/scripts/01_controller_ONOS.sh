#!/usr/bin/env bash
# Run ON C0. Safe by default: print commands; --apply must be given to change host.
set -euo pipefail
ACTION="${1:---dry-run}"
if [[ "$ACTION" != '--apply' && "$ACTION" != '--dry-run' ]]; then echo 'Usage: 01_controller_ONOS.sh [--dry-run|--apply]'; exit 2; fi
if [[ "$ACTION" == '--apply' ]]; then
  [[ "$(id -u)" -eq 0 ]] || { echo 'Use sudo for --apply'; exit 3; }
  ip -o -4 addr show | grep -Eq 'inet 192\.168\.50\.10/24' || { echo 'BLOCKED: Not physical H1.0 C0 management IP';exit 4; }
fi
printf '%s\n' 'ONOS Classic 2.7.0, Docker image onosproject/onos:2.7.0' \
  'NOTE: ONOS REST/web interface is plaintext HTTP on management-only LAN; isolate by firewall and change default credentials.'
if [[ "$ACTION" == '--dry-run' ]];then
  cat <<'COMMANDS'
To execute on C0 after installing Ubuntu 24.04 and verifying 192.168.50.10/24:
 sudo bash scripts/01_controller_ONOS.sh --apply
Actions: apt install docker.io curl; docker pull onosproject/onos:2.7.0; run as container exposing 6653 and 8181 on host network.
Default credentials must be changed before any external access. Activate OpenFlow and forwarding app after ONOS responds.
COMMANDS
  exit 0
fi
apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y docker.io curl
systemctl enable --now docker
if ! docker ps -a --format '{{.Names}}' | grep -qx 'onos-h1'; then
  docker pull onosproject/onos:2.7.0
  docker run -d --name onos-h1 --restart unless-stopped --network host onosproject/onos:2.7.0
else
  docker start onos-h1 || true
fi
echo 'ONOS STARTED/START REQUESTED — verify REST http://192.168.50.10:8181/onos/v1/devices and ONOS applications before installing datapaths.'
echo 'Do not expose ONOS default credentials or management port to the Internet.'
