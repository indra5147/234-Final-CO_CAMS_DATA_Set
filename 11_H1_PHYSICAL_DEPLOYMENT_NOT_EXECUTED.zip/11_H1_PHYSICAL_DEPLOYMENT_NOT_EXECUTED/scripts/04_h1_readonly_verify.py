#!/usr/bin/env python3
"""Read-only physical H1.0 verification. Never contacts hosts outside H1.0 LAN.
Run from C0 with a configured SSH key, and inspect all statuses.
"""
import argparse, datetime, json, os, re, shutil, socket, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
NODES={'C0':'192.168.50.10','SW1':'192.168.50.11','SW2':'192.168.50.12','CL1':'192.168.50.21','CL2':'192.168.50.22','SR1':'192.168.50.31','SR2':'192.168.50.32'}

def run(args,timeout=8):
    try:
        p=subprocess.run(args,capture_output=True,text=True,timeout=timeout)
        return {'ok':p.returncode==0,'returncode':p.returncode,'out':(p.stdout+p.stderr)[-4000:].strip()}
    except (subprocess.TimeoutExpired,FileNotFoundError) as e:
        return {'ok':False,'error':str(e)}

def route_guard():
    p=run(['ip','-o','-4','addr','show'])
    return p['ok'] and bool(re.search(r'\binet 192\.168\.50\.10/24\b',p['out']))

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--probe',action='store_true',help='Actually connect only if local C0 management NIC exists')
    ap.add_argument('--user',default='research')
    ap.add_argument('--ssh-key',default='~/.ssh/id_ed25519')
    ap.add_argument('--output',default=str(ROOT/'results'/'h1_physical_readiness.json'))
    args=ap.parse_args()
    state={'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'target':'LOCKED H1.0','mode':'probe' if args.probe else 'dry_run','expected_mgmt_nodes':NODES,'local_controller_mgmt_present':route_guard(),'checks':{},'status':'NOT_VALIDATED'}
    if not args.probe:
        print('DRY-RUN. To check actual seven-node lab, run on C0:')
        print('python3 scripts/04_h1_readonly_verify.py --probe --user <LAB_USER> --ssh-key ~/.ssh/id_ed25519')
    elif not state['local_controller_mgmt_present']:
        state['status']='BLOCKED_NOT_ON_H1_PHYSICAL_LAN'
        print('BLOCKED: local machine does not possess the 192.168.50.10/24 management interface.')
    elif not shutil.which('ssh'):
        state['status']='BLOCKED_NO_SSH_CLIENT'
        print('BLOCKED: OpenSSH client missing. Install openssh-client on C0.')
    else:
        key=os.path.expanduser(args.ssh_key)
        if not Path(key).exists():
            state['status']='BLOCKED_NO_SSH_KEY'
        else:
            state['checks']['ONOS_TCP_6653']=test_tcp('192.168.50.10',6653)
            state['checks']['ONOS_TCP_8181']=test_tcp('192.168.50.10',8181)
            for node,ip in NODES.items():
                if node=='C0':
                    state['checks'][node]={'ok':True,'role':'LOCAL_C0','ip':'192.168.50.10','openssl':run(['openssl','version'])}
                    continue
                commands='hostname; . /etc/os-release; echo "$PRETTY_NAME"; openssl version; ip -br -4 addr; '
                if node.startswith('SW'):
                    commands+='ovs-vsctl get-controller br-pqc; ovs-vsctl get bridge br-pqc protocols; ovs-vsctl list controller; ovs-ofctl -O OpenFlow13 show br-pqc;'
                commands+=' true'
                state['checks'][node]=run(['ssh','-i',key,'-o','BatchMode=yes','-o','StrictHostKeyChecking=accept-new','-o','ConnectTimeout=5',f'{args.user}@{ip}',commands],timeout=12)
            ok=all(x.get('ok') for x in state['checks'].values())
            state['status']='CONNECTIVITY_PROVISIONAL_PASS_REQUIRES_MANUAL_REVIEW' if ok else 'CONNECTIVITY_OR_SERVICE_CHECK_FAILED'
    dest=Path(args.output);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(json.dumps(state,indent=2))
    print(f'Physical H1.0 readiness status: {state["status"]}; report={dest}')
    return 0 if state['status']=='CONNECTIVITY_PROVISIONAL_PASS_REQUIRES_MANUAL_REVIEW' else 2

def test_tcp(host,port):
    try:
        with socket.create_connection((host,port),timeout=3):return {'ok':True,'host':host,'port':port}
    except OSError as e:return {'ok':False,'host':host,'port':port,'error':str(e)}

if __name__=='__main__':sys.exit(main())
