#!/usr/bin/env bash
# On SW1 or SW2: use data NICs only. Never add management NIC to bridge.
# Usage: sudo bash 02_ovs_physical_switch.sh SW1 nic1 nic2 nic3 [--apply]
set -euo pipefail
if [[ $# -lt 4 ]];then echo 'Usage: 02_ovs_physical_switch.sh SW1|SW2 dataNIC1 dataNIC2 dataNIC3 [--dry-run|--apply]';exit 2;fi
NODE="$1"; shift; NICS=("$1" "$2" "$3"); shift 3; MODE="${1:---dry-run}"
[[ "$NODE" == SW1 || "$NODE" == SW2 ]] || { echo 'NODE must be SW1 or SW2';exit 2; }
[[ "$MODE" == --apply || "$MODE" == --dry-run ]] || exit 2
[[ "${NICS[0]}" != "${NICS[1]}" && "${NICS[1]}" != "${NICS[2]}" && "${NICS[0]}" != "${NICS[2]}" ]] || { echo 'Repeated NIC names blocked';exit 3; }
MGMT_IP='192.168.50.11'; DP='0000000000000001'
if [[ "$NODE" == SW2 ]]; then MGMT_IP='192.168.50.12'; DP='0000000000000002';fi
for nic in "${NICS[@]}";do
 ip link show dev "$nic" >/dev/null || { echo "No such NIC: $nic";exit 4; }
 if ip -o -4 addr show dev "$nic" | grep -q 'inet ';then echo "BLOCKED: $nic has an IPv4 address, may be management NIC";exit 5;fi
 if ip -o -4 route show default | grep -qw "dev $nic"; then echo "BLOCKED: $nic owns default route";exit 6;fi
done
if [[ "$MODE" == --apply ]]; then
  [[ "$(id -u)" -eq 0 ]] || { echo 'Use sudo for --apply';exit 3; }
  ip -o -4 addr show | grep -Fq "inet ${MGMT_IP}/24" || { echo "BLOCKED: $NODE management IP missing";exit 7; }
fi
printf 'H1.0 %s dry-run=%s data NICs: %s\n' "$NODE" "$([[ "$MODE" == --dry-run ]] && echo yes || echo no)" "${NICS[*]}"
if [[ "$MODE" == --dry-run ]];then
  echo 'Would install OVS on Ubuntu, create br-pqc, add data NICs, set OpenFlow13 and remote ONOS controller.'
  echo 'WARNING: Adding a live data interface to OVS changes its forwarding behavior. Use local console, not remote data NIC SSH.'
  exit 0
fi
apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y openvswitch-switch
systemctl enable --now openvswitch-switch
ovs-vsctl --may-exist add-br br-pqc
for nic in "${NICS[@]}";do ovs-vsctl --may-exist add-port br-pqc "$nic";done
ovs-vsctl set bridge br-pqc protocols=OpenFlow13 other-config:datapath-id="$DP"
ovs-vsctl set-fail-mode br-pqc secure
ovs-vsctl set-controller br-pqc tcp:192.168.50.10:6653
ovs-vsctl --columns=name,controller,protocols,fail_mode list bridge br-pqc
ovs-vsctl list controller
ovs-ofctl -O OpenFlow13 show br-pqc
