import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from migration_scheduler import plan,load_jobs,Job,ALGORITHMS

class SchedulerTests(unittest.TestCase):
    def setUp(self):self.jobs=load_jobs()
    def test_every_job_once_every_strategy(self):
        for s in ALGORITHMS:
            all_jobs=[j for batch in plan(self.jobs,s,observed_network_load=.65) for j in batch]
            self.assertEqual(sorted(x.id for x in all_jobs), sorted(x.id for x in self.jobs))
    def test_limit_not_broken(self):
        for s in ALGORITHMS:
            self.assertTrue(all(len(batch)<=3 for batch in plan(self.jobs,s,max_parallel=3)))
    def test_hybrid_only(self):
        with self.assertRaises(ValueError):plan([Job('invalid','x',3,.2,800,40,'X25519')],'P1')
    def test_b4_least_loaded_first(self):
        order=[j for batch in plan(self.jobs,'B4') for j in batch]
        self.assertEqual(order,sorted(self.jobs,key=lambda j:(j.measured_service_load,j.id)))
    def test_p1_reduces_parallelism_under_load(self):
        self.assertTrue(all(len(b)==1 for b in plan(self.jobs,'P1',observed_network_load=.9)))
        self.assertTrue(any(len(b)>1 for b in plan(self.jobs,'P1',observed_network_load=.1)))
    def test_duplicates_fail(self):
        with self.assertRaises(ValueError):plan([self.jobs[0],self.jobs[0]],'B1')

if __name__=='__main__':unittest.main()
