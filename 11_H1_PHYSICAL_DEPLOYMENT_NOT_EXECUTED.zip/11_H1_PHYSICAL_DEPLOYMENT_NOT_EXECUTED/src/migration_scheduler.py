"""Baseline B1–B4 and candidate P1 planning for LOCKED protocol V1.0.

IMPORTANT: This module produces policy-ordered batches only. It does not
migrate active TLS sessions, configure ONOS, or measure service disruption.
Scientific performance claims require independent physical H1.0 trials.
"""
from dataclasses import dataclass
import math

ALGORITHMS=('B1','B2','B3','B4','P1')
HYBRID='X25519MLKEM768'

@dataclass(frozen=True)
class Job:
    id: str
    service: str
    security_priority: int  # 1=low, 5=highest
    measured_service_load: float  # recent utilization, 0..1
    deadline_ms: int
    estimated_cutover_ms: int
    required_group: str=HYBRID


def chunks(items,size):
    return [items[i:i+size] for i in range(0,len(items),size)]


def plan(jobs,policy,observed_network_load=0.25,max_parallel=4,fixed_batch=2):
    """Return ordered batches; all policies share the same concurrency cap.

    P1 is a preliminary heuristic to test, NOT an established novel algorithm.
    If deadline constraints are physically infeasible this planner does not
    claim to guarantee deadlines; the real controller must reject unsafe plans.
    """
    if policy not in ALGORITHMS:raise ValueError('Unknown strategy '+policy)
    if not 0 <= observed_network_load <= 1:raise ValueError('Network load out of range')
    if max_parallel<1 or fixed_batch<1:raise ValueError('Invalid parallel/batch limit')
    if len({j.id for j in jobs})!=len(jobs):raise ValueError('Duplicate job ID')
    for j in jobs:
        if j.required_group!=HYBRID:raise ValueError('Policy denies any non-hybrid migration')
        if not 0 <= j.measured_service_load <= 1:raise ValueError('Job service load out of range')
        if j.deadline_ms<=0 or j.estimated_cutover_ms<=0:raise ValueError('Invalid latency data')
        if j.security_priority<1 or j.security_priority>5:raise ValueError('Invalid priority')
    jobs=list(jobs)
    if policy=='B1': return chunks(jobs,max_parallel)
    if policy=='B2': return chunks(jobs,min(fixed_batch,max_parallel))
    if policy=='B3': return chunks(jobs,1)
    if policy=='B4':
        ordered=sorted(jobs,key=lambda j:(j.measured_service_load,j.id))
        return chunks(ordered,max_parallel)
    # P1: urgency-first policy with load-adaptive controlled concurrency.
    # Deadline slack is a ranking signal, NOT a guarantee of compliance.
    ordered=sorted(jobs,key=lambda j:(
        j.deadline_ms-j.estimated_cutover_ms,
        -j.security_priority,
        j.measured_service_load,
        j.id))
    if observed_network_load>=.75: n=1
    elif observed_network_load>=.50: n=min(2,max_parallel)
    else: n=max_parallel
    return chunks(ordered,n)


def load_jobs():
    # Deterministic configuration input for **functional smoke tests only**.
    return [Job(f'S{i:02d}',f'service-{i:02d}',1+(i%5),(.13*i)%1,700+i*31,30+(i%3)*8) for i in range(1,13)]
