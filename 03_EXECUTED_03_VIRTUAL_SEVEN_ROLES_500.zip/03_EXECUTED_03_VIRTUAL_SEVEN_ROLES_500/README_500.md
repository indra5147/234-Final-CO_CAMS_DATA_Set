# Executed seven-process-role SDN–PQC prototype: 500 trials per migration policy

## Research title
Controller-Orchestrated Crypto-Agile Post-Quantum Migration for Scalable Software-Defined Networks

## Scope
This is a **single-computer, single-kernel, loopback-only functional proof-of-concept** with seven logical OS process roles. The process labels are C0 (scheduler), SW1/SW2 (ordinary TCP byte relays), CL1/CL2 (migration-worker HTTP agents), and SR1/SR2 (TLS 1.3 servers). **It is not ONOS/OpenFlow/Open vSwitch, seven VMs, or the locked seven-machine hardware H1.0.**

## Actual execution protocol
- Real OpenSSL X25519 and X25519MLKEM768 authenticated TLS 1.3 sessions traverse CL→SW1→SW2→SR proxy links.
- A 12-job deterministic service list is migrated once by each scheduling policy in each trial block.
- Five scheduling policies: B1 bounded-bulk, B2 fixed-batch, B3 paced single-step, B4 load-aware job sort, P1 urgency/security sort with configured-load-dependent concurrency.
- Target repetitions: 500 trial blocks **per strategy** (2,500 policy executions, 30,000 sequential reconnect events, 60,002 successful handshakes including 2 route preflights, if all succeed).
- All strategies use configured load signal 0.62; this is a test input **not measured link utilization**. Strategy order is shuffled deterministically per trial.
- B1/B4 batch size up to 4, B2 batch size 2, B3 one at a time, P1 batch size 2 at load signal 0.62. This affects throughput and should be reported as part of the treatment, not hidden.

## Prerequisites
Linux with C compiler, Python 3.10+, OpenSSL 3.5+ library/development headers. numpy/matplotlib required for analysis.

## Reproduce
```bash
python3 virtual_testbed.py --trials 500 > experiment_console_500.log 2>&1
python3 analyze_500.py
```

## Experimental files
- `results/virtual_7_role_tls_reconnect_events.csv` — one record per sequential reconnect operation.
- `results/virtual_7_role_policy_runs.csv` — one record per strategy execution.
- `results/policy_summary_500.csv` — aggregated per-policy descriptive measurements.
- `results/paired_comparisons_500.json` — paired trial-block bootstrap comparisons (interpretation limited to this one host).
- `results/EXPERIMENTAL_REPORT_500.md` — methods, summaries and limitations.
- `results/*.png` — visualization of achieved measurements, not hypothetical values.
- `results/sha256_manifest_500.json` — integrity digests of source and datasets.

## Core caveats
The reconnect interval is **not live service disruption**, because the probes do not maintain a continuous serving application across cutover. Neither a physical SDN experiment nor the locked primary superiority hypothesis has been evaluated. Results must not be presented as full SDN migration superiority evidence. All test findings remain exploratory local-process measurements.
