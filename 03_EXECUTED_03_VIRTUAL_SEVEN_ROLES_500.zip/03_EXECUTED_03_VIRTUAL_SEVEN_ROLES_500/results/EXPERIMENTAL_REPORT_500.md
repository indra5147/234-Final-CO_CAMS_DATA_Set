# Executed 500-run-per-policy single-host proof-of-concept

**Completed trials:** 500 per B1, B2, B3, B4 and P1 = 2,500 policy runs.
**TLS reconnect operations:** 30,000.
**Successful real TLS handshakes:** 60,002 including 2 two-hop route preflights.
**Library:** OpenSSL 3.5.5 27 Jan 2026 (Library: OpenSSL 3.5.5 27 Jan 2026).
**Environment:** SINGLE_KERNEL_LOOPBACK_SEVEN_PROCESS_ROLES_NOT_OVS_ONOS.

## Critical limitations

- Seven distinct OS process roles on one shared Linux kernel, not 7 virtual machines or 7 physical PCs.
- SW1 and SW2 are TCP relays, not Open vSwitch; C0 is a Python scheduler, not ONOS.
- All traffic uses local loopback; 0.62 is a **configured scheduling signal**, not physical network utilization.
- A reconnect event means a successful X25519 handshake followed by a successful X25519MLKEM768 handshake; this does **not** migrate an active continuous TLS session.
- Sequential reconnect interval includes subprocess startup and scheduling; it is **not p95 service disruption** from locked protocol V1.0.
- Each strategy uses deterministic 12-job input each trial, and P1/B4 have different concurrency decisions by design.
- No defensible physical SDN or production-network superiority conclusions follow from these results.

## Descriptive measurements

| Policy | Runs | Reconnections | Mean 12-job batch (ms) | Pooled p95 reconnect (ms) | Success |
|---|---:|---:|---:|---:|---:|
| B1 | 500 | 6,000 | 80.59 | 15.04 | 100.0% |
| B2 | 500 | 6,000 | 181.70 | 13.08 | 100.0% |
| B3 | 500 | 6,000 | 322.24 | 12.02 | 100.0% |
| B4 | 500 | 6,000 | 80.99 | 14.86 | 100.0% |
| P1 | 500 | 6,000 | 124.45 | 12.86 | 100.0% |

## P1 versus B4 paired trial comparisons

A paired bootstrap resampled complete **trial blocks** (10,000 draws) rather than pretending individual reconnect events were independent:

- batch_ms_P1_minus_B4: mean difference 43.461 ms; 95% bootstrap CI [41.757, 45.118] ms, n=500 trial pairs.
- within_trial_p95_reconnect_ms_P1_minus_B4: mean difference -1.951 ms; 95% bootstrap CI [-2.396, -1.537] ms, n=500 trial pairs.

**Interpretation:** A statistically narrow local process-time interval does NOT prove P1 superiority. The locked primary outcome is p95 application service disruption with a common deadline and security guarantees; this prototype does not measure it.

## Source records and reproducibility

- `virtual_7_role_tls_reconnect_events.csv`: individual negotiation outcomes, actual TLS phase times and local event timings.
- `virtual_7_role_policy_runs.csv`: full batch wall time by trial and strategy.
- `policy_summary_500.csv` and `paired_comparisons_500.json`: aggregated descriptive measurements.
- `node_health.json` and process logs: seven OS processes and both two-hop TLS paths.
- `sha256_manifest_500.json`: file digests for source and outcomes.

```bash
python3 virtual_testbed.py --trials 500
python3 analyze_500.py
```

## Next validation gate

For locked V1.0, real or privileged emulated ONOS/OpenFlow/OVS networking, continuous application requests, timed cutover interruption, real measured load, held-out workloads, and fair calibrated policy baselines are still required. Physical H1.0 tests remain pending.
