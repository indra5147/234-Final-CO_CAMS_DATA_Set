#!/usr/bin/env python3
"""Generate a readable results workbook using artifact_tool only."""
import csv, json
from pathlib import Path
from artifact_tool import Workbook,SpreadsheetFile
root=Path(__file__).resolve().parent
out=root/'results'
with (out/'policy_summary_500.csv').open(newline='') as f: pol=list(csv.DictReader(f))
with (out/'virtual_7_role_policy_runs.csv').open(newline='') as f: runs=list(csv.DictReader(f))
comparisons=json.loads((out/'paired_comparisons_500.json').read_text())
summary=json.loads((out/'seven_virtual_nodes_summary.json').read_text())

wb=Workbook.create()
a=wb.worksheets.add('Overview')
a.merge_cells('A1:G2')
a.get_range('A1').values=[['SDN–PQC | 500-TRIAL-PER-POLICY LOCAL PROTOTYPE']]
a.get_range('A1:G2').format={'fill':'#17365D','font':{'bold':True,'color':'#FFFFFF','size':16},'vertical_alignment':'center','row_height':28}
a.get_range('A4:B10').values=[
['Execution basis','ONE physical host / seven process roles'],
['Tested methods','B1, B2, B3, B4, P1'],
['Trials per method',int(summary['trials_per_policy'])],
['Policy execution runs',int(summary['trials_per_policy'])*5],
['TLS reconnect events',int(summary['total_events'])],
['Real TLS handshakes',int(summary['total_tls_handshakes'])],
['TLS verification passed',bool(summary['all_verified'])],
]
a.get_range('A4:A10').format={'fill':'#EAF1F8','font':{'bold':True}}
a.get_range('A4:A10').format.column_width=31
a.get_range('B4:B10').format.column_width=43
a.merge_cells('A12:G12');a.get_range('A12').values=[['SCIENTIFIC INTERPRETATION']]
a.get_range('A12:G12').format={'fill':'#34495E','font':{'bold':True,'color':'#FFFFFF'}}
a.merge_cells('A13:G16')
a.get_range('A13').values=[['These are real OpenSSL TLS reconnect measurements through two local TCP proxy processes, NOT a physical ONOS/OVS testbed. The reconnect interval is NOT active application downtime. A synthetic load signal of 0.62 is configured, not measured. P1 superiority according to locked primary p95 service-disruption criteria remains UNTESTED.']]
a.get_range('A13:G16').format={'wrap_text':True,'row_height':22,'vertical_alignment':'center','fill':'#FFF5E8'}
a.merge_cells('A18:G18');a.get_range('A18').values=[['PAIRED RUN-LEVEL COMPARISONS: P1 – B4']]
a.get_range('A18:G18').format={'fill':'#34495E','font':{'bold':True,'color':'#FFFFFF'}}
a.get_range('A19:D21').values=[['Metric','Mean difference (ms)','95% CI lower','95% CI upper'],
 ['Batch completion',round(comparisons['batch_ms_P1_minus_B4']['mean_delta'],4),*map(lambda x:round(x,4),comparisons['batch_ms_P1_minus_B4']['ci95'])],
 ['Within-trial p95 reconnect',round(comparisons['within_trial_p95_reconnect_ms_P1_minus_B4']['mean_delta'],4),*map(lambda x:round(x,4),comparisons['within_trial_p95_reconnect_ms_P1_minus_B4']['ci95'])]]
a.get_range('A19:D19').format={'fill':'#DCEAF6','font':{'bold':True}}
a.get_range('A19:A21').format.column_width=31
for col in ('B','C','D'):a.get_range(f'{col}19:{col}21').format.column_width=22

p=wb.worksheets.add('Policy Summary')
headers=['Policy','Trials','Reconnects','Handshake count','Success %','Batch mean (ms)','Batch SD (ms)','Batch median (ms)','Reconnect mean (ms)','Pooled p95 (ms)','Trial p95 median (ms)']
p.get_range('A1:K1').values=[headers]
p.get_range('A2:K6').values=[[r['policy'],int(r['trial_runs']),int(r['reconnect_events']),int(r['tls_handshakes']),float(r['success_pct']),float(r['mean_batch_completion_ms']),float(r['sd_batch_completion_ms']),float(r['median_batch_completion_ms']),float(r['mean_reconnect_interval_ms']),float(r['pooled_p95_reconnect_interval_ms']),float(r['p95_per_trial_median_ms'])] for r in pol]
p.get_range('A1:K1').format={'fill':'#17365D','font':{'bold':True,'color':'#FFFFFF'},'row_height':28,'wrap_text':True}
p.get_range('A1:A6').format.column_width=16
p.get_range('B1:K6').format.column_width=21
p.freeze_panes.freeze_rows(1)
p.tables.add('A1:K6',True,'PolicySummary500')

s=wb.worksheets.add('Policy Runs 2500')
s.get_range('A1:E1').values=[['Trial','Policy','Batch completion (ms)','Verified reconnect operations','Batch sizes']]
s.get_range('A1:E1').format={'fill':'#17365D','font':{'bold':True,'color':'#FFFFFF'},'row_height':29,'wrap_text':True}
s.get_range('A2:E2501').values=[[int(r['trial']),r['policy'],float(r['wall_ms']),int(r['successful_migrations']),r['batch_sizes']] for r in runs]
s.get_range('A1:A2501').format.column_width=13
s.get_range('B1:B2501').format.column_width=14
s.get_range('C1:C2501').format.column_width=28
s.get_range('D1:D2501').format.column_width=25
s.get_range('E1:E2501').format.column_width=22
s.freeze_panes.freeze_rows(1)
s.tables.add('A1:E2501',True,'TrialRuns500')

z=wb.worksheets.add('Evidence Notes')
z.get_range('A1:B10').values=[
 ['Field','Scientific meaning'],
 ['Trial block','Each strategy executes the same 12-job configuration within a randomized sequence'],
 ['Pooled p95 reconnect','95th percentile of 6,000 local subprocess reconnection intervals, not downtime'],
 ['Paired 95% CI','10,000 trial-pair bootstrap resamples; run-level pairing'],
 ['Cryptographic validation','Successful X25519 then X25519MLKEM768 negotiation and endpoint ACKs'],
 ['Network','Linux loopback traffic only; no physical 1 GbE or OpenFlow topology'],
 ['SW1/SW2','Two Python TCP relays, not Open vSwitch devices'],
 ['Load','Controller input set to 0.62; NOT observed network utilization'],
 ['No superiority claim','Locked V1.0 service disruption and security SLA have not been evaluated'],
 ['Raw event evidence','Available in separate 30,000-row CSV inside execution ZIP'],
]
z.get_range('A1:B1').format={'fill':'#17365D','font':{'bold':True,'color':'#FFFFFF'},'row_height':26}
z.get_range('A1:A10').format.column_width=27
z.get_range('B1:B10').format={'wrap_text':True,'row_height':38,'column_width':85}
z.freeze_panes.freeze_rows(1)

path=out/'SDN_PQC_500x5_Run_Results.xlsx'
SpreadsheetFile.export_xlsx(wb).save(str(path))
print('Excel created',path, 'size',path.stat().st_size)
print('Summary sample',wb.inspect({'kind':'table','range':'Policy Summary!A1:D6','include':'values','table_max_rows':6,'table_max_cols':4}).ndjson[:900])
