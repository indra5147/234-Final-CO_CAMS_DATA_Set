#!/usr/bin/env python3
"""Analyze real single-host TLS reconnect proxy PoC, not physical SDN data."""
from pathlib import Path
import csv, json, math, statistics, hashlib, subprocess
from collections import defaultdict
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

root=Path(__file__).resolve().parent
out=root/'results'
summary=json.loads((out/'seven_virtual_nodes_summary.json').read_text())
with (out/'virtual_7_role_tls_reconnect_events.csv').open(newline='') as f:
    events=list(csv.DictReader(f))
with (out/'virtual_7_role_policy_runs.csv').open(newline='') as f:
    runs=list(csv.DictReader(f))
policies=['B1','B2','B3','B4','P1']
n=summary['trials_per_policy']; num_services=summary['services_per_trial']
assert n>=500, n
assert len(events)==n*5*num_services, (len(events),n)
assert len(runs)==n*5, (len(runs),n)
assert all(e['classical_ok']=='True' and e['hybrid_ok']=='True' and e['negotiated_classical'].lower()=='x25519' and e['negotiated_hybrid'].lower()=='x25519mlkem768' for e in events)
by_policy=defaultdict(list); by_trial_policy=defaultdict(list)
for e in events:
    by_policy[e['policy']].append(e)
    by_trial_policy[(int(e['trial']),e['policy'])].append(float(e['reconnect_interval_ms']))
run_map={(int(r['trial']),r['policy']):float(r['wall_ms']) for r in runs}
assert all(len(by_policy[p])==num_services*n for p in policies)
assert all(len(by_trial_policy[(i,p)])==num_services for i in range(1,n+1) for p in policies)

def p95(vals): return float(np.percentile(np.asarray(vals,dtype=float),95))

def paired_bootstrap_diff(x,y,seed=20261028,reps=10000):
    # Resample independent *trial pairs*, not individual TLS operations.
    d=np.asarray(x,dtype=float)-np.asarray(y,dtype=float)
    rng=np.random.default_rng(seed)
    sample_indices=rng.integers(0,len(d),size=(reps,len(d)))
    boots=d[sample_indices].mean(axis=1)
    return {'mean_delta':float(np.mean(d)),'ci95':list(map(float,np.percentile(boots,[2.5,97.5]))),'trial_pairs':len(d)}

rows=[]
for policy in policies:
    e=by_policy[policy]
    r=[run_map[(i,policy)] for i in range(1,n+1)]
    re=[float(x['reconnect_interval_ms']) for x in e]
    rows.append({'policy':policy,'trial_runs':n,'reconnect_events':len(e),'tls_handshakes':2*len(e),'success_pct':100.0,
                 'mean_batch_completion_ms':round(float(np.mean(r)),4),
                 'sd_batch_completion_ms':round(float(np.std(r,ddof=1)),4),
                 'median_batch_completion_ms':round(float(np.median(r)),4),
                 'mean_reconnect_interval_ms':round(float(np.mean(re)),4),
                 'pooled_p95_reconnect_interval_ms':round(p95(re),4),
                 'p95_per_trial_median_ms':round(float(np.median([p95(by_trial_policy[(i,policy)]) for i in range(1,n+1)])),4)})
with (out/'policy_summary_500.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

b4_batch=[run_map[(i,'B4')] for i in range(1,n+1)]
p1_batch=[run_map[(i,'P1')] for i in range(1,n+1)]
b4_p95=[p95(by_trial_policy[(i,'B4')]) for i in range(1,n+1)]
p1_p95=[p95(by_trial_policy[(i,'P1')]) for i in range(1,n+1)]
comparisons={
 'batch_ms_P1_minus_B4':paired_bootstrap_diff(p1_batch,b4_batch),
 'within_trial_p95_reconnect_ms_P1_minus_B4':paired_bootstrap_diff(p1_p95,b4_p95),
 'interpretation':'Proxy/loopback process timings only. Reconnect interval is not user-visible downtime; no ONOS, OVS, real congestion, or physical hardware. These CIs are descriptive for repeated trials on this one host and do not establish generalizable SDN superiority.'
}
(out/'paired_comparisons_500.json').write_text(json.dumps(comparisons,indent=2)+'\n')

# Plots deliberately do not imply a service-disruption advantage.
fig,ax=plt.subplots(figsize=(9,4.7))
means=[r['mean_batch_completion_ms'] for r in rows]
sd=[r['sd_batch_completion_ms'] for r in rows]
ci=[1.96*s/math.sqrt(n) for s in sd]
ax.bar(policies,means,yerr=ci,capsize=4)
ax.set_ylabel('Mean wall-clock time per 12-job batch (ms)')
ax.set_xlabel('Scheduling strategy')
ax.set_title(f'Loopback TLS proxy PoC — {n} run blocks per strategy')
fig.tight_layout();fig.savefig(out/'batch_time_500_runs.png',dpi=220);plt.close(fig)

fig,ax=plt.subplots(figsize=(9,4.7))
ax.bar(policies,[r['pooled_p95_reconnect_interval_ms'] for r in rows])
ax.set_ylabel('Pooled p95 sequential reconnect interval (ms)')
ax.set_title('500-run single-host proxy experiment — NOT live service downtime')
fig.tight_layout();fig.savefig(out/'pooled_reconnect_p95_500_runs.png',dpi=220);plt.close(fig)

fig,ax=plt.subplots(figsize=(9,4.7))
ax.plot(range(1,n+1),p1_batch,label='P1',alpha=.7,linewidth=.9)
ax.plot(range(1,n+1),b4_batch,label='B4',alpha=.7,linewidth=.9)
ax.set_xlabel('Trial block');ax.set_ylabel('Batch wall time (ms)')
ax.set_title('Main comparison: P1 versus B4 across paired run blocks')
ax.legend();fig.tight_layout();fig.savefig(out/'P1_vs_B4_500_trial_timeline.png',dpi=220);plt.close(fig)

manifest={}
for f in ['virtual_testbed.py','src/tlsprobe.c','src/migration_scheduler.py','analyze_500.py','results/virtual_7_role_tls_reconnect_events.csv','results/virtual_7_role_policy_runs.csv','results/policy_summary_500.csv']:
    manifest[f]=hashlib.sha256((root/f).read_bytes()).hexdigest()
(out/'sha256_manifest_500.json').write_text(json.dumps({'sha256':manifest,'openssl':summary['openss_l_version'],'trials_per_policy':n},indent=2)+'\n')
lines=['# Executed 500-run-per-policy single-host proof-of-concept','',
       f'**Completed trials:** {n} per B1, B2, B3, B4 and P1 = {n*5:,} policy runs.',
       f'**TLS reconnect operations:** {len(events):,}.',
       f'**Successful real TLS handshakes:** {summary["total_tls_handshakes"]:,} including 2 two-hop route preflights.',
       f'**Library:** {summary["openss_l_version"]}.',
       f'**Environment:** {summary["environment"]}.','',
       '## Critical limitations','',
       '- Seven distinct OS process roles on one shared Linux kernel, not 7 virtual machines or 7 physical PCs.',
       '- SW1 and SW2 are TCP relays, not Open vSwitch; C0 is a Python scheduler, not ONOS.',
       '- All traffic uses local loopback; 0.62 is a **configured scheduling signal**, not physical network utilization.',
       '- A reconnect event means a successful X25519 handshake followed by a successful X25519MLKEM768 handshake; this does **not** migrate an active continuous TLS session.',
       '- Sequential reconnect interval includes subprocess startup and scheduling; it is **not p95 service disruption** from locked protocol V1.0.',
       '- Each strategy uses deterministic 12-job input each trial, and P1/B4 have different concurrency decisions by design.',
       '- No defensible physical SDN or production-network superiority conclusions follow from these results.','',
       '## Descriptive measurements','',
       '| Policy | Runs | Reconnections | Mean 12-job batch (ms) | Pooled p95 reconnect (ms) | Success |',
       '|---|---:|---:|---:|---:|---:|']
for r in rows:
    lines.append(f'| {r["policy"]} | {r["trial_runs"]} | {r["reconnect_events"]:,} | {r["mean_batch_completion_ms"]:.2f} | {r["pooled_p95_reconnect_interval_ms"]:.2f} | {r["success_pct"]:.1f}% |')
lines+=['','## P1 versus B4 paired trial comparisons','',
        'A paired bootstrap resampled complete **trial blocks** (10,000 draws) rather than pretending individual reconnect events were independent:', '']
for k in ('batch_ms_P1_minus_B4','within_trial_p95_reconnect_ms_P1_minus_B4'):
    c=comparisons[k]
    lines.append(f'- {k}: mean difference {c["mean_delta"]:.3f} ms; 95% bootstrap CI [{c["ci95"][0]:.3f}, {c["ci95"][1]:.3f}] ms, n={n} trial pairs.')
lines+=['','**Interpretation:** A statistically narrow local process-time interval does NOT prove P1 superiority. The locked primary outcome is p95 application service disruption with a common deadline and security guarantees; this prototype does not measure it.','',
        '## Source records and reproducibility','',
        '- `virtual_7_role_tls_reconnect_events.csv`: individual negotiation outcomes, actual TLS phase times and local event timings.',
        '- `virtual_7_role_policy_runs.csv`: full batch wall time by trial and strategy.',
        '- `policy_summary_500.csv` and `paired_comparisons_500.json`: aggregated descriptive measurements.',
        '- `node_health.json` and process logs: seven OS processes and both two-hop TLS paths.',
        '- `sha256_manifest_500.json`: file digests for source and outcomes.','',
        '```bash',f'python3 virtual_testbed.py --trials {n}','python3 analyze_500.py','```','',
        '## Next validation gate','',
        'For locked V1.0, real or privileged emulated ONOS/OpenFlow/OVS networking, continuous application requests, timed cutover interruption, real measured load, held-out workloads, and fair calibrated policy baselines are still required. Physical H1.0 tests remain pending.','']
(out/'EXPERIMENTAL_REPORT_500.md').write_text('\n'.join(lines))
print('Analysis done:',len(events),'events,',len(runs),'policy runs')
for r in rows:print(r['policy'],r['mean_batch_completion_ms'],r['pooled_p95_reconnect_interval_ms'])
print(json.dumps(comparisons,indent=2))
