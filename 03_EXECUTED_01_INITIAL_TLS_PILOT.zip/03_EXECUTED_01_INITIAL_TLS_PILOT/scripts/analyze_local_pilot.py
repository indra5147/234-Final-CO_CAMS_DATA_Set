#!/usr/bin/env python3
"""Descriptive loopback pilot stats. Never interprets as migration/SDN results."""
import csv, json, sys
from pathlib import Path
import numpy as np
from scipy.stats import bootstrap
root=Path(__file__).resolve().parents[1]
file=Path(sys.argv[1]) if len(sys.argv)>1 else root/'results'/'local_tls_pilot.csv'
rows=list(csv.DictReader(file.open()))
groups=['X25519','X25519MLKEM768']
summary=[]
for group in groups:
    subset=[r for r in rows if r['requested_group']==group]
    vals=np.array([float(r['handshake_ms']) for r in subset])
    ci=bootstrap((vals,),np.mean,random_state=20261028,n_resamples=5000,method='percentile').confidence_interval
    summary.append({'group':group,'n':len(vals),'handshake_mean_ms':float(np.mean(vals)),'handshake_median_ms':float(np.median(vals)),'handshake_p95_ms':float(np.percentile(vals,95)),'handshake_p99_ms':float(np.percentile(vals,99)),'handshake_sd_ms':float(np.std(vals,ddof=1)),'mean_95pct_bootstrap_ci_ms':[float(ci.low),float(ci.high)],'certificate_verified_count':sum(int(r['certificate_verified']) for r in subset),'passed_count':sum(int(r['passed']) for r in subset)})
by={g:{int(r['pair_id']):float(r['handshake_ms']) for r in rows if r['requested_group']==g} for g in groups}
diff=np.array([by[groups[1]][i]-by[groups[0]][i] for i in sorted(by[groups[0]])])
diffci=bootstrap((diff,),np.mean,random_state=20261028,n_resamples=5000,method='percentile').confidence_interval
result={'scope':'LOCAL-LOOPBACK CRYPTOGRAPHIC PILOT ONLY; not SDN/ONOS/OVS, not H1.0 and not P1-vs-B4 migration superiority','groups':summary,'paired_difference_hybrid_minus_classical_ms':{'mean_ms':float(np.mean(diff)),'mean_95pct_bootstrap_ci_ms':[float(diffci.low),float(diffci.high)]},'negative_downgrade':json.loads((root/'results'/'downgrade_negative_test.json').read_text())}
(root/'results'/'local_tls_summary.json').write_text(json.dumps(result,indent=2))
lines=['# Measured Local TLS Pilot — NOT SDN H1.0 Validation','','**Scope:** Real OpenSSL TLS 1.3 handshakes over Linux loopback on a single virtualized/container host. The experiments do **not** connect the seven physical H1.0 nodes or execute the proposed P1 scheduling algorithm.','',f'Number of successful TLS handshakes: **{len(rows)}**; both groups had verified certificate chains, correct negotiated groups and successful app ACK.','','| Key exchange | n | Mean handshake (ms) | Median (ms) | p95 (ms) | Mean bootstrap 95% CI (ms) |','|---|---:|---:|---:|---:|---:|']
for x in summary:
    l,u=x['mean_95pct_bootstrap_ci_ms'];lines.append(f"| {x['group']} | {x['n']} | {x['handshake_mean_ms']:.4f} | {x['handshake_median_ms']:.4f} | {x['handshake_p95_ms']:.4f} | [{l:.4f}, {u:.4f}] |")
lines+=['',f"Paired hybrid-minus-classical mean handshake difference: **{np.mean(diff):.4f} ms** (bootstrap 95% CI [{diffci.low:.4f}, {diffci.high:.4f}] ms). This single-host loopback difference is not a physical network estimate.",'',f"Negative downgrade test: **{'PASS' if result['negative_downgrade']['rejected'] else 'FAIL'}** (hybrid-only client rejected classical-only server).",'', '## Still required for locked protocol','', 'Physical H1.0 deployment; management and data NIC isolation; ONOS/OpenFlow 1.3 control; OVS forwarding verification; TLS endpoint migration agents; B1–B4 and P1 orchestration; shared migration deadlines; application disruption instrumentation; independent held-out workload experiments; ablation, fault injection and statistical superiority tests.','']
(root/'results'/'LOCAL_PILOT_REPORT.md').write_text('\n'.join(lines))
print('\n'.join(lines))
