#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
mkdir -p "$ROOT/bin" "$ROOT/certs"
cc -O2 -Wall -Wextra -std=c11 -o "$ROOT/bin/tlsprobe" "$ROOT/src/tlsprobe.c" -lssl -lcrypto -lpthread
if [[ ! -e "$ROOT/certs/server.crt" ]]; then
  openssl req -x509 -newkey ec -pkeyopt ec_paramgen_curve:P-256 -nodes -sha256 -days 30 \
   -subj '/CN=sdn-pqc.local' -addext 'subjectAltName=DNS:sdn-pqc.local,IP:127.0.0.1' \
   -keyout "$ROOT/certs/server.key" -out "$ROOT/certs/server.crt" >/dev/null 2>&1
  chmod 600 "$ROOT/certs/server.key"
fi
printf 'Built: %s/bin/tlsprobe\nOpenSSL: ' "$ROOT"
openssl version
