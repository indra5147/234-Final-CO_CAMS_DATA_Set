#!/usr/bin/env python3
"""Measured authenticated TLS 1.3 loopback pilot, NOT H1.0 SDN testbed.

Runs balanced randomized-order full-handshake probes with independently
configured classical and hybrid-PQC servers on 127.0.0.1. Fails closed on
certificate, group, or application ACK failures. Includes negative downgrade test.
"""
import argparse
import csv
import datetime as dt
import json
import os
import random
import signal
import socket
import subprocess
import sys
import time
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
HEADER=['environment','run_id','pair_id','sequence','timestamp_utc','tag','trial','host','port','requested_group','negotiated_group','certificate_verified','handshake_ms','application_rtt_ms','total_ms','passed','cipher','status']

def free_port():
    with socket.socket() as s:
        s.bind(('127.0.0.1', 0))
        return s.getsockname()[1]

def ready(port, timeout=5):
    start=time.monotonic()
    while time.monotonic()-start < timeout:
        with socket.socket() as s:
            s.settimeout(.1)
            if s.connect_ex(('127.0.0.1',port)) == 0: return True
        time.sleep(.025)
    return False

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--pairs',type=int,default=100,help='Paired trials, each tests both key exchanges')
    ap.add_argument('--seed',type=int,default=20261028)
    ap.add_argument('--output',default=str(ROOT/'results'/'local_tls_pilot.csv'))
    args=ap.parse_args()
    assert args.pairs>0 and args.pairs<=10000
    binary=ROOT/'bin'/'tlsprobe'; cert=ROOT/'certs'/'server.crt';key=ROOT/'certs'/'server.key'
    if not binary.is_file() or not cert.is_file():
        print('Run scripts/setup.sh first',file=sys.stderr);return 2
    out=Path(args.output);out.parent.mkdir(parents=True,exist_ok=True)
    rng=random.Random(args.seed)
    ports={'X25519':free_port(),'X25519MLKEM768':free_port()}
    servers=[]
    logfile=ROOT/'logs'/'pilot_servers.log'
    logfile.parent.mkdir(parents=True, exist_ok=True)
    with logfile.open('w') as log:
        try:
            for group,port in ports.items():
                p=subprocess.Popen([str(binary),'server','--port',str(port),'--group',group,'--cert',str(cert),'--key',str(key)],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
                servers.append(p)
            for port in ports.values():
                if not ready(port): raise RuntimeError(f'local server on port {port} not ready')
            rows=[];order=[]
            for trial in range(1,args.pairs+1):
                groups=['X25519','X25519MLKEM768']
                rng.shuffle(groups)
                for group in groups:
                    proc=subprocess.run([str(binary),'client','--host','127.0.0.1','--port',str(ports[group]),'--group',group,'--ca',str(cert),'--server-name','sdn-pqc.local','--tag','local_pilot','--trial',str(trial)],capture_output=True,text=True,timeout=12)
                    fields=next(csv.reader([proc.stdout.strip()])) if proc.stdout.strip() else []
                    if len(fields)!=13:
                        raise RuntimeError(f'Probe output corrupted: rc={proc.returncode} stdout={proc.stdout} stderr={proc.stderr}')
                    ts=dt.datetime.now(dt.timezone.utc).isoformat()
                    row=['local_loopback_only',f'L-{trial:04d}-{group}',trial,len(rows)+1,ts,*fields]
                    if proc.returncode!=0 or int(fields[10])!=1 or int(fields[6])!=1:
                        raise RuntimeError(f'Functional TLS failure {group}: {row} {proc.stderr}')
                    rows.append(row)
            with out.open('w',newline='') as f:
                writer=csv.writer(f);writer.writerow(HEADER);writer.writerows(rows)
            # Mandatory negative: hybrid-only client -> classical-only TLS server must reject.
            neg=subprocess.run([str(binary),'client','--host','127.0.0.1','--port',str(ports['X25519']),'--group','X25519MLKEM768','--ca',str(cert),'--server-name','sdn-pqc.local','--tag','downgrade_test','--trial','negative'],capture_output=True,text=True,timeout=12)
            rejected=neg.returncode!=0 and 'NONE' in neg.stdout
            negative={'requested_group':'X25519MLKEM768','server_only_group':'X25519','expected':'rejected','rejected':rejected,'return_code':neg.returncode,'raw_output':neg.stdout.strip(),'stderr':neg.stderr.strip()}
            (out.parent/'downgrade_negative_test.json').write_text(json.dumps(negative,indent=2))
            meta={'environment':'isolated Linux container, localhost 127.0.0.1; NO SDN, NO physical network','openssl':subprocess.check_output(['openssl','version'],text=True).strip(),'test_binary':str(binary),'timestamp_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'pairs':args.pairs,'total_handshakes':len(rows),'seed':args.seed,'certificate_verification':True,'ciphersuite':'TLS_AES_128_GCM_SHA256','session_resumption_disabled':True,'actual_h1_0_installed':False,'onos_connected':False,'ovs_connected':False,'physical_nics_measured':False,'experimental_status':'local_pilot_only'}
            (out.parent/'pilot_metadata.json').write_text(json.dumps(meta,indent=2))
            print(f'SUCCESS: {len(rows)} verified handshakes, {args.pairs} pairs; downgrade rejection={rejected}; data={out}')
            return 0 if rejected else 3
        finally:
            for p in servers:
                if p.poll() is None: p.terminate()
            for p in servers:
                try: p.wait(timeout=3)
                except subprocess.TimeoutExpired: p.kill()

if __name__=='__main__':raise SystemExit(main())
