#!/usr/bin/env bash
# READ-ONLY preflight; no remote changes. Does not fake connectivity.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
source "$ROOT/config/hosts.env"
# Avoid accidental attempts toward unrelated addresses through an Internet gateway.
if ! ip -o -4 addr show | grep -Eq 'inet 192\.168\.50\.[0-9]+/24'; then
 echo 'BLOCKED: This workstation is not directly connected to H1.0 management LAN (192.168.50.0/24).'; exit 2
fi
for node in C0 SW1 SW2 CL1 CL2 SR1 SR2; do
  ip="${!node}"
  echo "Checking $node ($ip)..."
  ssh -i "${SSH_KEY/#\~/$HOME}" -o BatchMode=yes -o StrictHostKeyChecking=accept-new -o ConnectTimeout=5 "${LAB_USER}@${ip}" \
    'printf "hostname="; hostname; printf "os="; . /etc/os-release; echo "$PRETTY_NAME"; printf "openssl="; openssl version; printf "nics="; ip -br link | tr "\n" " "; echo' \
    || { echo "FAILED: $node unreachable or SSH authentication not configured"; exit 4; }
done
echo 'PASS: all seven H1.0 nodes reachable via SSH; still need ONOS/OVS functional checks.'
