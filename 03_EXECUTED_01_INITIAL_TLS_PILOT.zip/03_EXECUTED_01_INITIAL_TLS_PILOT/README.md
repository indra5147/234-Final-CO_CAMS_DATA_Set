# Controller-Orchestrated Crypto-Agile Post-Quantum Migration for Scalable Software-Defined Networks

## Executed proof-of-concept package, 28 October 2026

**Status: LOCAL TLS CORRECTNESS PILOT COMPLETE; PHYSICAL H1.0 TESTBED NOT CONNECTED.**

This package provides a runnable OpenSSL 3.5+ TLS 1.3 microbenchmark and *actual* locally measured handshake data, certificate and negotiated-group verification, a negative security test, plus a **read-only** preflight connectivity test for the locked seven-machine physical lab. It does **not** implement ONOS/OVS orchestration, B1–B4/P1 scheduling, migration agents or service-disruption measurement. Results must not be cited as evidence of SDN or P1 superiority.

### Locked physical hardware addresses

| Host | Role | Management IPv4 |
|---|---|---|
| C0 | ONOS / orchestration controller | 192.168.50.10 |
| SW1 | Physical Linux OVS forwarding PC | 192.168.50.11 |
| SW2 | Physical Linux OVS forwarding PC | 192.168.50.12 |
| CL1 | TLS client | 192.168.50.21 |
| CL2 | TLS client | 192.168.50.22 |
| SR1 | TLS server | 192.168.50.31 |
| SR2 | TLS server | 192.168.50.32 |

The data-plane /24 is 10.10.10.0/24, with clients .11/.12 and servers .21/.22. These are *planned addresses*, not addresses verified as reachable by this package. Management interface must be isolated from OVS data ports.

### Reproduce the local cryptographic pilot (Linux with OpenSSL >= 3.5, gcc, Python, NumPy and SciPy)

```bash
bash scripts/setup.sh
python3 scripts/run_local_pilot.py --pairs 100
python3 scripts/analyze_local_pilot.py
```

Outputs: `results/local_tls_pilot.csv`, `results/pilot_metadata.json`, `results/downgrade_negative_test.json`, `results/local_tls_summary.json`, `results/LOCAL_PILOT_REPORT.md`.

The test program validates the server certificate and hostname, exact negotiated key exchange group, TLS 1.3 cipher suite, and an encrypted application PING/ACK. Full handshakes are tested without session resumption. Servers listen on ephemeral localhost ports; two groups are tested in randomly interleaved pairs. The negative test rejects `X25519MLKEM768` client policy against an `X25519`-only server. Keys generated in `certs/` are **ephemeral demonstration self-signed test keys**, not production credentials. **Do not import them to production systems**.

### Physical H1.0 connectivity preflight (run ON C0 or lab admin host, not inside this sandbox)

1. Connect seven physical PCs and management switch (see `docs/PHYSICAL_LAB_CHECKLIST.md`). Install Linux, verify physical interfaces and configure locked IPv4 addresses.
2. Configure SSH keys and usernames via a local config file:

```bash
cp config/hosts.env.example config/hosts.env
nano config/hosts.env  # put actual lab account and secure SSH key
bash scripts/h1_remote_preflight.sh
```

The script **makes no remote changes** and refuses to run unless the initiating machine itself has an interface on `192.168.50.0/24`. If SSH fails, check network and authentication. Do not put private SSH keys in this package or share them in chat.

### What is required before calling the full experiment executed?

- Physical cabling and per-machine management/data connectivity proven and logged.
- ONOS controller and two OpenFlow 1.3-connected OVS hardware datapaths verified.
- OpenSSL 3.5+ deployed on both servers and both clients, with independent test certificates.
- Endpoint migration agents and a service workload actually performing connection draining/replacement/rollback.
- Separate B1 bulk, B2 fixed-batch, B3 fixed-rate, B4 tuned load-aware greedy, P1 controller-orchestrated migration implementations.
- E1–E6 under identical traffic and policy constraints and independently held-out workloads; collect real service disruption and deadline compliance.
- 30 independent repeats **subject to pilot variability and power analysis**, confidence intervals, failures and raw logs.

### Scientific disclosure

The available execution container has only a loopback interface and a virtual network interface. It is **not routed onto** the physical H1.0 management subnet. Local TLS measurements are informative for library correctness and method debugging but cannot establish external network scalability, controller workload, migration speed, reliability or superiority.
