# Measured Local TLS Pilot — NOT SDN H1.0 Validation

**Scope:** Real OpenSSL TLS 1.3 handshakes over Linux loopback on a single virtualized/container host. The experiments do **not** connect the seven physical H1.0 nodes or execute the proposed P1 scheduling algorithm.

Number of successful TLS handshakes: **200**; both groups had verified certificate chains, correct negotiated groups and successful app ACK.

| Key exchange | n | Mean handshake (ms) | Median (ms) | p95 (ms) | Mean bootstrap 95% CI (ms) |
|---|---:|---:|---:|---:|---:|
| X25519 | 100 | 1.1406 | 1.1071 | 1.6511 | [1.1022, 1.1824] |
| X25519MLKEM768 | 100 | 1.4441 | 1.3526 | 1.8543 | [1.3824, 1.5173] |

Paired hybrid-minus-classical mean handshake difference: **0.3035 ms** (bootstrap 95% CI [0.2331, 0.3841] ms). This single-host loopback difference is not a physical network estimate.

Negative downgrade test: **PASS** (hybrid-only client rejected classical-only server).

## Still required for locked protocol

Physical H1.0 deployment; management and data NIC isolation; ONOS/OpenFlow 1.3 control; OVS forwarding verification; TLS endpoint migration agents; B1–B4 and P1 orchestration; shared migration deadlines; application disruption instrumentation; independent held-out workload experiments; ablation, fault injection and statistical superiority tests.
