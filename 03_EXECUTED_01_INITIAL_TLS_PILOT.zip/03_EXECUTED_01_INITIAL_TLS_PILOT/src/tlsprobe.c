// SDN-PQC H1.0: reproducible TLS1.3 X25519/X25519MLKEM768 microbenchmark.
// This microbenchmark does NOT implement SDN migration, ONOS orchestration, or service-disruption testing.
#define _POSIX_C_SOURCE 200809L
#include <openssl/ssl.h>
#include <openssl/err.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <stdint.h>
#include <time.h>
#include <unistd.h>
#include <signal.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <strings.h>

static double mono_ms(void) {struct timespec t; clock_gettime(CLOCK_MONOTONIC_RAW,&t);return t.tv_sec*1000.0+t.tv_nsec/1e6;}
static const char *argval(int n,char **a,const char *key,const char *def) {for(int i=2;i+1<n;i++)if(!strcmp(a[i],key))return a[i+1];return def;}
static int die_ssl(const char *s) {fprintf(stderr,"ERROR: %s\n",s); ERR_print_errors_fp(stderr); return 1;}
static SSL_CTX *server_context(const char *cert,const char *key,const char *group) {
 SSL_CTX *ctx=SSL_CTX_new(TLS_server_method());if(!ctx) return NULL;
 SSL_CTX_set_min_proto_version(ctx,TLS1_3_VERSION);SSL_CTX_set_max_proto_version(ctx,TLS1_3_VERSION);
 if(!SSL_CTX_set1_groups_list(ctx,group)||!SSL_CTX_use_certificate_file(ctx,cert,SSL_FILETYPE_PEM)||!SSL_CTX_use_PrivateKey_file(ctx,key,SSL_FILETYPE_PEM)){SSL_CTX_free(ctx);return NULL;}
 SSL_CTX_set_ciphersuites(ctx,"TLS_AES_128_GCM_SHA256");SSL_CTX_set_options(ctx,SSL_OP_NO_TICKET);SSL_CTX_set_num_tickets(ctx,0);
 return ctx;
}
typedef struct {int fd;SSL_CTX *ctx;} sconn;
static void *handle(void *p){sconn *w=p;SSL *s=SSL_new(w->ctx);if(!s){close(w->fd);free(w);return NULL;}SSL_set_fd(s,w->fd);
 if(SSL_accept(s)>0){char buf[8192];int nr=SSL_read(s,buf,sizeof(buf));if(nr>0){const char *ok="ACK\n";SSL_write(s,ok,(int)strlen(ok));}}
 SSL_shutdown(s); SSL_free(s);close(w->fd);free(w);return NULL;}
static int runserver(int n,char **a){const char *port=argval(n,a,"--port","8443"),*group=argval(n,a,"--group","X25519");
 const char *cert=argval(n,a,"--cert","certs/server.crt"),*key=argval(n,a,"--key","certs/server.key");
 SSL_CTX *ctx=server_context(cert,key,group);if(!ctx)return die_ssl("server SSL_CTX configuration");
 int sock=socket(AF_INET,SOCK_STREAM,0),one=1;setsockopt(sock,SOL_SOCKET,SO_REUSEADDR,&one,sizeof(one));
 struct sockaddr_in address={0};address.sin_family=AF_INET;address.sin_addr.s_addr=INADDR_ANY;address.sin_port=htons((uint16_t)atoi(port));
 if(bind(sock,(struct sockaddr*)&address,sizeof(address))<0||listen(sock,1024)<0){perror("bind/listen");return 2;}
 printf("READY TLS1.3 group=%s port=%s\n",group,port);fflush(stdout);
 for(;;){int fd=accept(sock,NULL,NULL);if(fd>=0){int no_delay=1;setsockopt(fd,IPPROTO_TCP,TCP_NODELAY,&no_delay,sizeof(no_delay));}if(fd<0){if(errno==EINTR)continue;perror("accept");break;}sconn *w=malloc(sizeof(*w));if(!w){close(fd);continue;}w->fd=fd;w->ctx=ctx;pthread_t t;if(pthread_create(&t,NULL,handle,w)==0)pthread_detach(t);else{close(fd);free(w);}}
 close(sock);SSL_CTX_free(ctx);return 0;}
static int tcpconnect(const char *host,const char *port){struct addrinfo h={0},*r=NULL,*p;h.ai_family=AF_UNSPEC;h.ai_socktype=SOCK_STREAM;
 if(getaddrinfo(host,port,&h,&r))return -1;int fd=-1;for(p=r;p;p=p->ai_next){fd=socket(p->ai_family,p->ai_socktype,p->ai_protocol);if(fd<0)continue;struct timeval tv={.tv_sec=4,.tv_usec=0};setsockopt(fd,SOL_SOCKET,SO_RCVTIMEO,&tv,sizeof(tv));setsockopt(fd,SOL_SOCKET,SO_SNDTIMEO,&tv,sizeof(tv));if(connect(fd,p->ai_addr,p->ai_addrlen)==0){int no_delay=1;setsockopt(fd,IPPROTO_TCP,TCP_NODELAY,&no_delay,sizeof(no_delay));break;}close(fd);fd=-1;}freeaddrinfo(r);return fd;}
static int runclient(int n,char **a){const char *host=argval(n,a,"--host","127.0.0.1"),*port=argval(n,a,"--port","8443"),*group=argval(n,a,"--group","X25519"),*ca=argval(n,a,"--ca","certs/server.crt");
 const char *server_name=argval(n,a,"--server-name","sdn-pqc.local"),*tag=argval(n,a,"--tag","local_pilot"),*trial=argval(n,a,"--trial","1");
 SSL_CTX *ctx=SSL_CTX_new(TLS_client_method());if(!ctx)return die_ssl("new client context");
 SSL_CTX_set_min_proto_version(ctx,TLS1_3_VERSION);SSL_CTX_set_max_proto_version(ctx,TLS1_3_VERSION); SSL_CTX_set_verify(ctx,SSL_VERIFY_PEER,NULL);SSL_CTX_set_ciphersuites(ctx,"TLS_AES_128_GCM_SHA256");
 if(!SSL_CTX_load_verify_locations(ctx,ca,NULL)||!SSL_CTX_set1_groups_list(ctx,group)){SSL_CTX_free(ctx);return die_ssl("client verification/groups");}
 int fd=tcpconnect(host,port);if(fd<0){fprintf(stderr,"connect fail %s:%s\n",host,port);return 3;}
 SSL *s=SSL_new(ctx);SSL_set_fd(s,fd); SSL_set_tlsext_host_name(s,server_name);SSL_set1_host(s,server_name);
 double c0=mono_ms(),h0=mono_ms();int tls_ok=(SSL_connect(s)==1);double hs=mono_ms()-h0;
 char got[128]="NONE",cipher[128]="NONE";int app_ok=0;double ar=0;
 if(tls_ok){const char *ng=SSL_get0_group_name(s);if(ng)snprintf(got,sizeof(got),"%s",ng);const char *c=SSL_get_cipher_name(s);if(c)snprintf(cipher,sizeof(cipher),"%s",c);
  const char *req="PING\n";double p0=mono_ms();int wr=SSL_write(s,req,(int)strlen(req));char buf[16];int rd=wr>0?SSL_read(s,buf,sizeof(buf)-1):-1;ar=mono_ms()-p0;app_ok=rd>0&&rd<16&&(buf[rd]=0,!strcmp(buf,"ACK\n"));}
 int verified=tls_ok&&SSL_get_verify_result(s)==X509_V_OK&&strcasecmp(got,group)==0;
 int pass=tls_ok&&app_ok&&verified;double total=mono_ms()-c0;
 printf("%s,%s,%s,%s,%s,%s,%d,%.6f,%.6f,%.6f,%d,%s,%s\n",tag,trial,host,port,group,got,verified,hs,ar,total,pass,cipher,pass?"ok":"fail");fflush(stdout);
 if(!pass){fprintf(stderr,"TLS probe unsuccessful (tls=%d app=%d matched=%d).\n",tls_ok,app_ok,verified);if(!tls_ok)ERR_print_errors_fp(stderr);}
 if(tls_ok){SSL_shutdown(s);} SSL_free(s);close(fd);SSL_CTX_free(ctx);return pass?0:4;}
int main(int n,char **a){OPENSSL_init_ssl(0,NULL);signal(SIGPIPE,SIG_IGN);if(n<2){fprintf(stderr,"Usage: tlsprobe server|client [--port ... --group ...]\n");return 2;}if(!strcmp(a[1],"server"))return runserver(n,a);if(!strcmp(a[1],"client"))return runclient(n,a);return 2;}
