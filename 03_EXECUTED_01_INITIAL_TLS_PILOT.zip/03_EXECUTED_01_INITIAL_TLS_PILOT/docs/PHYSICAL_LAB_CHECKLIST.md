# Locked Physical H1.0 — installation / connectivity checklist

The following are future experimental acceptance checks; **not performed in the assistant's container**.

## Physical topology and NIC assignment

- C0 management NIC -> management switch port 1.
- SW1 management onboard NIC -> management switch port 2.
- SW2 management onboard NIC -> management switch port 3.
- CL1, CL2 USB 3.0 management NICs -> ports 4, 5.
- SR1, SR2 USB 3.0 management NICs -> ports 6, 7.
- CL1 onboard NIC -> SW1 Intel I350 port 1; CL2 -> SW1 port 2.
- SW1 Intel I350 port 3 -> SW2 Intel I350 port 3.
- SW2 Intel I350 port 1 -> SR1 onboard NIC; SW2 port 2 -> SR2.
- 7 management and 5 data links total; verify LEDs, port indexes, cables and link speed.

## OS & cryptographic proof

1. Run `hostnamectl`, `ip -br addr`, `ethtool <NIC>`, `lspci -nn | grep -i ethernet` on each host; archive outputs. Do **not** assume adapter order matches physical port number.
2. On CL1/CL2/SR1/SR2, record `openssl version -a`, `openssl list -tls-groups | grep -E 'X25519|MLKEM'` and `ldd <tlsprobe_binary> | grep ssl`.
3. Place **non-production test cert/key** individually on servers; clients trust their test CA. Verify certificate hostname and negotiated group.
4. Configure management LAN `192.168.50.0/24`, data LAN `10.10.10.0/24`, with OVS bridge ports lacking host IPs.
5. Verify ONOS controller `C0` sees exactly `SW1/SW2` and expected ports; capture switch connection, flow rules and port stats. Record actual ONOS/OVS/OpenFlow versions.
6. Verify `CL1/CL2 <-> SR1/SR2` data traffic traverses SW1 and SW2 (disable a switch port and show data-plane outage/recovery in a controlled maintenance window). Avoid destructive tests on live networks.
7. Record time sync (chrony or PTP), experiment ID, kernel version, link speeds, CPU governor, environment and tool revisions.

## Security and comparison preconditions

- Maintain TLS 1.3 and same `TLS_AES_128_GCM_SHA256` and certificate auth for classical vs hybrid comparisons.
- Capture exact negotiated `X25519` / `X25519MLKEM768` and reject unauthorized classical-only fallback.
- Do not claim PQ authentication: fixed ECDSA P-256 certificates are classical.
- Main P1 vs B4 comparison uses identical workload samples, security policy, migration deadline and pre-tuned baseline parameters.
- Primary endpoint: p95 application disruption across independent held-out runs, conditional on deadline/security compliance; secondary outcomes and resource budgets pre-register before final testing.

**Photo integrity:** use real photographs taken of installed hardware; AI-generated illustrations must not be submitted as physical evidence.
