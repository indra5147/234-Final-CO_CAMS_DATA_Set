# Locked strategy V1.0 — execution status

| Component | Status on 2026-10-28 | Evidence |
|---|---|---|
| TLS 1.3 X25519 | PASS, localhost only | `results/local_tls_pilot.csv` |
| TLS 1.3 X25519MLKEM768 | PASS, localhost only | `results/local_tls_pilot.csv` |
| X.509 hostname/certificate validation | PASS, localhost only | `certificate_verified` field |
| Downgrade rejection (hybrid-only client/classical-only server) | PASS, localhost only | `results/downgrade_negative_test.json` |
| Physical 7-PC H1.0 network | NOT CONNECTED | No management network route |
| Two physical Open vSwitch datapaths | NOT TESTED | OVS not installed on assistant container |
| ONOS controller | NOT TESTED | ONOS not installed on assistant container |
| Migration agents / service draining | NOT IMPLEMENTED | — |
| B1–B4 / P1 algorithm comparative trials | NOT RUN | — |
| E1–E6 real hardware validation | NOT RUN | — |
| Claim of proposed-system superiority | NOT ESTABLISHED | — |

No dummy or synthetic data is presented as scientific results.
