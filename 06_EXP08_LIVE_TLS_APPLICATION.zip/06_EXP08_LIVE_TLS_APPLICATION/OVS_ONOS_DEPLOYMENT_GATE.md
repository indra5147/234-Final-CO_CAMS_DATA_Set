# Gate to a genuine isolated OpenFlow/OVS EXP-08 test

This file documents **requirements not met in the current ChatGPT container**, not a claim of deployment.

1. Start on a researcher-controlled Ubuntu 24.04 computer with passwordless local sudo or administrator access and no policy restrictions on creating network namespaces and veth pairs.
2. Install and verify: `iproute2`, `openvswitch-switch`, OpenSSL 3.5+ (ensure the TLS app links the expected libssl), an ONOS Classic 2.7.0 controller build with compatible Java runtime, `iperf3`, `tcpdump`, and host monitoring utilities.
3. Verify `sudo ip netns add exp08check && sudo ip netns del exp08check` succeeds. Verify `ovs-vsctl show` and `ovs-ofctl --version` and the controller's northbound API respond.
4. Instantiate seven isolated namespaces or privileged VMs representing C0/SW1/SW2/CL1/CL2/SR1/SR2. Create five distinct veth links matching physical H1.0 topology (CL1–SW1, CL2–SW1, SW1–SW2, SW2–SR1, SW2–SR2). Provide independent management links for OpenFlow controller access.
5. Configure OVS bridges on SW1/SW2, OpenFlow 1.3 connections to ONOS and verify controller-inserted flows/port counters. Do not confuse a Python TCP byte relay with an OpenFlow switch.
6. Integrate the live TLS PING/PONG application from EXP-08 as endpoint sessions, retaining peer/hostname/group verification.
7. Record actual offered/achieved load and user-facing service disruption, packet drops, NIC/OVS port statistics, controller decision latency, flow programming time, endpoint CPU/DRAM usage, power and software versions. Compare all methods at matched concurrency/security/deadlines.
8. Run controlled 10/25/50/75/90% load trials and deterministic failure/recovery injections on independent trials, keep raw PCAP/logs with synchronization provenance.
9. Freeze algorithm and baseline settings using development workloads, then evaluate on held-out independent workload conditions without tuning; report the locked p95 application disruption primary outcome and safety/deadline feasibility.
10. Only after this gate can the manuscript claim virtualized OpenFlow / SDN experimental validation. Physical H1.0 claims require the separately locked seven-computer deployment.

**DO NOT cite the current single-host proxy data as real OpenFlow SDN evidence.**
