# EXP-08 — Continuous-Service TLS Migration: Experimental Report

## Execution scope

- Data: **genuine, newly measured application requests over TLS 1.3 on loopback** (not a replay of externally published latency records).
- Topology: seven independent **process roles** on one Linux kernel, two TCP forwarding proxies (not ONOS/OVS/OpenFlow switches).
- TLS: authenticated X25519 classical and X25519MLKEM768 hybrid, verified against a test certificate.
- Trial blocks: 30; strategy policy runs: 150; successful live TLS cutovers: 1800.
- Concurrency cap: 4 for all policies; P1 observed-load input held at 0.10 for matching policy capacity.

## Primary measured outcomes

The session-level interruption measurement is the time between closing the established classical TLS connection and the **first successful hybrid-PQC PONG** from the live application. Acknowledgement gap is separately last successful classical PONG to first hybrid PONG. The per-policy-run p95 is computed across 12 services; 12 services are not treated as independent trials.

| Policy | Mean run p95 interruption (ms) | Mean policy completion (ms) | Hybrid TLS migrations | Offline request attempts |
|---|---:|---:|---:|---:|
| B1 | 6.846 | 176.068 | 360 | 391 |
| B2 | 6.525 | 225.875 | 360 | 427 |
| B3 | 5.936 | 258.117 | 360 | 323 |
| B4 | 7.672 | 181.720 | 360 | 416 |
| P1 | 6.854 | 175.445 | 360 | 372 |

## Matched P1 versus B4 comparisons

- p95_service_disruption_ms: mean P1−B4 = -0.818, paired bootstrap 95% CI [-1.518, -0.190], P1 numerically lower in 60.0% of matched trial blocks.
- batch_wall_ms: mean P1−B4 = -6.275, paired bootstrap 95% CI [-10.598, -1.869], P1 numerically lower in 76.7% of matched trial blocks.
- offline_attempts: mean P1−B4 = -1.467, paired bootstrap 95% CI [-2.433, -0.500], P1 numerically lower in 56.7% of matched trial blocks.
- p95_ack_gap_ms: mean P1−B4 = -0.768, paired bootstrap 95% CI [-1.496, -0.124], P1 numerically lower in 60.0% of matched trial blocks.

## Interpretation and strict limits

The experiment tests **continuous TLS application cutover with two TCP forwarding hops**. A lower p95 interruption is evidence only within this single-host functional test; it does not establish superiority over existing physical SDN systems. No ONOS controller, Open vSwitch/OpenFlow rules, real network saturation, multi-host time synchronisation, realistic contention, or fault injection is present. The P1 scheduler is the unchanged locked heuristic; no post-test tuning was used to claim superiority. Results must **not** be described as H1.0 physical hardware evidence.

Methodology caution: make-before-break can eliminate much of the interruption; this pilot uniformly uses break-before-make for all strategies. Comparing policies on schedule order alone does not demonstrate superiority across migration mechanisms. Observed app downtime is from TLS teardown to first new acknowledgement, while whole-policy timing includes controller harness startup/shutdown; it is not a pure migration makespan.
