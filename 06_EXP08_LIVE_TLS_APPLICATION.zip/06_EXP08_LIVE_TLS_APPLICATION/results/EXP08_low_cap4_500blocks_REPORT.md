# EXP-08 — Continuous-Service TLS Migration: Experimental Report

## Execution scope

- Data: **genuine, newly measured application requests over TLS 1.3 on loopback** (not a replay of externally published latency records).
- Topology: seven independent **process roles** on one Linux kernel, two TCP forwarding proxies (not ONOS/OVS/OpenFlow switches).
- TLS: authenticated X25519 classical and X25519MLKEM768 hybrid, verified against a test certificate.
- Trial blocks: 500; strategy policy runs: 2500; successful live TLS cutovers: 30000.
- Concurrency cap: 4 for all policies; P1 observed-load input held at 0.10 for matching policy capacity.

## Primary measured outcomes

The session-level interruption measurement is the time between closing the established classical TLS connection and the **first successful hybrid-PQC PONG** from the live application. Acknowledgement gap is separately last successful classical PONG to first hybrid PONG. The per-policy-run p95 is computed across 12 services; 12 services are not treated as independent trials.

| Policy | Mean run p95 interruption (ms) | Mean policy completion (ms) | Hybrid TLS migrations | Offline request attempts |
|---|---:|---:|---:|---:|
| B1 | 6.952 | 175.937 | 6000 | 6281 |
| B2 | 6.550 | 223.215 | 6000 | 6834 |
| B3 | 5.973 | 256.610 | 6000 | 5648 |
| B4 | 6.864 | 176.188 | 6000 | 6261 |
| P1 | 6.964 | 176.785 | 6000 | 6372 |

## Matched P1 versus B4 comparisons

- p95_service_disruption_ms: mean P1−B4 = 0.100, paired bootstrap 95% CI [-0.098, 0.302], P1 numerically lower in 49.8% of matched trial blocks.
- batch_wall_ms: mean P1−B4 = 0.597, paired bootstrap 95% CI [-1.290, 2.446], P1 numerically lower in 47.2% of matched trial blocks.
- offline_attempts: mean P1−B4 = 0.222, paired bootstrap 95% CI [-0.092, 0.536], P1 numerically lower in 44.2% of matched trial blocks.
- p95_ack_gap_ms: mean P1−B4 = 0.089, paired bootstrap 95% CI [-0.125, 0.306], P1 numerically lower in 48.6% of matched trial blocks.

## Interpretation and strict limits

The experiment tests **continuous TLS application cutover with two TCP forwarding hops**. A lower p95 interruption is evidence only within this single-host functional test; it does not establish superiority over existing physical SDN systems. No ONOS controller, Open vSwitch/OpenFlow rules, real network saturation, multi-host time synchronisation, realistic contention, or fault injection is present. The P1 scheduler is the unchanged locked heuristic; no post-test tuning was used to claim superiority. Results must **not** be described as H1.0 physical hardware evidence.

Methodology caution: make-before-break can eliminate much of the interruption; this pilot uniformly uses break-before-make for all strategies. Comparing policies on schedule order alone does not demonstrate superiority across migration mechanisms. Observed app downtime is from TLS teardown to first new acknowledgement, while whole-policy timing includes controller harness startup/shutdown; it is not a pure migration makespan.
