# EXP-08 — Continuous-Service TLS Migration: Experimental Report

## Execution scope

- Data: **genuine, newly measured application requests over TLS 1.3 on loopback** (not a replay of externally published latency records).
- Topology: seven independent **process roles** on one Linux kernel, two TCP forwarding proxies (not ONOS/OVS/OpenFlow switches).
- TLS: authenticated X25519 classical and X25519MLKEM768 hybrid, verified against a test certificate.
- Trial blocks: 30; strategy policy runs: 150; successful live TLS cutovers: 1800.
- Concurrency cap: 2 for all policies; P1 observed-load input held at 0.10 for matching policy capacity.

## Primary measured outcomes

The session-level interruption measurement is the time between closing the established classical TLS connection and the **first successful hybrid-PQC PONG** from the live application. Acknowledgement gap is separately last successful classical PONG to first hybrid PONG. The per-policy-run p95 is computed across 12 services; 12 services are not treated as independent trials.

| Policy | Mean run p95 interruption (ms) | Mean policy completion (ms) | Hybrid TLS migrations | Offline request attempts |
|---|---:|---:|---:|---:|
| B1 | 6.869 | 178.334 | 360 | 375 |
| B2 | 7.644 | 226.109 | 360 | 422 |
| B3 | 5.943 | 262.086 | 360 | 351 |
| B4 | 6.808 | 179.019 | 360 | 381 |
| P1 | 7.252 | 185.599 | 360 | 396 |

## Matched P1 versus B4 comparisons

- p95_service_disruption_ms: mean P1−B4 = 0.444, paired bootstrap 95% CI [-0.245, 1.220], P1 numerically lower in 46.7% of matched trial blocks.
- batch_wall_ms: mean P1−B4 = 6.580, paired bootstrap 95% CI [1.161, 12.468], P1 numerically lower in 33.3% of matched trial blocks.
- offline_attempts: mean P1−B4 = 0.500, paired bootstrap 95% CI [-0.933, 1.934], P1 numerically lower in 43.3% of matched trial blocks.
- p95_ack_gap_ms: mean P1−B4 = 0.472, paired bootstrap 95% CI [-0.308, 1.312], P1 numerically lower in 43.3% of matched trial blocks.

## Interpretation and strict limits

The experiment tests **continuous TLS application cutover with two TCP forwarding hops**. A lower p95 interruption is evidence only within this single-host functional test; it does not establish superiority over existing physical SDN systems. No ONOS controller, Open vSwitch/OpenFlow rules, real network saturation, multi-host time synchronisation, realistic contention, or fault injection is present. The P1 scheduler is the unchanged locked heuristic; no post-test tuning was used to claim superiority. Results must **not** be described as H1.0 physical hardware evidence.

Methodology caution: make-before-break can eliminate much of the interruption; this pilot uniformly uses break-before-make for all strategies. Comparing policies on schedule order alone does not demonstrate superiority across migration mechanisms. Observed app downtime is from TLS teardown to first new acknowledgement, while whole-policy timing includes controller harness startup/shutdown; it is not a pure migration makespan.
