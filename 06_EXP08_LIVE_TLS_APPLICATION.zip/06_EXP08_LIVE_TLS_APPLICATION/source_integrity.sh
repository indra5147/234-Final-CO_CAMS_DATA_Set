#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
echo 'EXP08 version and data hash snapshot:'
openssl version
python3 --version
sha256sum src/tls_app.c src/migration_scheduler.py exp08.py analyze_exp08.py
find results -type f -name '*.csv' -print0 | sort -z | xargs -0 -r sha256sum
