#!/usr/bin/env bash
# Run only when the EXP-08 local testbed servers and proxies are live.
set -u
ROOT="$(cd "$(dirname "$0")" && pwd)"
run_fail() {
 name="$1"; port="$2"; group="$3"
 set +e
 printf 'PING\n' | timeout 3s openssl s_client -connect "127.0.0.11:${port}" -tls1_3 -groups "$group" -CAfile "$ROOT/certs/server.crt" -verify_hostname sdn-pqc.local -verify_return_error -quiet > "$ROOT/logs/${name}.stdout" 2> "$ROOT/logs/${name}.stderr"
 status=$?
 set -e
 if [[ "$status" -eq 0 ]]; then echo "FAIL unexpected handshake success: $name"; return 1; fi
 echo "PASS rejected incompatible negotiated group: $name (exit=$status)"
}
run_fail negative_hybrid_to_classical 31101 X25519MLKEM768
run_fail negative_classical_to_hybrid 32101 X25519
