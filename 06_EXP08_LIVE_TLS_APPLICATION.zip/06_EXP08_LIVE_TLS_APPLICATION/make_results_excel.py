#!/usr/bin/env python3
import argparse,csv,json
from pathlib import Path
from artifact_tool import Workbook, SpreadsheetFile
R=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--trials',type=int,default=500);ap.add_argument('--parallel',type=int,default=4);a=ap.parse_args()
pre=f'EXP08_low_cap{a.parallel}_{a.trials}blocks'
with (R/'results'/f'{pre}_policy_runs.csv').open() as f:runs=list(csv.DictReader(f))
with (R/'results'/f'{pre}_policy_summary.csv').open() as f:summary=list(csv.DictReader(f))
with (R/'results'/f'{pre}_statistical_report.json').open() as f:stat=json.load(f)
wb=Workbook.create();s=wb.worksheets.add('Policy Summary')
s.get_range('A1:H1').values=[['Policy','Runs','Live cutovers','Mean run p95 gap (ms)','Mean batch wall (ms)','Offline attempts','Other request failures','Responded classical+hybrid']]
mat=[]
for x in summary:mat.append([x['policy'],int(x['runs']),int(x['live_migrations']),round(float(x['mean_run_p95_disruption_ms']),4),round(float(x['mean_batch_completion_ms']),4),int(x['total_offline_request_attempts']),int(x['total_other_request_failures']),int(x['acknowledged_classical_requests'])+int(x['acknowledged_hybrid_requests'])])
s.get_range('A2:H6').values=mat
s.get_range('A8:B8').values=[['Critical comparison: P1 minus B4','Value']]
k=stat['paired_P1_vs_B4'];out=[['Mean difference, p95 app interruption (ms)',round(k['p95_service_disruption_ms']['mean_P1_minus_B4'],4)],['95% CI lower, p95 app interruption (ms)',round(k['p95_service_disruption_ms']['paired_bootstrap_95CI'][0],4)],['95% CI upper, p95 app interruption (ms)',round(k['p95_service_disruption_ms']['paired_bootstrap_95CI'][1],4)],['Mean difference, batch wall (ms)',round(k['batch_wall_ms']['mean_P1_minus_B4'],4)],['Trial blocks per policy',a.trials]]
s.get_range('A9:B13').values=out
s.get_range('A15:H16').values=[['SCOPE: single Linux host, 7 process roles, two TCP proxies; NOT an ONOS/OVS/physical SDN test','','','','','','',''],['Measured application PING/PONG service cutover. No actual 1GbE load, packet loss, controller flow installation or external validation.','','','','','','','']]
s.get_range('A1:H1').format={'fill':'#183153','font':{'color':'#FFFFFF','bold':True},'row_height':30,'wrap_text':True}
s.get_range('A8:B8').format={'fill':'#183153','font':{'color':'#FFFFFF','bold':True},'row_height':24}
s.get_range('A1:A16').format.column_width=28
s.get_range('B1:C16').format.column_width=17
s.get_range('D1:H16').format.column_width=23
s.get_range('A15:H16').format.wrap_text=True
s.get_range('A15:H16').format.row_height=38
s.freeze_panes.freeze_rows(1)
q=wb.worksheets.add('Trial-level Runs');headers=list(runs[0]);rows=[]
for item in runs:
 row=[]
 for v in item.values():
  try:
   num=float(v);row.append(int(num) if num.is_integer() else num)
  except ValueError:row.append(v)
 rows.append(row)
q.get_range_by_indexes(0,0,1,len(headers)).values=[headers]
q.get_range_by_indexes(1,0,len(rows),len(headers)).values=rows
q.get_range_by_indexes(0,0,1,len(headers)).format={'fill':'#183153','font':{'color':'#FFFFFF','bold':True},'row_height':34,'wrap_text':True}
q.get_range_by_indexes(0,0,len(rows)+1,len(headers)).format.column_width=20
q.freeze_panes.freeze_rows(1)
q.tables.add(f'A1:{chr(64+len(headers))}{len(rows)+1}',True,'EXP08TrialRuns')
n=wb.worksheets.add('Study Notes')
notes=[('Classification','Executed, single-host live TLS application cutover'),('Role count','7 separate main OS process roles plus per-service TLS workers'),('Proxy nodes','SW1 / SW2 are userspace TCP relays, NOT OVS / OpenFlow'),('Crypto groups','TLS 1.3 X25519 -> X25519MLKEM768'),('Application probes','Periodic PING/PONG, approximately 2.5 ms cadence'),('Primary endpoint','Run-level p95 app interruption: old TLS teardown to first new PONG'),('Unit of inference','Trial block (12 sessions per strategy run are clustered)'),('Concurrency',f'Equal cap {a.parallel} for all strategies; P1 configured load signal 0.10'),('Data limitations','Loopback / CPU jitter; no congestion; no physically isolated links'),('Hardware H1.0','NOT connected or validated'),('Original experiment','EXP-08 generated new measurements, not an external GitHub replay'),('No superiority claim','Only local app-level functional evidence; SDN validation pending')]
n.get_range('A1:B1').values=[['Field','Information']]
n.get_range('A2:B13').values=[list(x) for x in notes]
n.get_range('A1:B1').format={'fill':'#183153','font':{'color':'#FFFFFF','bold':True}}
n.get_range('A1:A13').format.column_width=26
n.get_range('B1:B13').format.column_width=75
n.get_range('B2:B13').format.wrap_text=True
n.get_range('A1:B13').format.row_height=28
n.freeze_panes.freeze_rows(1)
out=R/'results'/f'{pre}_RESULTS.xlsx';SpreadsheetFile.export_xlsx(wb).save(str(out))
print('Workbook exported',out,out.stat().st_size)
print(wb.inspect({'kind':'table','range':'Policy Summary!A1:H6','include':'values','table_max_rows':6,'table_max_cols':8}).ndjson[:1200])
