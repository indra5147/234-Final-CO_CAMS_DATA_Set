#define _POSIX_C_SOURCE 200809L
#include <openssl/ssl.h>
#include <openssl/err.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <netinet/tcp.h>
#include <poll.h>
#include <unistd.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <errno.h>
#include <signal.h>

static double now_ms(void){struct timespec ts;clock_gettime(CLOCK_MONOTONIC,&ts);return ts.tv_sec*1000.+ts.tv_nsec/1e6;}
static const char *arg(int argc,char **argv,const char *k,const char *fallback){for(int i=2;i+1<argc;i++) if(!strcmp(argv[i],k))return argv[i+1];return fallback;}
static SSL_CTX* tlsctx(int server,const char *group,const char*crt,const char*key){
 SSL_CTX *ctx=SSL_CTX_new(server?TLS_server_method():TLS_client_method());if(!ctx)return NULL;
 SSL_CTX_set_min_proto_version(ctx,TLS1_3_VERSION);SSL_CTX_set_max_proto_version(ctx,TLS1_3_VERSION);
 SSL_CTX_set_ciphersuites(ctx,"TLS_AES_128_GCM_SHA256"); SSL_CTX_set_options(ctx,SSL_OP_NO_TICKET); SSL_CTX_set_num_tickets(ctx,0);
 if(!SSL_CTX_set1_groups_list(ctx,group)){SSL_CTX_free(ctx);return NULL;}
 if(server){if(!SSL_CTX_use_certificate_file(ctx,crt,SSL_FILETYPE_PEM)||!SSL_CTX_use_PrivateKey_file(ctx,key,SSL_FILETYPE_PEM)){SSL_CTX_free(ctx);return NULL;}}
 else {SSL_CTX_set_verify(ctx,SSL_VERIFY_PEER,NULL);if(!SSL_CTX_load_verify_locations(ctx,crt,NULL)){SSL_CTX_free(ctx);return NULL;}}
 return ctx;
}
static int socket_listener(const char *bindip,int port){int fd=socket(AF_INET,SOCK_STREAM,0);if(fd<0)return -1;int v=1;setsockopt(fd,SOL_SOCKET,SO_REUSEADDR,&v,sizeof(v));struct sockaddr_in a={0};a.sin_family=AF_INET;a.sin_port=htons(port);if(inet_pton(AF_INET,bindip,&a.sin_addr)!=1 || bind(fd,(void*)&a,sizeof(a)) || listen(fd,256)){perror("listen");close(fd);return -1;}return fd;}
typedef struct {SSL_CTX *ctx;int fd;} ServerConn;
static void* server_worker(void*vp){ServerConn *c=vp;SSL *s=SSL_new(c->ctx);SSL_set_fd(s,c->fd);if(SSL_accept(s)==1){char buf[128];for(;;){int n=SSL_read(s,buf,sizeof(buf));if(n<=0)break; if(SSL_write(s,"PONG\n",5)!=5)break;}}SSL_free(s);close(c->fd);free(c);return NULL;}
static int run_server(int argc,char**argv){const char*ip=arg(argc,argv,"--bind","127.0.0.31");int po=atoi(arg(argc,argv,"--old-port","31031")),pn=atoi(arg(argc,argv,"--new-port","32031"));const char*crt=arg(argc,argv,"--cert","certs/server.crt"),*key=arg(argc,argv,"--key","certs/server.key");
 SSL_CTX *ctx[2]={tlsctx(1,"X25519",crt,key),tlsctx(1,"X25519MLKEM768",crt,key)};if(!ctx[0]||!ctx[1]){ERR_print_errors_fp(stderr);return 2;}int a=socket_listener(ip,po),b=socket_listener(ip,pn);if(a<0||b<0)return 3;fprintf(stdout,"READY old=%d hybrid=%d\n",po,pn);fflush(stdout);
 struct pollfd fds[2]={{a,POLLIN,0},{b,POLLIN,0}};for(;;){if(poll(fds,2,-1)<0){if(errno==EINTR)continue;break;}for(int j=0;j<2;j++){if(fds[j].revents&POLLIN){int fd=accept(fds[j].fd,NULL,NULL);if(fd<0)continue;int one=1;setsockopt(fd,IPPROTO_TCP,TCP_NODELAY,&one,sizeof(one));ServerConn *w=calloc(1,sizeof(*w));w->ctx=ctx[j];w->fd=fd;pthread_t th;if(pthread_create(&th,NULL,server_worker,w)==0)pthread_detach(th);else{close(fd);free(w);}}}}
 return 0;}
typedef struct {SSL*ssl;SSL_CTX*ctx;int fd;int verified;char group[80];double hs_ms;} Link;
static int new_link(const char *ip,int port,const char*group,const char*ca,Link*out){memset(out,0,sizeof(*out));out->fd=-1;out->ctx=tlsctx(0,group,ca,NULL);if(!out->ctx)return -1;out->fd=socket(AF_INET,SOCK_STREAM,0);if(out->fd<0)return -1;struct sockaddr_in a={0};a.sin_family=AF_INET;a.sin_port=htons(port);if(inet_pton(AF_INET,ip,&a.sin_addr)!=1||connect(out->fd,(void*)&a,sizeof(a)))return -1;int one=1;setsockopt(out->fd,IPPROTO_TCP,TCP_NODELAY,&one,sizeof(one));
 struct timeval tv={.tv_sec=2,.tv_usec=0};setsockopt(out->fd,SOL_SOCKET,SO_RCVTIMEO,&tv,sizeof(tv));setsockopt(out->fd,SOL_SOCKET,SO_SNDTIMEO,&tv,sizeof(tv));
 out->ssl=SSL_new(out->ctx);SSL_set_fd(out->ssl,out->fd);SSL_set_tlsext_host_name(out->ssl,"sdn-pqc.local");SSL_set1_host(out->ssl,"sdn-pqc.local");double t=now_ms();int ok=SSL_connect(out->ssl)==1;out->hs_ms=now_ms()-t;const char*neg=ok?SSL_get0_group_name(out->ssl):NULL;snprintf(out->group,sizeof(out->group),"%s",neg?neg:"");out->verified=ok&&(SSL_get_verify_result(out->ssl)==X509_V_OK)&&(!strcasecmp(out->group,group));return out->verified?0:-2;}
static void free_link(Link*l){if(l->ssl){SSL_free(l->ssl);l->ssl=NULL;}if(l->fd>=0){close(l->fd);l->fd=-1;}if(l->ctx){SSL_CTX_free(l->ctx);l->ctx=NULL;}}
typedef struct {pthread_mutex_t lock;Link link;volatile int active,phase,running;int old_ok,new_ok,offline_attempts,failed_attempts,success_old,success_new;double last_old_ack,first_new_ack,last_ack,old_close_ms,hybrid_handshake_ms,max_ack_gap_ms,old_hs_ms;} Session;
static void sleep_us(long us){struct timespec tm={us/1000000,(us%1000000)*1000};nanosleep(&tm,NULL);}
static void *sender(void *v){Session *s=v;while(s->running){pthread_mutex_lock(&s->lock);if(s->active){int w=SSL_write(s->link.ssl,"PING\n",5);char buf[64];int r=w==5?SSL_read(s->link.ssl,buf,sizeof(buf)):0;if(r==5&&!memcmp(buf,"PONG\n",5)){double t=now_ms();if(s->last_ack>0 && t-s->last_ack>s->max_ack_gap_ms)s->max_ack_gap_ms=t-s->last_ack;s->last_ack=t;if(s->phase==0){s->success_old++;s->last_old_ack=t;}else{s->success_new++;if(s->first_new_ack==0)s->first_new_ack=t;}}else s->failed_attempts++;}else s->offline_attempts++;pthread_mutex_unlock(&s->lock);sleep_us(2500);}return NULL;}
static int run_client(int argc,char **argv){const char*ip=arg(argc,argv,"--host","127.0.0.11");int po=atoi(arg(argc,argv,"--old-port","31101")),pn=atoi(arg(argc,argv,"--new-port","32101"));const char*ca=arg(argc,argv,"--ca","certs/server.crt");Session s={0};pthread_mutex_init(&s.lock,NULL);if(new_link(ip,po,"X25519",ca,&s.link))return 4;s.old_ok=s.link.verified;s.old_hs_ms=s.link.hs_ms;s.active=1;s.running=1;pthread_t th;pthread_create(&th,NULL,sender,&s);printf("READY classical_verified=%d group=%s\n",s.old_ok,s.link.group);fflush(stdout);char line[128];int migrated=0;
 while(fgets(line,sizeof(line),stdin)){if(!strncmp(line,"MIGRATE",7) && !migrated){migrated=1;pthread_mutex_lock(&s.lock);s.active=0;s.old_close_ms=now_ms();free_link(&s.link);pthread_mutex_unlock(&s.lock);
 Link h={0};int st=new_link(ip,pn,"X25519MLKEM768",ca,&h);s.hybrid_handshake_ms=h.hs_ms;pthread_mutex_lock(&s.lock);if(st==0){s.link=h;s.active=1;s.phase=1;s.new_ok=1;}else{free_link(&h);s.failed_attempts++;}pthread_mutex_unlock(&s.lock);printf("MIGRATED ok=%d group=%s\n",s.new_ok,s.new_ok?s.link.group:"NONE");fflush(stdout);}
 else if(!strncmp(line,"STOP",4))break;}
 sleep_us(7000);s.running=0;pthread_join(th,NULL);pthread_mutex_lock(&s.lock);if(s.active)free_link(&s.link);pthread_mutex_unlock(&s.lock);pthread_mutex_destroy(&s.lock);
 double downtime=s.first_new_ack>0?s.first_new_ack-s.old_close_ms:-1;double gap=s.first_new_ack>0&&s.last_old_ack>0?s.first_new_ack-s.last_old_ack:-1;
 printf("RESULT {\"classical_verified\":%d,\"hybrid_verified\":%d,\"old_responses\":%d,\"new_responses\":%d,\"offline_attempts\":%d,\"failed_attempts\":%d,\"app_disruption_ms\":%.6f,\"ack_gap_ms\":%.6f,\"max_ack_gap_ms\":%.6f,\"old_handshake_ms\":%.6f,\"hybrid_handshake_ms\":%.6f}\n",s.old_ok,s.new_ok,s.success_old,s.success_new,s.offline_attempts,s.failed_attempts,downtime,gap,s.max_ack_gap_ms,s.old_hs_ms,s.hybrid_handshake_ms);fflush(stdout);
 return !(s.old_ok&&s.new_ok&&s.success_old>=1&&s.success_new>=1);}
int main(int argc,char **argv){OPENSSL_init_ssl(0,NULL);signal(SIGPIPE,SIG_IGN);if(argc<2)return 2;if(!strcmp(argv[1],"server"))return run_server(argc,argv);if(!strcmp(argv[1],"client"))return run_client(argc,argv);return 2;}
