#!/usr/bin/env python3
"""EXP-08 live TLS application cutover with seven localhost process ROLES.
Not real ONOS, OpenFlow, Docker, isolated virtual machines, or physical SDN.
C0 orchestrates SW1,SW2 forwarding proxies, CL1/CL2 TLS clients, SR1/SR2 TLS servers.
Application downtime is measured between acknowledgements on persistent TLS sessions.
"""
import argparse, asyncio, csv, json, os, subprocess, sys, statistics, time, math, random, threading, http.server, urllib.request, socket, signal
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'src'))
from migration_scheduler import load_jobs, plan, ALGORITHMS
HOST={'C0':'127.0.0.10','SW1':'127.0.0.11','SW2':'127.0.0.12','CL1':'127.0.0.21','CL2':'127.0.0.22','SR1':'127.0.0.31','SR2':'127.0.0.32'}
# SW1 forwards to SW2; SW2 forwards to TLS service ports. Four real TCP routes.
ROUTES={
 'SW1':[(31101,HOST['SW2'],31201),(32101,HOST['SW2'],32201),(31102,HOST['SW2'],31202),(32102,HOST['SW2'],32202)],
 'SW2':[(31201,HOST['SR1'],31031),(32201,HOST['SR1'],32031),(31202,HOST['SR2'],31032),(32202,HOST['SR2'],32032)]}
AGENT_PORT={'CL1':35021,'CL2':35022}

def make_bin():
 (ROOT/'bin').mkdir(exist_ok=True)
 subprocess.run(['cc','-O2','-std=c11','-Wall','-Wextra','-pthread',str(ROOT/'src/tls_app.c'),'-o',str(ROOT/'bin/tls_app'),'-lssl','-lcrypto'],check=True)
 if not ((ROOT/'certs/server.crt').exists() and (ROOT/'certs/server.key').exists()):
  subprocess.run(['openssl','req','-x509','-newkey','ec','-pkeyopt','ec_paramgen_curve:P-256','-nodes','-keyout',str(ROOT/'certs/server.key'),'-out',str(ROOT/'certs/server.crt'),'-days','14','-subj','/CN=sdn-pqc.local','-addext','subjectAltName=DNS:sdn-pqc.local'],check=True,capture_output=True)

def reachable(ip,port):
 try:
  with socket.create_connection((ip,port),timeout=.1):return True
 except OSError:return False
async def stream(sr,tw):
 try:
  while b:=await sr.read(65536):tw.write(b);await tw.drain()
 except (OSError,asyncio.CancelledError):pass
 finally:
  try:tw.write_eof()
  except (OSError,NotImplementedError):pass
async def run_proxy(role):
 async def handler(reader,writer,dip,dport):
  try:rr,rw=await asyncio.open_connection(dip,dport)
  except OSError:writer.close();await writer.wait_closed();return
  await asyncio.gather(stream(reader,rw),stream(rr,writer))
  for w in (writer,rw):
   w.close()
   try:await w.wait_closed()
   except OSError:pass
 ss=[await asyncio.start_server(lambda r,w,ip=dip,port=dport:handler(r,w,ip,port),HOST[role],pr) for pr,dip,dport in ROUTES[role]]
 print(json.dumps({'role':role,'ready':True,'routes':len(ss)}),flush=True)
 await asyncio.gather(*(s.serve_forever() for s in ss))

class Agent(http.server.BaseHTTPRequestHandler):
 role='';sessions={};lock=threading.Lock()
 def log_message(self,*args):pass
 def answer(self,d,status=200):
  raw=json.dumps(d).encode();self.send_response(status);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
 def do_GET(self):
  self.answer({'role':self.role,'healthy':True})
 def do_POST(self):
  try:
   n=int(self.headers.get('Content-Length','0'));data=json.loads(self.rfile.read(n));op=self.path;ident=data['id'];
   with self.lock:
    if op=='/start':
     if ident in self.sessions:raise RuntimeError('duplicate '+ident)
     k=1 if self.role=='CL1' else 2
     cmd=[str(ROOT/'bin/tls_app'),'client','--host',HOST['SW1'],'--old-port',str(31100+k),'--new-port',str(32100+k),'--ca',str(ROOT/'certs/server.crt')]
     p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,bufsize=1)
     ready=p.stdout.readline().strip()
     if not ready.startswith('READY classical_verified=1'):raise RuntimeError('TLS startup failed: '+ready+' '+p.stderr.read()[:200])
     self.sessions[ident]=p;self.answer({'ready':True,'id':ident,'old_tls_verified':True});return
    p=self.sessions[ident]
    if op=='/migrate':
     p.stdin.write('MIGRATE\n');p.stdin.flush();line=p.stdout.readline().strip()
     if not line.startswith('MIGRATED ok=1'):raise RuntimeError('hybrid failed '+line)
     self.answer({'id':ident,'hybrid_tls_verified':True});return
    if op=='/stop':
     p.stdin.write('STOP\n');p.stdin.flush();line=p.stdout.readline().strip()
     p.stdin.close();rc=p.wait(timeout=3)
     if not line.startswith('RESULT ') or rc!=0:raise RuntimeError('bad service stop '+line+' rc='+str(rc))
     del self.sessions[ident];v=json.loads(line[len('RESULT '):]);v['id']=ident;self.answer(v);return
   self.answer({'error':'bad operation'},404)
  except Exception as e:self.answer({'error':str(e)},500)
def run_agent(role):
 cls=type('RoleAgent',(Agent,),{'role':role,'sessions':{},'lock':threading.Lock()})
 print(json.dumps({'role':role,'ready':True}),flush=True)
 http.server.ThreadingHTTPServer((HOST[role],AGENT_PORT[role]),cls).serve_forever()

def agent(job):return 'CL1' if int(job[1:])%2 else 'CL2'
def post(service,method):
 role=agent(service);raw=json.dumps({'id':service}).encode();req=urllib.request.Request(f'http://{HOST[role]}:{AGENT_PORT[role]}/{method}',data=raw,headers={'Content-Type':'application/json'})
 with urllib.request.urlopen(req,timeout=8) as resp:
  d=json.load(resp)
  if 'error' in d:raise RuntimeError(f'{service}:{method}:{d["error"]}')
  return d

def spawn(role):
 f=(ROOT/'logs'/f'{role}.log').open('w')
 if role.startswith('SR'):
  k=1 if role=='SR1' else 2
  cmd=[str(ROOT/'bin/tls_app'),'server','--bind',HOST[role],'--old-port',str(31030+k),'--new-port',str(32030+k),'--cert',str(ROOT/'certs/server.crt'),'--key',str(ROOT/'certs/server.key')]
 else:cmd=[sys.executable,str(ROOT/'exp08.py'),'--role',role]
 return subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT,start_new_session=True),f

def percentile(xs,p):
 v=sorted(xs);k=(len(v)-1)*(p/100);a=int(k);b=min(a+1,len(v)-1);return v[a]+(v[b]-v[a])*(k-a)

def main_experiment(trials,parallel=4,scenario='low',seed=20261028):
 assert 1<=parallel<=4
 make_bin();(ROOT/'results').mkdir(exist_ok=True);(ROOT/'logs').mkdir(exist_ok=True)
 procs={r:spawn(r) for r in ('SR1','SR2','SW2','SW1','CL1','CL2')};res=[];runs=[]; rng=random.Random(seed);jobs=load_jobs(); ids=[j.id for j in jobs];
 try:
  for t in range(150):
   if all(reachable(HOST[r],p) for r,p in [('SR1',31031),('SR1',32031),('SR2',31032),('SR2',32032),('SW1',31101),('SW1',32101),('SW1',31102),('SW1',32102),('CL1',35021),('CL2',35022)]):break
   time.sleep(.03)
  else:raise RuntimeError('Seven-role network not ready. See logs')
  nodepids={'C0':os.getpid(), **{r:p.pid for r,(p,f) in procs.items()}}
  assert len(set(nodepids.values()))==7
  print('SEVEN ROLES READY '+json.dumps(nodepids),flush=True)
  # Preflight one routed TLS migration to validate all forwarding paths.
  for sid in ['S01','S02']:
   post(sid,'start');time.sleep(.013);post(sid,'migrate');time.sleep(.014);rr=post(sid,'stop')
   if not(rr['classical_verified'] and rr['hybrid_verified'] and rr['old_responses']>0 and rr['new_responses']>0):raise RuntimeError('preflight '+str(rr))
  print('PREFLIGHT PASSED: two TLS paths with genuine live PING/PONG cutover',flush=True)
  for trial in range(1,trials+1):
   pols=list(ALGORITHMS);rng.shuffle(pols)
   for policy in pols:
    tag=f'{trial}:{policy}:{parallel}:{scenario}'
    t0=time.monotonic()
    # Both client role agents hold 12 simultaneous live TLS app sessions.
    with ThreadPoolExecutor(max_workers=12) as pool:list(pool.map(lambda sid:post(sid,'start'),ids))
    time.sleep(.012)  # allow real requests before cutover
    observed=.1 # development baseline; P1 retains same concurrency limit as the other methods
    batches=plan(jobs,policy,observed_network_load=observed,max_parallel=parallel,fixed_batch=2)
    for bi,b in enumerate(batches):
     with ThreadPoolExecutor(max_workers=parallel) as pool:list(pool.map(lambda j:post(j.id,'migrate'),b))
     if bi<len(batches)-1 and policy in ('B2','B3'):time.sleep(.008 if policy=='B2' else .005)
    time.sleep(.013)
    with ThreadPoolExecutor(max_workers=12) as pool: items=list(pool.map(lambda sid:post(sid,'stop'),ids))
    end=(time.monotonic()-t0)*1000
    valid=all(q['classical_verified'] and q['hybrid_verified'] and q['old_responses']>0 and q['new_responses']>0 and q['app_disruption_ms']>=0 for q in items)
    if not valid:raise RuntimeError('invalid app data '+str(items))
    disruptions=[q['app_disruption_ms'] for q in items]; gaps=[q['ack_gap_ms'] for q in items]
    for q in items:q.update({'trial':trial,'policy':policy,'parallel':parallel,'scenario':scenario,'environment':'SINGLE_HOST_LOOPBACK_TLS_PROXY_NOT_ONOS_OVS'})
    res+=items
    runs.append({'trial':trial,'policy':policy,'parallel':parallel,'scenario':scenario,'p95_service_disruption_ms':percentile(disruptions,95),'max_service_disruption_ms':max(disruptions),'mean_service_disruption_ms':statistics.mean(disruptions),'p95_ack_gap_ms':percentile(gaps,95),'batch_wall_ms':end,'offline_attempts':sum(q['offline_attempts'] for q in items),'failed_attempts':sum(q['failed_attempts'] for q in items),'classical_responses':sum(q['old_responses'] for q in items),'hybrid_responses':sum(q['new_responses'] for q in items),'success_count':sum(q['classical_verified'] and q['hybrid_verified'] for q in items)})
   if trial%5==0 or trial==1:print(f'COMPLETED {trial}/{trials} matched blocks ({trial*5} policy runs, {trial*60} live migrations)',flush=True)
  results=ROOT/'results';prefix=f'EXP08_{scenario}_cap{parallel}_{trials}blocks'
  def write(rows,name):
   with (results/name).open('w',newline='') as f:
    wr=csv.DictWriter(f,fieldnames=list(rows[0].keys()));wr.writeheader();wr.writerows(rows)
  write(res,prefix+'_service_events.csv');write(runs,prefix+'_policy_runs.csv')
  sm={}
  for p in ALGORITHMS:
   a=[r for r in runs if r['policy']==p]
   sm[p]={'runs':len(a),'mean_run_p95_disruption_ms':statistics.mean(r['p95_service_disruption_ms'] for r in a),'mean_batch_wall_ms':statistics.mean(r['batch_wall_ms'] for r in a),'total_migrations':12*len(a),'response_success_rate':1.0,'total_offline_attempts':sum(r['offline_attempts'] for r in a),'total_failed_attempts':sum(r['failed_attempts'] for r in a)}
  out={'trial_blocks':trials,'policy_runs':len(runs),'migrations':len(res),'scenario':scenario,'same_concurrency_cap':parallel,'live_application_requests':True,'no_real_net_congestion':True,'observed_app_interruptions':True,'env_limitations':['No Docker, netns, Open vSwitch, ONOS or CAP_NET_ADMIN','Seven role processes share one kernel and use loopback TCP proxies','No full physical/virtual SDN topology; no 1Gbps hardware links','Workload priority/load are fixed test inputs, not monitored real utilization','No real fault-injection/recovery experiment','Within-trial twelve services are not independent replications'],'openss_l_version':subprocess.check_output(['openssl','version'],text=True).strip(),'nodes':nodepids,'per_policy':sm}
  (results/(prefix+'_summary.json')).write_text(json.dumps(out,indent=2))
  print('DONE '+json.dumps({'runs':len(runs),'migrations':len(res),'statistics':sm}),flush=True)
 finally:
  for p,f in procs.values():
   if p.poll() is None:p.terminate()
  for p,f in procs.values():
   try:p.wait(timeout=3)
   except subprocess.TimeoutExpired:p.kill();p.wait()
   f.close()

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--role',choices=['SW1','SW2','CL1','CL2']);parser.add_argument('--trials',type=int,default=3);parser.add_argument('--parallel',type=int,default=4);parser.add_argument('--scenario',default='low');args=parser.parse_args()
 if args.role in ('SW1','SW2'):asyncio.run(run_proxy(args.role))
 elif args.role:run_agent(args.role)
 else:main_experiment(args.trials,args.parallel,args.scenario)
