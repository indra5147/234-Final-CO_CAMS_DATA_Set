# Execution environment checks (2026-10-28)

- Kernel: Linux 6.18.55; Python 3.13.5; OpenSSL executable and Python SSL module: 3.5.5.
- Root user inside a restricted container, without `CAP_NET_ADMIN`, `CAP_NET_RAW` or `CAP_SYS_ADMIN`.
- Linux `ip netns add` fails (`mount --make-shared /run/netns failed: Operation not permitted`).
- `docker` and `ovs-vsctl` not installed.
- **Consequently:** Cannot instantiate Docker containers, independent Linux network namespaces, OVS kernel datapaths, or ONOS/OpenFlow-controlled switches. The measured experiment uses seven ordinary processes on one kernel with two userspace TCP byte relays.
