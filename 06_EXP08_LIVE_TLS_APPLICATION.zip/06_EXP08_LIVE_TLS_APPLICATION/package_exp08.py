#!/usr/bin/env python3
"""Package EXP08 raw evidence, source and analysis without private test keys."""
from pathlib import Path
import hashlib,zipfile,json,datetime
r=Path(__file__).resolve().parent
out=r.parent/'EXP08_Real_TLS_Application_Migration_Executed_500x5.zip'
files=[]
for path in r.rglob('*'):
 if not path.is_file():continue
 q=path.relative_to(r).as_posix()
 if q.startswith('certs/') or q.startswith('bin/') or '__pycache__' in q or q.endswith('.pyc') or q.endswith('.zip'):continue
 files.append(path)
manifest={'note':'Single-host 7-role application-level TLS test; not OVS/ONOS; no H1.0 physical validation','files':{p.relative_to(r).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}}
(r/'results'/'PACKAGE_SHA256_MANIFEST.json').write_text(json.dumps(manifest,indent=2))
files.append(r/'results'/'PACKAGE_SHA256_MANIFEST.json')
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(set(files)):z.write(p,arcname='EXP08_Continuous_TLS_Migration/'+p.relative_to(r).as_posix())
print(str(out));print('size_bytes:',out.stat().st_size);print('files:',len(files))
