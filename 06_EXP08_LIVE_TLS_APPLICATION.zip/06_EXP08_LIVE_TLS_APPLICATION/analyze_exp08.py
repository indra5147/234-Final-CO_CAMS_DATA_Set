#!/usr/bin/env python3
"""Run-block analysis for EXP08; 12 sessions per run are clustered, not independent trials."""
import argparse,csv,statistics,random,json,datetime as dt,hashlib,os
from pathlib import Path
from collections import defaultdict
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent

def pct(v,p):
 a=sorted(v); x=(len(a)-1)*(p/100); k=int(x);return a[k]+(a[min(k+1,len(a)-1)]-a[k])*(x-k)
def mean(x):return statistics.mean(x)
def ci_mean_diff(a,b,seed=20261028,iterations=3000):
 rng=random.Random(seed);n=len(a); dif=[a[i]-b[i] for i in range(n)];samples=[]
 for _ in range(iterations):samples.append(sum(dif[rng.randrange(n)] for i in range(n))/n)
 return (mean(dif),pct(samples,2.5),pct(samples,97.5))
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--trials',type=int,default=30);ap.add_argument('--parallel',type=int,default=4);ap.add_argument('--scenario',default='low');args=ap.parse_args()
 pre=f'EXP08_{args.scenario}_cap{args.parallel}_{args.trials}blocks';dst=ROOT/'results';
 with (dst/(pre+'_policy_runs.csv')).open() as f:runs=list(csv.DictReader(f))
 with (dst/(pre+'_service_events.csv')).open() as f:events=list(csv.DictReader(f))
 names=('B1','B2','B3','B4','P1')
 assert len(runs)==args.trials*5,(len(runs),args.trials)
 assert len(events)==args.trials*60,(len(events),args.trials)
 assert all(e['classical_verified']=='1' and e['hybrid_verified']=='1' for e in events)
 assert all(int(e['old_responses'])>=1 and int(e['new_responses'])>=1 for e in events)
 by={p:sorted((x for x in runs if x['policy']==p),key=lambda x:int(x['trial'])) for p in names}
 assert all([int(x['trial']) for x in by[p]]==list(range(1,args.trials+1)) for p in names)
 fields=['p95_service_disruption_ms','mean_service_disruption_ms','p95_ack_gap_ms','batch_wall_ms','offline_attempts','failed_attempts','classical_responses','hybrid_responses']
 summary=[]
 for p in names:
  q=by[p];data={k:[float(x[k]) for x in q] for k in fields}
  summary.append({'policy':p,'runs':len(q),'live_migrations':len(q)*12,'mean_run_p95_disruption_ms':mean(data['p95_service_disruption_ms']), 'median_run_p95_disruption_ms':statistics.median(data['p95_service_disruption_ms']),'mean_batch_completion_ms':mean(data['batch_wall_ms']),'total_offline_request_attempts':int(sum(data['offline_attempts'])),'total_other_request_failures':int(sum(data['failed_attempts'])),'acknowledged_classical_requests':int(sum(data['classical_responses'])),'acknowledged_hybrid_requests':int(sum(data['hybrid_responses']))})
 with (dst/(pre+'_policy_summary.csv')).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(summary[0]));w.writeheader();w.writerows(summary)
 comparisons={}
 for field in ['p95_service_disruption_ms','batch_wall_ms','offline_attempts','p95_ack_gap_ms']:
  p1=[float(x[field]) for x in by['P1']];b4=[float(x[field]) for x in by['B4']];diff,lo,hi=ci_mean_diff(p1,b4)
  comparisons[field]={'mean_P1_minus_B4':diff,'paired_bootstrap_95CI':[lo,hi],'P1_better_fraction':sum(a<b for a,b in zip(p1,b4))/len(p1)}
 result={'experiment':'EXP08 continuous-application migration single-host proof of concept','trials_per_policy':args.trials,'total_policy_runs':len(runs),'total_migrations':len(events),'connections_per_migration':2,'negotiated_groups':['X25519','X25519MLKEM768'],'summary':summary,'paired_P1_vs_B4':comparisons,'instrumentation':'C OpenSSL SSL_connect and persistent TLS SSL_write/SSL_read PING/PONG; monotonic timestamps; p95 across 12 services per trial; trials are inferential units','limitations':['Not OpenFlow/OVS/ONOS; forwarding through two process TCP relays on one shared Linux kernel','No measured network load; no congested or geographically distributed links','Synthetic scheduling load/priority inputs; no external controller resource telemetry','No independent physical network nodes; environment lacks CAP_NET_ADMIN','No security downgrade-injection or controller fault recovery test','Service downtime is last old connection teardown to first new PONG, not a network-wide downtime','Plain ECDSA P-256 TLS authentication, hybrid-PQC key agreement only']}
 (dst/(pre+'_statistical_report.json')).write_text(json.dumps(result,indent=2))
 plt.figure(figsize=(10,5.5))
 plt.bar([s['policy'] for s in summary],[s['mean_run_p95_disruption_ms'] for s in summary]);plt.ylabel('Mean of per-run p95 interruption (ms)');plt.xlabel('Migration strategy');plt.title('Observed application interruption during TLS migration');plt.tight_layout();plt.savefig(dst/(pre+'_disruption.png'),dpi=250);plt.close()
 plt.figure(figsize=(10,5.5));plt.bar([s['policy'] for s in summary],[s['mean_batch_completion_ms'] for s in summary]);plt.ylabel('Mean whole-policy execution time (ms)');plt.xlabel('Migration strategy');plt.title('Batch completion (includes startup, cutover, and stop/measurement)');plt.tight_layout();plt.savefig(dst/(pre+'_batch_completion.png'),dpi=250);plt.close()
 plt.figure(figsize=(11,5.5));z=[float(x['p95_service_disruption_ms'])-float(y['p95_service_disruption_ms']) for x,y in zip(by['P1'],by['B4'])];plt.plot(range(1,len(z)+1),z,linewidth=1,alpha=.75);plt.axhline(0,linestyle='--');plt.xlabel('Matched trial');plt.ylabel('P1 − B4 observed p95 interruption (ms)');plt.title('Paired run-block differences: negative favors P1');plt.tight_layout();plt.savefig(dst/(pre+'_P1_B4_pairs.png'),dpi=250);plt.close()
 report=f'''# EXP-08 — Continuous-Service TLS Migration: Experimental Report

## Execution scope

- Data: **genuine, newly measured application requests over TLS 1.3 on loopback** (not a replay of externally published latency records).
- Topology: seven independent **process roles** on one Linux kernel, two TCP forwarding proxies (not ONOS/OVS/OpenFlow switches).
- TLS: authenticated X25519 classical and X25519MLKEM768 hybrid, verified against a test certificate.
- Trial blocks: {args.trials}; strategy policy runs: {len(runs)}; successful live TLS cutovers: {len(events)}.
- Concurrency cap: {args.parallel} for all policies; P1 observed-load input held at 0.10 for matching policy capacity.

## Primary measured outcomes

The session-level interruption measurement is the time between closing the established classical TLS connection and the **first successful hybrid-PQC PONG** from the live application. Acknowledgement gap is separately last successful classical PONG to first hybrid PONG. The per-policy-run p95 is computed across 12 services; 12 services are not treated as independent trials.

| Policy | Mean run p95 interruption (ms) | Mean policy completion (ms) | Hybrid TLS migrations | Offline request attempts |
|---|---:|---:|---:|---:|
'''
 for s in summary:report+=f"| {s['policy']} | {s['mean_run_p95_disruption_ms']:.3f} | {s['mean_batch_completion_ms']:.3f} | {s['live_migrations']} | {s['total_offline_request_attempts']} |\n"
 report+='\n## Matched P1 versus B4 comparisons\n\n'
 for k,v in comparisons.items():report+=f"- {k}: mean P1−B4 = {v['mean_P1_minus_B4']:.3f}, paired bootstrap 95% CI [{v['paired_bootstrap_95CI'][0]:.3f}, {v['paired_bootstrap_95CI'][1]:.3f}], P1 numerically lower in {100*v['P1_better_fraction']:.1f}% of matched trial blocks.\n"
 report+='''
## Interpretation and strict limits

The experiment tests **continuous TLS application cutover with two TCP forwarding hops**. A lower p95 interruption is evidence only within this single-host functional test; it does not establish superiority over existing physical SDN systems. No ONOS controller, Open vSwitch/OpenFlow rules, real network saturation, multi-host time synchronisation, realistic contention, or fault injection is present. The P1 scheduler is the unchanged locked heuristic; no post-test tuning was used to claim superiority. Results must **not** be described as H1.0 physical hardware evidence.

Methodology caution: make-before-break can eliminate much of the interruption; this pilot uniformly uses break-before-make for all strategies. Comparing policies on schedule order alone does not demonstrate superiority across migration mechanisms. Observed app downtime is from TLS teardown to first new acknowledgement, while whole-policy timing includes controller harness startup/shutdown; it is not a pure migration makespan.
'''
 (dst/(pre+'_REPORT.md')).write_text(report)
 print(report[:4500]);print('\nSTAT JSON',dst/(pre+'_statistical_report.json'))
if __name__=='__main__':main()
