# EXP-10 lab execution runbook — V3

**This is a deployment and data-integrity package, not completed ONOS/OVS research data.** The last actual attempt in this ChatGPT sandbox was blocked by missing `CAP_NET_ADMIN`, Docker, Mininet and OVS. It did not generate SDN CSV results.

## On a dedicated Ubuntu 24.04 computer only

Prerequisites: an authorized, isolated lab host with sudo, Docker capability, free local TCP ports 6653 and 8181, 16+ GiB RAM, and internet for software installation. Do not run on production interfaces. This creates Mininet virtual interfaces and configures local switches.

```bash
cd EXP10_SDN_Lab_Validated_V3
sudo bash scripts/install_ubuntu24.sh
sudo bash scripts/install_openssl35.sh
sudo bash scripts/build_tls35.sh
sudo bash scripts/run_smoke_only.sh
```

**Inspect the `RUN_ID` output and its directory** under `results/studies/smoke_.../`. Confirm `EXP10_COMPLETED.json`, `EXP10_smoke_gate.json` with `accepted: true`, both `EXP10_*.csv` files, and the SHA-256 file. If any failure occurs, do not launch the full matrix; inspect `results/studies/<run-id>/logs/` and the local controller container logs.

Then, only after the real smoke succeeds:

```bash
sudo -E env EXP10_CONFIRM_FULL=YES bash scripts/run_full_exp10_lab.sh
```

The launcher targets 6 policies x 3 traffic modes x 5 network load targets x 500 trial blocks = 45,000 policy executions. This is a **planned maximum**, not executed data. Every condition writes to a new unique `results/studies/study_*` folder. A failed condition stops the launcher, and its logs must be retained. The code does not prove exact controller/OVS version interoperability until run in the Ubuntu lab. The 7 physical Dell PCs in the locked H1.0 testbed are a separate validation.

## Security and scientific controls

- Do not put a test private key or certificate in a public repository; the build creates short-lived lab certificates only.
- A completed run may have failed trials: inspect `success_count`, success/failure rates, link utilization, ONOS flow status, and unsafe downgrade counts. Only **genuine observed** migration data belongs in the paper; failed trials must not be silently discarded.
- Current main metric is **application inter-response gap** (last old-session response to first hybrid-session response), **not** a complete trace of every unavailable service interval.
- Per-endpoint deadline and campaign guard are present, but the guard cannot forcibly preempt a blocked synchronous TLS handshake. Do not claim hard real-time guarantees.
- Locked original P1 is unchanged. P1-v1.1 is exploratory; if not significantly superior to B4 on independent workloads, report that result.

## Recovery & verification

If OpenFlow rules do not reach `ADDED`, or measured network load falls outside target tolerance, preserve logs and stop. Prior run folders are immutable: running an identical `--run-id` is rejected, and analyses require explicit `--results-dir` with a completion marker and matching event counts.

To inspect the local sandbox status, read `results/LOCAL_EXECUTION_AUDIT.json`. That audit is **not** an EXP-10 SDN measurement.
