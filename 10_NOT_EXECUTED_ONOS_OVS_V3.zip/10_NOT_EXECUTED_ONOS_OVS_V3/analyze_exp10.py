#!/usr/bin/env python3
"""Only analyzes actual EXP10_policy_runs.csv generated on a privileged SDN host.
No invented fallback, no substitution of old experiment data.
"""
import argparse,csv,collections,json,math,random,statistics,pathlib
R=pathlib.Path(__file__).resolve().parent/'results'

def mean(a):return statistics.mean(a) if a else None

def bootstrap_paired(xs,n=3000,seed=2718):
 rng=random.Random(seed);sz=len(xs)
 if sz<2:return None
 avgs=sorted(sum(xs[rng.randrange(sz)] for j in range(sz))/sz for _ in range(n))
 return [avgs[int(.025*(n-1))],avgs[int(.975*(n-1))]]

def load_csv(p):
 with p.open(newline='') as f:return list(csv.DictReader(f))

def main():
 parser=argparse.ArgumentParser()
 parser.add_argument('--results-dir',required=True,help='Unique EXP-10 output folder with completion marker')
 args=parser.parse_args()
 global R
 R=pathlib.Path(args.results_dir).resolve()
 authorized=(pathlib.Path(__file__).resolve().parent/'results'/'studies').resolve()
 if not R.is_relative_to(authorized):raise SystemExit('Analysis REFUSED: results must be inside results/studies/')
 marker=R/'EXP10_COMPLETED.json'
 if not marker.is_file():raise SystemExit('Analysis REFUSED: missing EXP10_COMPLETED.json marker; data may be stale or incomplete')
 meta=json.loads(marker.read_text())
 if meta.get('status')!='COMPLETED_ON_PRIVILEGED_SDN_HOST':raise SystemExit('Analysis REFUSED: completion status invalid')
 p=R/'EXP10_policy_runs.csv'
 if not p.is_file():raise SystemExit('NO EXP-10 SDN DATA: actual ONOS/OVS runs have not executed; analysis refused.')
 rows=load_csv(p)
 if not rows:raise SystemExit('Empty/invalid data; no results')
 if len(rows)!=meta['expected_policy_rows'] or len(rows)!=meta['observed_policy_rows']:
  raise SystemExit('Analysis REFUSED: run count differs from completion marker')
 service=load_csv(R/'EXP10_service_events.csv')
 if len(service)!=meta['observed_service_rows'] or len(service)!=12*len(rows):
  raise SystemExit('Analysis REFUSED: service records are incomplete or mismatched')
 keys=[(x['traffic_mode'],x['load_target_pct'],x['trial'],x['policy']) for x in rows]
 if len(set(keys))!=len(keys):raise SystemExit('Analysis REFUSED: duplicated policy-trial keys')
 expected={'trial','load_target_pct','load_observed_pct','traffic_mode','policy','success','observed_p95_ack_gap_ms','global_deadline_met'}
 if expected-set(rows[0]):raise SystemExit('Missing required columns: '+str(expected-set(rows[0])))
 g=collections.defaultdict(list)
 for r in rows:g[(r['traffic_mode'],r['load_target_pct'],r['policy'])].append(r)
 summaries=[];pairs=[]
 for (mode,load,policy),rr in sorted(g.items()):
  successful=[x for x in rr if x['success']=='True' and x['observed_p95_ack_gap_ms'] not in ('','None')]
  lats=[float(x['observed_p95_ack_gap_ms']) for x in successful]
  rec={'mode':mode,'load_target_pct':load,'policy':policy,'n_policy_runs':len(rr),
       'n_successful':len(successful),'n_failed':len(rr)-len(successful),
       'mean_run_p95_inter_response_gap_ms':mean(lats),'observed_mean_load_pct':mean([float(x['load_observed_pct']) for x in rr]),
       'global_deadline_miss_count':sum(x['global_deadline_met']=='False' for x in rr),
       'unsafe_downgrade_events':sum(int(x.get('unsafe_downgrade_events') or 0) for x in rr)}
  summaries.append(rec)
 for mode,load,pol in sorted(g):
  if pol not in ('P1','P1_v1.1'):continue
  baseline={x['trial']:x for x in g.get((mode,load,'B4'),[])}
  diffs=[];n_common=0
  for row in g[(mode,load,pol)]:
   b=baseline.get(row['trial'])
   if not b:continue
   n_common+=1
   if row['success']!='True' or b['success']!='True':continue
   if row['observed_p95_ack_gap_ms'] in ('','None') or b['observed_p95_ack_gap_ms'] in ('','None'):continue
   diffs.append(float(row['observed_p95_ack_gap_ms'])-float(b['observed_p95_ack_gap_ms']))
  pairs.append({'mode':mode,'load_target_pct':load,'contrast':f'{pol}-B4','paired_blocks_total':n_common,
   'paired_blocks_both_successful':len(diffs),'mean_run_p95_gap_diff_ms':mean(diffs),
   'paired_bootstrap_95ci':bootstrap_paired(diffs),
   'note':'Failure blocks excluded from latency contrast but retained in failure-rate summary; do not claim non-inferiority from null CI.'})
 def dump_csv(filename,arr):
  if not arr:return
  with (R/filename).open('w',newline='') as f:
   w=csv.DictWriter(f,fieldnames=list(arr[0]));w.writeheader();w.writerows(arr)
 dump_csv('EXP10_descriptive_summary.csv',summaries)
 dump_csv('EXP10_paired_B4_CIs.csv',[{**x,'paired_bootstrap_95ci':json.dumps(x['paired_bootstrap_95ci'])} for x in pairs])
 (R/'EXP10_analysis.json').write_text(json.dumps({'source':'ACTUAL EXP10 ONOS OVS RUN FILE ONLY','summary':summaries,'paired':pairs,'limitations':['Application inter-response gaps are not proven service downtime','Link achieved utilization may diverge from commanded offered load','Four namespace hosts plus two OVS switches and Docker ONOS controller is single-host emulation','No physical H1.0 validation']},indent=2))
 print(json.dumps({'total_runs':len(rows),'groups':len(summaries),'paired_comparisons':len(pairs),'summary':'EXP10_analysis.json'},indent=2))
if __name__=='__main__':main()
