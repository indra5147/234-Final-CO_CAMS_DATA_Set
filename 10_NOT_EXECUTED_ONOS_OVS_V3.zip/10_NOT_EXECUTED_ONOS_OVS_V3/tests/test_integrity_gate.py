"""Synthetic NEGATIVE TEST fixtures only. Creates no publishable measurements."""
import csv, json, pathlib, subprocess, sys, tempfile, unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
STUDIES=ROOT/'results'/'studies'
class IntegrityRejectionTests(unittest.TestCase):
    def test_missing_completion_marker_rejected(self):
        STUDIES.mkdir(parents=True,exist_ok=True)
        with tempfile.TemporaryDirectory(prefix='negative_fixture_',dir=STUDIES) as work:
            w=pathlib.Path(work)
            (w/'EXP10_policy_runs.csv').write_text('trial,policy,success\n1,B4,True\n')
            p=subprocess.run([sys.executable,str(ROOT/'analyze_exp10.py'),'--results-dir',str(w)],capture_output=True,text=True)
            self.assertNotEqual(p.returncode,0)
            self.assertIn('missing EXP10_COMPLETED.json',p.stderr+p.stdout)
            self.assertFalse((w/'EXP10_analysis.json').exists())
    def test_missing_event_records_rejected(self):
        STUDIES.mkdir(parents=True,exist_ok=True)
        with tempfile.TemporaryDirectory(prefix='negative_fixture_',dir=STUDIES) as work:
            w=pathlib.Path(work)
            (w/'EXP10_COMPLETED.json').write_text(json.dumps({'status':'COMPLETED_ON_PRIVILEGED_SDN_HOST','expected_policy_rows':1,'observed_policy_rows':1,'observed_service_rows':12}))
            (w/'EXP10_policy_runs.csv').write_text('trial,load_target_pct,load_observed_pct,traffic_mode,policy,success,observed_p95_ack_gap_ms,global_deadline_met\n1,10,10,steady,B4,True,2.1,True\n')
            (w/'EXP10_service_events.csv').write_text('service,hybrid_verified\nS01,1\n')
            p=subprocess.run([sys.executable,str(ROOT/'analyze_exp10.py'),'--results-dir',str(w)],capture_output=True,text=True)
            self.assertNotEqual(p.returncode,0)
            self.assertIn('service records are incomplete',p.stderr+p.stdout)
            self.assertFalse((w/'EXP10_analysis.json').exists())
    def test_smoke_rejects_wrong_trial_count(self):
        STUDIES.mkdir(parents=True,exist_ok=True)
        with tempfile.TemporaryDirectory(prefix='negative_fixture_',dir=STUDIES) as work:
            w=pathlib.Path(work)
            (w/'EXP10_COMPLETED.json').write_text(json.dumps({'status':'COMPLETED_ON_PRIVILEGED_SDN_HOST','trial_blocks':1,'policies':['B4'],'loads':[10],'modes':['steady'],'expected_policy_rows':0,'observed_service_rows':0}))
            (w/'EXP10_policy_runs.csv').write_text('trial,policy\n')
            (w/'EXP10_service_events.csv').write_text('service,hybrid_verified\n')
            p=subprocess.run([sys.executable,str(ROOT/'scripts/check_smoke.py'),'--results-dir',str(w)],capture_output=True,text=True)
            self.assertNotEqual(p.returncode,0)
            self.assertIn('wrong sizes',p.stdout+p.stderr)
            self.assertFalse(json.loads((w/'EXP10_smoke_gate.json').read_text())['accepted'])
if __name__=='__main__':unittest.main()
