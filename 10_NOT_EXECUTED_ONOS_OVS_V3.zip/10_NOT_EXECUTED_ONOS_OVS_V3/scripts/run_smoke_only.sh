#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
[[ $(id -u) -eq 0 ]] || { echo 'Use sudo on an authorized isolated Ubuntu machine' >&2;exit 2; }
/usr/bin/python3 scripts/check_environment.py
[[ -x bin/tls_app && -r certs/server.crt && -r certs/server.key ]] || { echo 'Build TLS first' >&2;exit 3; }
bash scripts/start_onos_270.sh
RUN_ID="smoke_$(date -u +%Y%m%dT%H%M%S)_$$_${RANDOM}"
RUN_DIR="results/studies/$RUN_ID"
echo "RUN_ID=$RUN_ID"
/usr/bin/python3 exp10_mininet.py --run-id "$RUN_ID" --trials 3 --modes steady --loads 10 --workers 4 --verbose
/usr/bin/python3 scripts/check_smoke.py --results-dir "$RUN_DIR"
/usr/bin/python3 analyze_exp10.py --results-dir "$RUN_DIR"
(cd "$RUN_DIR" && sha256sum *.csv *.json > FILES_SHA256.txt)
echo "Smoke passed: $RUN_DIR. Full run requires explicit EXP10_CONFIRM_FULL=YES."
