#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
[[ $(id -u) -eq 0 ]] || { echo 'Requires root on the authorized lab machine' >&2;exit 3; }
[[ "${EXP10_CONFIRM_FULL:-}" == 'YES' ]] || { echo 'Set EXP10_CONFIRM_FULL=YES to authorize long experiments' >&2;exit 4; }
/usr/bin/python3 scripts/check_environment.py
[[ -x bin/tls_app && -r certs/server.crt && -r certs/server.key ]] || { echo 'Run build_tls35.sh first' >&2;exit 5; }
bash scripts/start_onos_270.sh
RUN_ID="smoke_$(date -u +%Y%m%dT%H%M%S)_$$_${RANDOM}"
RUN_DIR="results/studies/$RUN_ID"
/usr/bin/python3 exp10_mininet.py --run-id "$RUN_ID" --trials 3 --modes steady --loads 10 --workers 4
/usr/bin/python3 scripts/check_smoke.py --results-dir "$RUN_DIR"
/usr/bin/python3 analyze_exp10.py --results-dir "$RUN_DIR"
(cd "$RUN_DIR" && sha256sum *.csv *.json > FILES_SHA256.txt)
echo "SMOKE ACCEPTED: $RUN_DIR"
for mode in steady bursty high_arrivals; do
 for load in 10 25 50 75 90; do
  RUN_ID="study_${mode}_${load}_$(date -u +%Y%m%dT%H%M%S)_$$_${RANDOM}"
  RUN_DIR="results/studies/$RUN_ID"
  echo "START: $RUN_ID" >&2
  # stdout/stderr go to unique log, not to a shared stale result directory
  mkdir -p results/launcher_logs
  /usr/bin/python3 exp10_mininet.py --run-id "$RUN_ID" --trials 500 --modes "$mode" --loads "$load" --workers 4     --campaign-deadline-ms 3000 --endpoint-deadline-ms 750 >"results/launcher_logs/$RUN_ID.log" 2>&1
  /usr/bin/python3 analyze_exp10.py --results-dir "$RUN_DIR"
  (cd "$RUN_DIR" && sha256sum *.csv *.json > FILES_SHA256.txt)
  echo "VERIFIED: $RUN_ID" >&2
 done
done
echo 'All conditions launched and validated. Inspect failure rates and campaign deadlines before writing conclusions.'
