#!/usr/bin/env python3
"""Reject stale, duplicated, incomplete or unsuccessful ONOS smoke runs."""
from pathlib import Path
import argparse,csv,json
P=argparse.ArgumentParser();P.add_argument('--results-dir',required=True)
a=P.parse_args();base=Path(__file__).resolve().parents[1];r=Path(a.results_dir).resolve()
if not r.is_relative_to((base/'results'/'studies').resolve()):raise SystemExit('SMOKE FAIL: wrong results root')
if not (r/'EXP10_COMPLETED.json').is_file():raise SystemExit('SMOKE FAIL: no verified completion marker')
meta=json.loads((r/'EXP10_COMPLETED.json').read_text())
if meta.get('status')!='COMPLETED_ON_PRIVILEGED_SDN_HOST':raise SystemExit('SMOKE FAIL: invalid completion status')
def read(name):
 with (r/name).open(newline='') as f:return list(csv.DictReader(f))
rows=read('EXP10_policy_runs.csv');ev=read('EXP10_service_events.csv')
pols={'B1','B2','B3','B4','P1','P1_v1.1'};issues=[]
if meta.get('trial_blocks')!=3 or set(meta.get('policies',[]))!=pols or meta.get('loads')!=[10] or meta.get('modes')!=['steady']:issues.append('incorrect smoke configuration')
if len(rows)!=18 or len(ev)!=216:issues.append(f'wrong sizes: runs={len(rows)}, services={len(ev)}')
if len(rows)!=meta.get('expected_policy_rows') or len(ev)!=meta.get('observed_service_rows'):issues.append('marker count mismatch')
keys=[(x['traffic_mode'],x['load_target_pct'],x['trial'],x['policy']) for x in rows]
if len(set(keys))!=len(keys):issues.append('duplicated trial/policy keys')
for n in range(1,4):
 rr=[x for x in rows if x.get('trial')==str(n)]
 if set(x.get('policy') for x in rr)!=pols or len(rr)!=6:issues.append(f'trial {n}: incomplete strategies')
for x in rows:
 if any(x.get(c)!='True' for c in ('success','controller_flow_staging_verified','load_within_tolerance','global_deadline_met')):issues.append('failed success/controller/load/deadline: '+repr(x.get('policy')))
 if int(x.get('unsafe_downgrade_events','0')):issues.append('unsafe downgrade')
 if int(x.get('completed_sessions','0'))!=12:issues.append('not 12 completed sessions')
for x in ev:
 if x.get('hybrid_verified')!='1' or x.get('classical_verified')!='1' or x.get('unsafe_downgrade')!='0' or x.get('deadline_expired')!='0':issues.append('service endpoint cryptographic/deadline violation')
report={'stage':'STRICT_SMOKE_GATE_V3','run_id':meta.get('run_id'),'checks':len(rows),'accepted':not issues,'issues':issues[:60]}
(r/'EXP10_smoke_gate.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
if issues:raise SystemExit(2)
