# EXP-10 complete implementation kit — SDN/PQC Migration (v2)

**Locked manuscript title:** Controller-Orchestrated Crypto-Agile Post-Quantum Migration for Scalable Software-Defined Networks

**Status (28 October 2026):** Source and local endpoint tests are executed; **NO ONOS/OpenFlow experiment has been executed** in this ChatGPT runtime. This container cannot create veth/network namespaces (CAP_NET_ADMIN absent), and Docker, OVS, Mininet and ONOS are unavailable. The full EXP-10A–F experiment needs an authorized Ubuntu 24.04 computer with network-admin privileges. Treat these scripts as integration-ready **but not yet validated against the real ONOS/OVS deployment**. Do not cite any of their simulated or unit-test outputs as SDN performance results.

## What v2 adds over the previous kit

* Genuine ONOS northbound **POST/GET/DELETE flow-rule lifecycle** via `src/onos_flow_manager.py`, rather than readiness monitoring alone. Rules are restricted to two known OVS datapath IDs and four allowed endpoint IPs. High-priority IPv4/TCP output actions are generated from the **actual Mininet port map**, not guessed switch-port numbers.
* Base classical path is installed after ONOS topology discovery. A new hybrid-PQC path is installed and checked (`ADDED`) before a migration campaign, and it is removed after the campaign. The same flow-stage semantics and controller deadline accounting are applied to every strategy. ONOS read-side verification of configured rules is implemented; packet-counter evidence must still be checked on your lab host.
* Fail-safe cleanup on partial POST error, strict 3-block smoke gate, per-condition CSV copies and SHA-256 manifests.
* Automatic isolated OpenSSL 3.5.9 LTS installer that checks the official SHA-256, without replacing Ubuntu system OpenSSL.
* Immutable legacy P1 baseline, baseline policies B1/B2/B3/B4, and **exploratory** P1-v1.1. Same worker ceiling and TLS groups; differences in scheduled batch size/serial behavior are intrinsic to each policy.
* Real endpoint request/response TLS 1.3 over Mininet, MBB transition, per-endpoint deadline; global campaign-time guard, 5 load levels, 3 traffic modes, real achieved-link-byte counts, statistical analysis.

## Architecture

Seven **logical roles** on ONE lab computer (not 7 distinct virtual machines):

```text
          C0: Docker ONOS 2.7.0 + Python migration orchestrator
                        (host management)
                OpenFlow 1.3     ONOS REST
              /                        \
CL1 10.10.10.11 -- SW1 OVS 3.3.9 -- SW2 OVS 3.3.9 -- SR1 10.10.10.21
CL2 10.10.10.12 --/     shared link       \-- SR2 10.10.10.22
```

Four client/server endpoints run in network namespaces provided by Mininet; both switches are **real Open vSwitch instances**, under ONOS control. The controller is in a Docker container, and the migration scheduler runs on the host. The locked seven-physical-PC H1.0 configuration remains a **separate future validation**.

## Run this on a dedicated Ubuntu 24.04 laboratory computer

Do **not** run on production networks. You will need 16+ GiB RAM, internet access at installation time, sudo, and free local ports 6653 and 8181.

```bash
cd EXP10_Full_SDN_Migration_V2
sudo bash scripts/install_ubuntu24.sh
sudo bash scripts/install_openssl35.sh
sudo bash scripts/build_tls35.sh
sudo bash scripts/run_smoke_only.sh
```

The OpenSSL installer downloads the official 3.5.9 LTS source archive and official SHA-256 checksum, builds under `/opt/openssl-3.5` and does not touch the OS OpenSSL. The build script links `tls_app` explicitly to that prefix. Generated lab-only certificates are short-lived, ECDSA P-256 and self-signed; never use these in production.

**Important:** smoke test must verify controller rules, both physical emulated datapaths, correct negotiated TLS groups, 12 completed hybrid cutovers, observed load within tolerance, successful safe teardown and global deadline for **each** of the 18 policy executions. If any fail, it stops and does **not** launch the full study. Inspect `results/EXP10_smoke_gate.json`, `results/sdn_ready.json` and the application/ONOS logs. ONOS 2.7 API details may need adjustment after the first live deployment.

When the smoke test is *actually* successful, run the complete trial matrix:

```bash
sudo -E env EXP10_CONFIRM_FULL=YES bash scripts/run_full_exp10_lab.sh
```

This executes **6 policies × 3 traffic modes × 5 targeted loads × 500 trial blocks = 45,000 policy executions**, covering 12 TLS sessions per run. The design allows up to **540,000 attempted cutovers**, not a claim that they already happened. Conditions are saved separately beneath `results/full_study/` and include checksums; failed runs must be reported, never dropped. If a condition fails, preserve the logs and investigate rather than silently re-running until it passes. Do not publish results from failed readiness checks.

### Locked comparisons

* B1: bulk
* B2: fixed batch
* B3: fixed-rate serialized stages
* B4: load-aware greedy (principal baseline)
* P1: **frozen** deadline/security-aware load-adaptive scheduler, unchanged
* P1-v1.1: exploratory development candidate with deadline-guarded LPT ordering; **not** the final proposed method

The offered background loads are 10%, 25%, 50%, 75%, 90% of calibrated throughput, under steady, bursty and high-connection-arrival profiles. **Observed utilization** is independently derived from OVS interface counters and recorded. Failed load-control conditions count as invalid; offered load is not a substitute for measured achieved load.

### Metrics and limitations

Policy-run CSV: achieved load, measured per-run p95 application inter-response gap, p95 excess gap, migration campaign elapsed time (including ONOS REST staging), controller flow staging duration, deadline success, attempted vs completed sessions, failures and unsafe downgrades. Service CSV: 12 per-run session records, handshake timing, old/new response counts and deadline flags. ONOS resource snapshots are coarse condition-level measures, **not** isolated per-migration overhead. Service inter-response gaps are observations and are **not a direct measurement of the complete service-unavailable interval**. Only final verified successful runs may be used for conditional p95 comparisons; failure rates must be reported separately.

The global campaign deadline is checked before each batch and at campaign completion. **It cannot forcibly interrupt an in-flight synchronous OpenSSL handshake**, so end-to-end hard real-time guarantees and full transactional rollback are NOT validated. Endpoint hybrid negotiation is verified with `X25519MLKEM768`, while ECDSA P-256 remains classical authentication. Unsafe downgrade tests verify negotiation rejection, not a general cryptographic security proof.

## Current local tests

```bash
bash scripts/local_regression.sh
python3 -m unittest discover -s tests -p 'test_*.py' -v
python3 scripts/check_environment.py
```

Here they passed 11 unit tests, four live endpoint deadline/fault scenarios and two group-mismatch rejection tests. The ONOS flow-rule tests operate against an in-memory mocked controller, **not ONOS**. The actual runner refuses to generate false SDN results when environment permissions are missing.

## Research and data integrity

* Source: `src/`, `exp10_mininet.py`, `analyze_exp10.py`, `scripts/`, `tests/`.
* `results/LOCAL_VALIDATION_STATUS.json` describes exactly what has run here.
* Experiment-generated artifacts `results/EXP10_policy_runs.csv` and `results/EXP10_service_events.csv` are deliberately **absent** from the distributed kit until real lab execution.
* No private keys, auto-generated certificates or locally built binaries are distributed.
* Use `results/full_study/<mode>_<load>pct/` as independent condition archives. Copy raw data unchanged and record machine CPU, system load, OVS/ONOS versions, OpenSSL library, software commit/hash, randomization seed, network utilization, traffic errors and dropped packets.
* The single-host Mininet testbed can study **real emulated OpenFlow switching and real TLS application migration** on a privileged host; it cannot replace the separate locked seven-Dell-PC physical H1.0 validation.

## Documented APIs and authoritative references

* [ONOS REST API and flow management](https://wiki.onosproject.org/display/ONOS/Appendix+B%3A+REST+API)
* [ONOS flow rule JSON criteria and instructions](https://wiki.onosproject.org/display/ONOS/Flow+Rules)
* [Practical REST intent/flow examples](https://github.com/jorgelopezcoronado/SDNLab)
* [OpenSSL 3.5 LTS release sources](https://openssl-library.org/source/)

**Frozen research conclusion:** EXP-09B did not establish P1-v1.1 superiority over B4. EXP-10 is intended to determine whether load-aware controller orchestration changes the trade-off on an actual programmable SDN data plane; no superiority is assumed.
