#!/usr/bin/env python3
"""EXP-10A..F genuine ONOS/OVS Mininet runner; RUN ONLY ON PRIVILEGED LAB HOST.

Not executed in ChatGPT sandbox; never labels dry-run/old data as ONOS results.
Seven LOGICAL roles: Docker ONOS controller/orchestrator C0, Mininet OVS
SW1/SW2, namespace clients CL1/CL2 and servers SR1/SR2.
This is not seven separate virtual machines or the seven physical H1.0 PCs.
"""
import argparse, csv, datetime, json, os, random, re, resource, signal, socket, statistics, subprocess, sys, threading, time, urllib.request, base64
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'src'))
from migration_scheduler import load_jobs, plan, chunks
from campaign import CampaignDeadline, CampaignDeadlineExceeded
from onos_flow_manager import ONOSREST, FlowLifecycle, FlowError, build_rules

POLICIES=('B1','B2','B3','B4','P1','P1_v1.1')
LOADS=(10,25,50,75,90)
MODES=('steady','bursty','high_arrivals')
class GateError(RuntimeError): pass

def pct(values,p):
 a=sorted(values); k=(len(a)-1)*(p/100);i=int(k);j=min(len(a)-1,i+1)
 return a[i]+(a[j]-a[i])*(k-i)

def get_onos(path,user='onos',password='rocks'):
 tok=base64.b64encode(f'{user}:{password}'.encode()).decode()
 req=urllib.request.Request(f'http://127.0.0.1:8181/onos/v1/{path}',headers={'Authorization':f'Basic {tok}','Accept':'application/json'})
 with urllib.request.urlopen(req,timeout=7) as r:return json.load(r)

def onos_gate(user,passwd):
 devices=get_onos('devices',user,passwd).get('devices',[])
 available=[d for d in devices if d.get('available')]
 expected={'of:0000000000000001','of:0000000000000002'}
 seen={d.get('id') for d in available}
 if not expected.issubset(seen): raise GateError(f'ONOS has not discovered the expected SW1/SW2 datapath IDs; seen={seen}')
 app=get_onos('applications/org.onosproject.fwd',user,passwd)
 if str(app.get('state','')).upper()!='ACTIVE':raise GateError('ONOS fwd application is not ACTIVE')
 links=get_onos('links',user,passwd).get('links',[])
 if len(links)<2:raise GateError('No verified bidirectional ONOS switch-to-switch links')
 return {'devices':[d.get('id') for d in available],'link_count':len(links),'fwd_state':app.get('state')}

def variant_batches(jobs,policy,parallel,load):
 if policy != 'P1_v1.1':return plan(jobs,policy,observed_network_load=load/100,max_parallel=parallel,fixed_batch=2)
 # Candidate frozen from EXP-07; same guard used in EXP-09B. Not promoted over locked P1.
 ordered=sorted(jobs,key=lambda j:(-j.estimated_cutover_ms,j.id))
 previous=[j for b in plan(jobs,'P1',observed_network_load=load/100,max_parallel=parallel) for j in b]
 def deadline_misses(seq):
  workers=[0.0]*parallel;count=0
  for job in seq:
   i=workers.index(min(workers));workers[i]+=job.estimated_cutover_ms;count+=workers[i]>job.deadline_ms
  return count
 return chunks(ordered if deadline_misses(ordered)<=deadline_misses(previous) else previous,parallel)

class Experiment:
 def __init__(self,args):
  self.args=args;self.net=None;self.servers=[];self.bg=[];self.bglogs=[];self.events=[];self.runs=[];self.logdir=ROOT/'logs';self.resdir=ROOT/'results';self.logdir.mkdir(exist_ok=True);self.resdir.mkdir(exist_ok=True)
  self.jobs=load_jobs();self.rng=random.Random(args.seed);self.flow_control=None;self.flow_ports={};self.control_audit=[]
 def launch(self):
  # Deferred import permits unprivileged dry-run and unit testing.
  from mininet.net import Mininet
  from mininet.node import RemoteController, OVSSwitch
  from mininet.link import TCLink
  # The controller is the ONOS Docker container, with orchestration in this runner.
  # Mininet OVS switches are root-namespace processes; four endpoints are namespaces.
  net=Mininet(controller=None,switch=OVSSwitch,link=TCLink,autoSetMacs=True,build=False)
  net.addController('c0',controller=RemoteController,ip='127.0.0.1',port=6653)
  self.cl1=net.addHost('cl1',ip='10.10.10.11/24')
  self.cl2=net.addHost('cl2',ip='10.10.10.12/24')
  self.sr1=net.addHost('sr1',ip='10.10.10.21/24')
  self.sr2=net.addHost('sr2',ip='10.10.10.22/24')
  self.sw1=net.addSwitch('sw1',protocols='OpenFlow13',failMode='secure',dpid='0000000000000001')
  self.sw2=net.addSwitch('sw2',protocols='OpenFlow13',failMode='secure',dpid='0000000000000002')
  bw=self.args.bottleneck_mbps
  net.addLink(self.cl1,self.sw1,bw=bw)
  net.addLink(self.cl2,self.sw1,bw=bw)
  net.addLink(self.sw1,self.sw2,bw=bw,delay='1ms')
  net.addLink(self.sw2,self.sr1,bw=bw)
  net.addLink(self.sw2,self.sr2,bw=bw)
  self.net=net
  net.build();net.start()
  self.backbone=self.sw1.connectionsTo(self.sw2)[0][0].name
  try:
   for tries in range(35):
    try:
     status=onos_gate(self.args.onos_user,self.args.onos_pass)
     break
    except Exception:
     time.sleep(1)
   else:status=onos_gate(self.args.onos_user,self.args.onos_pass)
   self.onos_status=status
   lost=net.ping([self.cl1,self.sr1,self.cl2,self.sr2],timeout='1')
   if lost>0:raise GateError(f'Network connectivity failed: {lost}% packet loss')
   flows=subprocess.run(['ovs-ofctl','-O','OpenFlow13','dump-flows','sw1'],capture_output=True,text=True,check=True).stdout
   if flows.count('cookie=')<1:raise GateError('sw1 has no installed OpenFlow rules; stop')
   # Instantiate a tightly scoped northbound flow-rule manager only after
   # the controller, topology, link and forwarding gates have passed.
   def swport(sw,neighbor):
    links=sw.connectionsTo(neighbor)
    if len(links)!=1:raise GateError(f'Expected one physical edge between {sw.name} and {neighbor.name}')
    return int(sw.ports[links[0][0]])
   self.flow_ports={
      'cl1':swport(self.sw1,self.cl1), 'cl2':swport(self.sw1,self.cl2),
      'sr1':swport(self.sw2,self.sr1), 'sr2':swport(self.sw2,self.sr2),
      'sw1_backbone':swport(self.sw1,self.sw2),
      'sw2_backbone':swport(self.sw2,self.sw1)}
   self.flow_control=FlowLifecycle(ONOSREST(username=self.args.onos_user,password=self.args.onos_pass),timeout_s=20.)
   self.flow_control.install(build_rules(self.flow_ports,hybrid=False),'classical')
   (self.resdir/'controller_classical_path.json').write_text(json.dumps({'port_map':self.flow_ports,'flows':self.flow_control.audit},indent=2))
   (self.resdir/'sdn_ready.json').write_text(json.dumps({'onos':status,'backbone':self.backbone,'network_ping_loss_pct':lost,'flow_dump':flows[:12000]},indent=2))
  except BaseException:
   self.stop();raise
 def calibrate_capacity(self):
  # Independent TCP throughput baseline on the same CL1->SW1->SW2->SR2 path.
  l=open(self.logdir/'iperf_calibration.stderr','w')
  server=self.sr2.popen(['iperf3','-s','-1','-p','5202'],stdout=l,stderr=subprocess.STDOUT)
  time.sleep(.35)
  cli=self.cl1.popen(['iperf3','-c','10.10.10.22','-p','5202','-t','2','-J'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
  try:
   out,err=cli.communicate(timeout=12)
   if cli.returncode:raise GateError('iperf3 calibration failed: '+err[:200])
   data=json.loads(out)
   bps=data['end']['sum_received']['bits_per_second']
   self.measured_capacity_mbps=bps/1e6
   if self.measured_capacity_mbps<1:raise GateError('Measured backbone capacity is below 1 Mbps')
   (self.resdir/'capacity_calibration.json').write_text(json.dumps({'protocol':'TCP iperf3','measured_capacity_mbps':self.measured_capacity_mbps,'TCLink_configured_mbps':self.args.bottleneck_mbps,'payload':data.get('end',{})},indent=2))
  finally:
   if server.poll() is None:server.terminate()
   try:server.wait(timeout=2)
   except subprocess.TimeoutExpired:server.kill();server.wait()
   l.close()
 def boot_tls(self):
  for role,host,ip,old,new in (('SR1',self.sr1,'10.10.10.21','31031','32031'),('SR2',self.sr2,'10.10.10.22','31032','32032')):
   p=host.popen([str(ROOT/'bin/tls_app'),'server','--bind',ip,'--old-port',old,'--new-port',new,'--cert',str(ROOT/'certs/server.crt'),'--key',str(ROOT/'certs/server.key')],stdout=subprocess.PIPE,stderr=open(self.logdir/f'{role}.stderr','w'),stdin=subprocess.DEVNULL,text=True,bufsize=1)
   self.servers.append(p)
   line=p.stdout.readline().strip()
   if not line.startswith('READY '):raise GateError(f'{role} did not start: {line}')
 def endpoint(self,job):
  i=int(job.id[1:])
  return (self.cl1,'10.10.10.21',31031,32031) if i%2 else (self.cl2,'10.10.10.22',31032,32032)
 def start_one(self,job,period_us):
  host,ip,old,new=self.endpoint(job)
  p=host.popen([str(ROOT/'bin/tls_app'),'client','--host',ip,'--old-port',str(old),'--new-port',str(new),'--ca',str(ROOT/'certs/server.crt'),'--mode','mbb','--deadline-ms',str(self.args.endpoint_deadline_ms),'--period-us',str(period_us)],stdout=subprocess.PIPE,stdin=subprocess.PIPE,stderr=open(self.logdir/'tls_clients.stderr','a'),text=True,bufsize=1)
  line=p.stdout.readline().strip()
  if not line.startswith('READY classical_verified=1'):
   p.kill();raise RuntimeError(f'{job.id} classical TLS failed: {line}')
  return (job,p)
 def migrate_one(self,entry):
  job,p=entry
  p.stdin.write('MIGRATE\n');p.stdin.flush()
  line=p.stdout.readline().strip()
  return {'service':job.id,'migration_log':line,'migration_valid':line.startswith('MIGRATED ok=1')}
 def stop_one(self,entry):
  job,p=entry
  if p.poll() is not None:return {'service':job.id,'missing_result':True,'rc':p.returncode}
  try:p.stdin.write('STOP\n');p.stdin.flush();line=p.stdout.readline().strip()
  except (BrokenPipeError,OSError):line=''
  try:p.stdin.close()
  except (OSError,ValueError):pass
  try:rc=p.wait(timeout=4)
  except subprocess.TimeoutExpired:p.kill();rc=p.wait(timeout=4)
  if not line.startswith('RESULT '):return {'service':job.id,'rc':rc,'missing_result':True}
  val=json.loads(line[7:]);val.update({'service':job.id,'rc':rc});return val
 def sample_link(self):
  # Monotonic bytes on shared OVS backbone; measured on the actual emulated datapath.
  path=Path('/sys/class/net')/self.backbone/'statistics/tx_bytes'
  return int(path.read_text())
 def start_background(self,load,mode):
  self.stop_background()
  sinklog=open(self.logdir/f'sink_{load}_{mode}.log','w');self.bglogs.append(sinklog)
  sink=self.sr2.popen([sys.executable,str(ROOT/'src/traffic_load.py'),'sink','--port','53000'],stdout=sinklog,stderr=subprocess.STDOUT)
  self.bg.append(sink);time.sleep(.2)
  traffic_mode='bursty' if mode=='bursty' else 'steady'
  tgtrate=self.measured_capacity_mbps*(load/100.0)
  sendlog=open(self.logdir/f'traffic_{load}_{mode}.log','w');self.bglogs.append(sendlog)
  loadp=self.cl1.popen([sys.executable,str(ROOT/'src/traffic_load.py'),traffic_mode,'--host','10.10.10.22','--mbps',str(tgtrate),'--port','53000'],stdout=sendlog,stderr=subprocess.STDOUT)
  self.bg.append(loadp)
  if mode=='high_arrivals':
   log=open(self.logdir/f'arrivals_{load}.log','w');self.bglogs.append(log)
   ar=self.cl2.popen([sys.executable,str(ROOT/'src/tls_arrivals.py'),'--dst','10.10.10.21','--cafile',str(ROOT/'certs/server.crt'),'--rate',str(self.args.arrival_rate)],stdout=log,stderr=subprocess.STDOUT)
   self.bg.append(ar)
  time.sleep(1)
  if any(p.poll() is not None for p in self.bg):raise GateError('Background cross traffic failed to start')
 def stop_background(self):
  for p in self.bg:
   if p.poll() is None:p.terminate()
   try:p.wait(timeout=2)
   except subprocess.TimeoutExpired:p.kill();p.wait(timeout=2)
  self.bg=[]
  for f in self.bglogs:f.close()
  self.bglogs=[]
 def run_policy(self,trial,policy,load,mode):
  """Genuine ONOS path staging and live MBB; global deadline includes REST operations.

  A failure is recorded as failure, never silently recast as a successful cutover.
  Any still-classical endpoint is stopped at campaign teardown (fail closed).
  """
  start=time.monotonic();startbytes=self.sample_link();outcomes=[]
  cpu0=resource.getrusage(resource.RUSAGE_SELF).ru_utime
  entries=[];deadline=self.args.campaign_deadline_ms;miss=False
  flow_elapsed_ms=None;flow_verified=False;flow_error=''
  period_us={'steady':2500,'bursty':2500,'high_arrivals':1400}[mode]
  elapsed_campaign=0.;scheduler_decision_ms=0.
  items=[];stage='hybrid'
  try:
   with ThreadPoolExecutor(max_workers=12) as pool:
    entries=list(pool.map(lambda j:self.start_one(j,period_us),self.jobs))
   time.sleep(.015)
   # Start the GLOBAL clock before path preparation: controller REST time counts.
   camp=CampaignDeadline(deadline)
   try:
    flow_elapsed_ms=self.flow_control.install(build_rules(self.flow_ports,hybrid=True),stage)
    flow_verified=True
   except Exception as exc:
    flow_error=f'controller_flow_install_failed: {type(exc).__name__}: {exc}'
    miss=True
   if flow_verified:
    decision_start=time.monotonic()
    # The planner's network-load input is a measured short-window observation,
    # NOT the target load used by the generator.
    pre_bytes=self.sample_link();pre_t=time.monotonic();time.sleep(.10)
    obs_bytes=self.sample_link();delta=max(1e-4,time.monotonic()-pre_t)
    observed_load=min(100.,max(0.,100*(obs_bytes-pre_bytes)*8/delta/(self.measured_capacity_mbps*1e6)))
    batches=variant_batches(self.jobs,policy,self.args.workers,observed_load)
    scheduler_decision_ms=(time.monotonic()-decision_start)*1000
    entrymap={j.id:(j,p) for j,p in entries}
    for n,batch in enumerate(batches):
     try:camp.assert_valid()
     except CampaignDeadlineExceeded:
      miss=True;break
     with ThreadPoolExecutor(max_workers=self.args.workers) as pool:
      outcomes.extend(pool.map(lambda j:self.migrate_one(entrymap[j.id]),batch))
     if n<len(batches)-1 and policy=='B2':time.sleep(.008)
     if n<len(batches)-1 and policy=='B3':time.sleep(.005)
    elapsed_campaign=camp.elapsed_ms()
    if elapsed_campaign>=deadline:miss=True
   else:
    elapsed_campaign=camp.elapsed_ms()
   time.sleep(.005)
  finally:
   with ThreadPoolExecutor(max_workers=12) as pool:
    items=list(pool.map(self.stop_one,entries)) if entries else []
   if self.flow_control is not None:
    try:self.flow_control.remove(stage)
    except FlowError as e:flow_error+='; flow_cleanup_failed: '+str(e)
  endbytes=self.sample_link();end=time.monotonic();wall=(end-start)*1000
  util=max(0,(endbytes-startbytes)*8/max(1e-6,end-start)/(self.measured_capacity_mbps*1e6)*100)
  load_ok=abs(util-load)<=max(5.0,0.20*load)
  valid=not miss and flow_verified and not flow_error and load_ok and len(items)==12 and len(outcomes)==12 and all(
   x.get('rc')==0 and x.get('classical_verified') and x.get('hybrid_verified') and x.get('new_preflight_ok')
   and x.get('old_responses',0)>0 and x.get('new_responses',0)>0 and not x.get('unsafe_downgrade')
   and not x.get('deadline_expired') and x.get('hybrid_ready_before_old_close') for x in items)
  event={'trial':trial,'load_target_pct':load,'load_observed_pct':util,'traffic_mode':mode,'policy':policy,
    'load_within_tolerance':load_ok,'global_deadline_ms':deadline,'campaign_elapsed_ms':elapsed_campaign,
    'global_deadline_met':not miss,'run_wall_ms_including_harness':wall,
    'controller_flow_staging_verified':flow_verified,'controller_flow_staging_ms':flow_elapsed_ms,
    'controller_flow_error':flow_error,'success':valid,
    'completed_sessions':sum(bool(x.get('hybrid_verified')) for x in items),
    'observed_p95_ack_gap_ms':pct([x['ack_gap_ms'] for x in items if x.get('ack_gap_ms',-1)>=0],95) if any(x.get('ack_gap_ms',-1)>=0 for x in items) else None,
    'observed_p95_excess_ack_gap_ms':pct([x['excess_gap_ms'] for x in items if x.get('excess_gap_ms',-1)>=0],95) if any(x.get('excess_gap_ms',-1)>=0 for x in items) else None,
    'service_failures':sum(x.get('offline_attempts',0)+x.get('failed_attempts',0) for x in items),
    'unsafe_downgrade_events':sum(x.get('unsafe_downgrade',0) for x in items),
    'orchestrator_cpu_user_delta_s':resource.getrusage(resource.RUSAGE_SELF).ru_utime-cpu0,
    'scheduler_decision_ms':scheduler_decision_ms,
    'failure_logs':json.dumps([x for x in outcomes if not x['migration_valid']])}
  for x in items:x.update({'trial':trial,'load_target_pct':load,'load_observed_pct':round(util,3),'traffic_mode':mode,'policy':policy})
  self.events.extend(items);self.runs.append(event)
  if not valid:print(f'WARNING failed trial={trial} load={load} mode={mode} policy={policy} flow_error={flow_error}',flush=True)
  return event
 def flush(self):
  for key,rows,name in [('runs',self.runs,'EXP10_policy_runs.csv'),('events',self.events,'EXP10_service_events.csv')]:
   if not rows:continue
   columns=sorted({k for x in rows for k in x})
   with (self.resdir/name).open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=columns,extrasaction='ignore');w.writeheader();w.writerows(rows)
 def sample_controller_resources(self,mode,load):
  # Coarse controller Docker CPU/RAM snapshot; not a per-migration delta.
  try:
   p=subprocess.run(['docker','stats','--no-stream','--format','{{json .}}','exp10-onos'],capture_output=True,text=True,timeout=10)
   obj=json.loads(p.stdout.strip()) if p.returncode==0 and p.stdout.strip() else {'error':p.stderr[:300]}
  except Exception as e:obj={'error':str(e)}
  with (self.resdir/'EXP10_ONOS_resource_snapshots.jsonl').open('a') as f:f.write(json.dumps({'mode':mode,'target_load_pct':load,'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'docker_stats':obj})+'\n')
 def run(self):
  self.launch()
  try:
   self.calibrate_capacity()
   self.boot_tls()
   for mode in self.args.modes:
    for load in self.args.loads:
     self.start_background(load,mode)
     self.sample_controller_resources(mode,load)
     try:
      for trial in range(1,self.args.trials+1):
       cond=list(self.args.policies);self.rng.shuffle(cond)
       for pol in cond:
        e=self.run_policy(trial,pol,load,mode)
        if self.args.verbose:print(json.dumps({k:e[k] for k in ('trial','load_target_pct','load_observed_pct','policy','success','observed_p95_ack_gap_ms')}),flush=True)
       if trial%10==0:
        self.flush();print(f'{mode} target={load}% trial={trial}/{self.args.trials}',flush=True)
     finally:self.stop_background()
   self.flush()
   final={'status':'EXECUTED_ON_PRIVILEGED_SDN_HOST','run_count':len(self.runs),'event_count':len(self.events),'success_count':sum(bool(r['success']) for r in self.runs),'source':'ONOS2.7.0/OVS3.3.9 if preflight enforced','interpretation':'Observed application inter-response gaps, not direct service-unavailable intervals'}
   (self.resdir/'execution_summary.json').write_text(json.dumps(final,indent=2))
  finally:self.stop()
 def stop(self):
  self.stop_background()
  if self.flow_control is not None:
   try:self.flow_control.remove_all()
   except FlowError as exc:print('WARNING controller flow cleanup:',exc,file=sys.stderr)
   finally:self.flow_control=None
  for p in self.servers:
   if p.poll() is None:p.terminate()
   try:p.wait(timeout=2)
   except subprocess.TimeoutExpired:p.kill();p.wait()
  self.servers=[]
  if self.net is not None:self.net.stop();self.net=None

def main():
 p=argparse.ArgumentParser()
 p.add_argument('--trials',type=int,default=3)
 p.add_argument('--workers',type=int,choices=(2,4),default=4)
 p.add_argument('--loads',type=int,nargs='+',choices=LOADS,default=list(LOADS))
 p.add_argument('--modes',nargs='+',choices=MODES,default=['steady'])
 p.add_argument('--policies',nargs='+',choices=POLICIES,default=list(POLICIES))
 p.add_argument('--bottleneck-mbps',type=float,default=100)
 p.add_argument('--campaign-deadline-ms',type=float,default=3000)
 p.add_argument('--endpoint-deadline-ms',type=float,default=750)
 p.add_argument('--arrival-rate',type=float,default=40)
 p.add_argument('--seed',type=int,default=20261028)
 p.add_argument('--onos-user',default=os.environ.get('ONOS_USER','onos'))
 p.add_argument('--onos-pass',default=os.environ.get('ONOS_PASS','rocks'))
 p.add_argument('--verbose',action='store_true')
 p.add_argument('--dry-run',action='store_true',help='Only output policy schedule and preflight, NEVER start emulation')
 a=p.parse_args()
 if a.trials<1 or a.campaign_deadline_ms<1 or a.bottleneck_mbps<=0:p.error('invalid trial/deadline/link parameters')
 if a.dry_run:
  jobs=load_jobs()
  for v in (10,50,90):
   for policy in POLICIES:
    batches=variant_batches(jobs,policy,a.workers,v)
    print(json.dumps({'mode':'dry_run_no_sdn','policy':policy,'load':v,'workers':a.workers,'batches':[[j.id for j in b] for b in batches]}))
  return
 if os.geteuid()!=0:raise GateError('Require root on authorized Ubuntu test computer')
 from scripts.check_environment import main as preflight
 if preflight()!=0:raise GateError('Missing required CAP_NET_ADMIN / OVS 3.3.9 / Mininet / OpenSSL 3.5.x; NO SDN RESULTS')
 if not (ROOT/'bin/tls_app').exists():raise GateError('Build TLS endpoints with scripts/build_tls35.sh')
 Experiment(a).run()
if __name__=='__main__':
 try:main()
 except (GateError,ImportError) as e:print('EXP10 BLOCKED:',e,file=sys.stderr);sys.exit(3)
