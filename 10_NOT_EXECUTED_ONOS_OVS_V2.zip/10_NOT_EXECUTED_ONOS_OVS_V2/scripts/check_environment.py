#!/usr/bin/env python3
"""Read-only EXP-10 environmental gate; never creates network interfaces."""
import ctypes, json, os, pathlib, platform, shutil, subprocess, sys, datetime
from pathlib import Path
OUT=Path(__file__).resolve().parents[1]/'results'/'environment_gate.json'

def run(cmd):
 try:
  p=subprocess.run(cmd,capture_output=True,text=True,timeout=5)
  return {'rc':p.returncode,'output':(p.stdout+' '+p.stderr).strip()[:400]}
 except (FileNotFoundError,subprocess.TimeoutExpired) as e:return {'rc':127,'output':str(e)}

def main():
 c=int(next(x.split(':',1)[1].strip() for x in Path('/proc/self/status').read_text().splitlines() if x.startswith('CapEff:')),16)
 probes={name:run(cmd) for name,cmd in {
  'openssl':['openssl','version'],'ovs':['ovs-vsctl','--version'],
  'docker':['docker','--version'],'ip':['ip','-V'],
  'iperf3':['iperf3','--version'],'tc':['tc','-V'],
  'gcc':['gcc','--version'],'mininet':['/usr/bin/python3','-c','import mininet.net; print("Mininet import OK")']
 }.items()}
 # Never attempt unshare or configure interfaces: read capabilities alone.
 gates={
  'linux':sys.platform=='linux',
  'cap_net_admin':bool(c&(1<<12)),
  'cap_sys_admin':bool(c&(1<<21)),
  'ovs_3_3_9':probes['ovs']['rc']==0 and '3.3.9' in probes['ovs']['output'],
  'openssl_3_5_x':probes['openssl']['rc']==0 and 'OpenSSL 3.5.' in probes['openssl']['output'],
  'mininet_available':probes['mininet']['rc']==0,
  'docker_available':probes['docker']['rc']==0,
  'iperf3_available':probes['iperf3']['rc']==0,
  'tc_available':probes['tc']['rc']==0}
 r={'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'machine':platform.platform(),'memory_kib':None,
 'testbed':'EXP-10 7 virtual roles; NOT physical H1.0',
 'probes':probes,'gates':gates,'eligible_for_sdn':all(gates.values()),
 'warning':'Availability/privilege check only; no ONOS/OVS or link actually exercised by this script.'}
 try:r['memory_kib']=int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemTotal:')))
 except Exception: pass
 OUT.parent.mkdir(parents=True,exist_ok=True);OUT.write_text(json.dumps(r,indent=2))
 print(json.dumps({'eligible_for_sdn':r['eligible_for_sdn'],'gates':gates,'saved':str(OUT)},indent=2))
 return 0 if r['eligible_for_sdn'] else 2
if __name__=='__main__':raise SystemExit(main())
