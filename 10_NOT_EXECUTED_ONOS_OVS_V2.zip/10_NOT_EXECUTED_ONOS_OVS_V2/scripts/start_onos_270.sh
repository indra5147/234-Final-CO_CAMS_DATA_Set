#!/usr/bin/env bash
set -euo pipefail
# Starts a LOCAL Docker ONOS 2.7.0 container. Does not expose to public network.
[[ $(id -u) -eq 0 ]] || { echo 'Run under sudo'; exit 2; }
command -v docker >/dev/null || { echo 'Docker missing'; exit 2; }
if docker container inspect exp10-onos >/dev/null 2>&1; then
 img=$(docker inspect --format '{{.Config.Image}}' exp10-onos)
 [[ $img == 'onosproject/onos:2.7.0' ]] || { echo "Unexpected image $img" >&2; exit 3; }
 docker start exp10-onos >/dev/null
else
 docker run -d --name exp10-onos --restart no \
  -p 127.0.0.1:6653:6653 -p 127.0.0.1:8181:8181 \
  -e ONOS_APPS=drivers,openflow,fwd \
  onosproject/onos:2.7.0 >/dev/null
fi
# Caller will check REST devices and fwd application status before migrations.
echo 'ONOS image onosproject/onos:2.7.0 started; readiness is NOT yet asserted.'
