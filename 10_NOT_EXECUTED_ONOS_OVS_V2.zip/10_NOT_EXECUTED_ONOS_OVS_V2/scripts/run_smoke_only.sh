#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
[[ $(id -u) -eq 0 ]] || { echo 'Use sudo on authorized isolated Ubuntu machine' >&2;exit 2; }
/usr/bin/python3 scripts/check_environment.py
[[ -x bin/tls_app && -r certs/server.crt && -r certs/server.key ]] || { echo 'Build TLS first' >&2;exit 3; }
bash scripts/start_onos_270.sh
/usr/bin/python3 exp10_mininet.py --trials 3 --modes steady --loads 10 --workers 4 --verbose
/usr/bin/python3 scripts/check_smoke.py
/usr/bin/python3 analyze_exp10.py
printf 'Smoke passed. SDN data in results/*.csv. Full run requires explicit EXP10_CONFIRM_FULL=YES.\n'
