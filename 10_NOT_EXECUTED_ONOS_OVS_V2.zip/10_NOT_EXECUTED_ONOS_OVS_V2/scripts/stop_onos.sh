#!/usr/bin/env bash
set -euo pipefail
[[ $(id -u) -eq 0 ]] || { echo 'Run under sudo';exit 2; }
docker stop exp10-onos >/dev/null || true
echo 'exp10-onos stopped (container preserved).'
