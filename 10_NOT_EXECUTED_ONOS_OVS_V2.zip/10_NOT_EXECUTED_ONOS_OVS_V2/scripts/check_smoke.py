#!/usr/bin/env python3
"""Strict acceptance gate: don't proceed to 45,000-run study on an invalid smoke test."""
from pathlib import Path
import csv,json,sys
p=Path(__file__).resolve().parents[1]/'results/EXP10_policy_runs.csv'
if not p.exists():raise SystemExit('Smoke gate FAIL: no actual EXP10_policy_runs.csv')
with p.open(newline='') as f:rows=list(csv.DictReader(f))
expected=3*6
issues=[]
if len(rows)!=expected:issues.append(f'{len(rows)} policies, expected {expected}')
policies={'B1','B2','B3','B4','P1','P1_v1.1'}
for trial in range(1,4):
 rs=[x for x in rows if int(x['trial'])==trial]
 if set(r['policy'] for r in rs)!=policies:issues.append(f'trial {trial}: missing or duplicated strategies')
for r in rows:
 if r['success']!='True':issues.append(f"unsuccessful {r['policy']} trial {r['trial']}")
 if r.get('controller_flow_staging_verified')!='True':issues.append('unverified ONOS flow staging')
 if r.get('load_within_tolerance')!='True':issues.append('observed link load outside tolerance')
 if r.get('global_deadline_met')!='True':issues.append('campaign deadline miss')
 if int(r.get('unsafe_downgrade_events','0')):issues.append('unsafe downgrade')
report={'stage':'STRICT_SMOKE_GATE','checks':len(rows),'accepted':not issues,'issues':issues}
p.with_name('EXP10_smoke_gate.json').write_text(json.dumps(report,indent=2))
if issues:
 print(json.dumps(report,indent=2));raise SystemExit(2)
print('Strict SDN smoke gate passed:',len(rows),'verified runs')
