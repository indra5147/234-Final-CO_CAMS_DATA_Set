#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
OPENSSL_PREFIX=${OPENSSL_PREFIX:-/opt/openssl-3.5}
if [[ -x "$OPENSSL_PREFIX/bin/openssl" ]];then
  exp=$($OPENSSL_PREFIX/bin/openssl version)
else
  echo "Missing locked OpenSSL binary $OPENSSL_PREFIX/bin/openssl" >&2;exit 2
fi
[[ $exp == 'OpenSSL 3.5.'* ]] || { echo "Required OpenSSL 3.5.x; got $exp" >&2;exit 2; }
# Explicitly link against selected 3.5 prefix, not Ubuntu libssl3 3.0.
LIB_DIR="$OPENSSL_PREFIX/lib64"; [[ -f "$LIB_DIR/libssl.so" ]] || LIB_DIR="$OPENSSL_PREFIX/lib"
[[ -f "$LIB_DIR/libssl.so" ]] || { echo 'OpenSSL 3.5 shared libraries unavailable';exit 2; }
mkdir -p bin certs
cc -O2 -Wall -Wextra -std=c11 -pthread -I"$OPENSSL_PREFIX/include" src/tls_app.c \
  -L"$LIB_DIR" -Wl,-rpath,"$LIB_DIR" -lssl -lcrypto -o bin/tls_app
"$OPENSSL_PREFIX/bin/openssl" req -x509 -newkey ec -pkeyopt ec_paramgen_curve:P-256 -nodes \
  -keyout certs/server.key -out certs/server.crt -days 2 -subj '/CN=sdn-pqc.local' \
  -addext 'subjectAltName=DNS:sdn-pqc.local' >/dev/null 2>&1
chmod 600 certs/server.key
ldd bin/tls_app | grep -E 'lib(ssl|crypto)' | grep -F "$OPENSSL_PREFIX" >/dev/null || { echo 'Linkage against OpenSSL prefix not established';exit 3; }
echo 'TLS1.3 endpoint compiled and self-signed testing certificate generated. DO NOT use this certificate in production.'
