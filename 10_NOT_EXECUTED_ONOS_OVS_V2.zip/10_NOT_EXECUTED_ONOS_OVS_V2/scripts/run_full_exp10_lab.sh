#!/usr/bin/env bash
set -euo pipefail
# Dedicated authorized Ubuntu lab ONLY. Runs 45,000 real ONOS/OVS policy trials if all gates pass.
cd "$(dirname "$0")/.."
[[ $(id -u) -eq 0 ]] || { echo 'Requires root on the lab machine' >&2;exit 3; }
[[ "${EXP10_CONFIRM_FULL:-}" == 'YES' ]] || {
 echo 'Set EXP10_CONFIRM_FULL=YES explicitly to authorize the long 45,000-run laboratory experiment.' >&2;exit 4;
}
/usr/bin/python3 scripts/check_environment.py
[[ -x bin/tls_app && -r certs/server.crt && -r certs/server.key ]] || {
 echo 'Run scripts/build_tls35.sh after installing locked OpenSSL first.' >&2;exit 5;
}
bash scripts/start_onos_270.sh
mkdir -p results/full_study
# An explicit, separate three-trial smoke condition must pass before the full run.
/usr/bin/python3 exp10_mininet.py --trials 3 --modes steady --loads 10 --workers 4 --verbose \
   >results/full_study/SMOKE.log 2>&1
/usr/bin/python3 analyze_exp10.py >> results/full_study/SMOKE.log
/usr/bin/python3 scripts/check_smoke.py >> results/full_study/SMOKE.log
mkdir -p results/full_study/SMOKE
cp -f results/EXP10_*.csv results/EXP10_analysis.json results/EXP10_smoke_gate.json results/full_study/SMOKE/
for mode in steady bursty high_arrivals; do
 for load in 10 25 50 75 90; do
  d="results/full_study/${mode}_${load}pct"
  mkdir -p "$d"
  echo "Running EXP10: $mode $load%: 500 matched blocks x 6 policies" | tee "$d/status.log"
  /usr/bin/python3 exp10_mininet.py --trials 500 --modes "$mode" --loads "$load" --workers 4 \
       --campaign-deadline-ms 3000 --endpoint-deadline-ms 750 >"$d/execution.log" 2>&1
  /usr/bin/python3 analyze_exp10.py >"$d/analysis.log" 2>&1
  cp -f results/EXP10_*.csv results/EXP10_analysis.json results/capacity_calibration.json results/sdn_ready.json "$d/"
  (cd "$d" && sha256sum *.csv *.json > FILES_SHA256.txt)
  echo "COMPLETE: $mode ${load}%" >> "$d/status.log"
 done
done
echo 'Full emulated study completed; manually verify all counts and failure flags before publication.'
