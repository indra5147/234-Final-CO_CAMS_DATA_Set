#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p bin certs results
if ! openssl version | grep -Fq 'OpenSSL 3.5.'; then echo 'Requires OpenSSL 3.5.x for local regression';exit 2;fi
cc -O2 -Wall -Wextra -std=c11 -pthread src/tls_app.c -lssl -lcrypto -o bin/tls_app
if [[ ! -e certs/server.crt ]]; then
  openssl req -x509 -newkey ec -pkeyopt ec_paramgen_curve:P-256 -nodes \
  -keyout certs/server.key -out certs/server.crt -days 2 -subj '/CN=sdn-pqc.local' \
  -addext 'subjectAltName=DNS:sdn-pqc.local' 2>/dev/null
  chmod 600 certs/server.key
fi
python3 -m unittest discover -s tests -p 'test_*.py' -v |& tee results/local_unit_tests.log
python3 tests/local_deadline.py |& tee results/local_deadline_tests.log
python3 tests/local_group_rejection.py |& tee results/local_group_rejection.log
printf '\nOnly local regression passed here. ONOS/OVS not exercised by this script.\n'
