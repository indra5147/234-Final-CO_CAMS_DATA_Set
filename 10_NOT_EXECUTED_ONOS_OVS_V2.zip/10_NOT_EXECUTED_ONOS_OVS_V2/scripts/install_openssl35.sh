#!/usr/bin/env bash
set -euo pipefail
# Run ONLY on a dedicated authorized Ubuntu 24.04 lab computer.
[[ $(id -u) -eq 0 ]] || { echo "Requires sudo" >&2;exit 2; }
. /etc/os-release
[[ $ID == ubuntu && $VERSION_ID == 24.04 ]] || { echo "Ubuntu 24.04 only" >&2;exit 3; }
apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y curl ca-certificates perl make gcc zlib1g-dev tar
ver=3.5.9
base="https://github.com/openssl/openssl/releases/download/openssl-${ver}"
work=$(mktemp -d);trap 'rm -rf "$work"' EXIT
curl -fSL --retry 3 "$base/openssl-${ver}.tar.gz" -o "$work/source.tgz"
curl -fSL --retry 3 "$base/openssl-${ver}.tar.gz.sha256" -o "$work/source.sha256"
expected=$(awk '{print $1}' "$work/source.sha256")
[[ "$expected" =~ ^[[:xdigit:]]{64}$ ]] || { echo 'Invalid upstream SHA256 format' >&2;exit 5; }
actual=$(sha256sum "$work/source.tgz" | awk '{print $1}')
[[ "$actual" == "$expected" ]] || { echo 'Upstream SHA256 mismatch; aborting' >&2;exit 6; }
mkdir "$work/src";tar -xf "$work/source.tgz" -C "$work/src" --strip-components=1
cd "$work/src"
./Configure --prefix=/opt/openssl-3.5 --openssldir=/opt/openssl-3.5/ssl shared
make -j "$(nproc)"
make install_sw
/opt/openssl-3.5/bin/openssl version
printf 'Installed OpenSSL %s in /opt/openssl-3.5, separate from the OS package.\n' "$ver"
