#!/usr/bin/env bash
set -euo pipefail
# Explicit user-run only on a disposable/authorized Ubuntu 24.04 lab machine.
if [[ $(id -u) -ne 0 ]]; then echo 'Run using sudo on Ubuntu 24.04' >&2; exit 2; fi
. /etc/os-release
[[ $ID == ubuntu && $VERSION_ID == 24.04 ]] || { echo 'Requires Ubuntu 24.04' >&2; exit 3; }
apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y openvswitch-switch mininet docker.io iperf3 iproute2 curl python3 python3-pip build-essential pkg-config libssl-dev tcpdump
ovs-vsctl --version | head -1
if ! ovs-vsctl --version | grep -Fq '3.3.9'; then echo 'STOP: OVS version is not exactly 3.3.9; do not silently substitute' >&2; exit 4; fi
printf '\nNOTE: Ubuntu default OpenSSL is NOT necessarily 3.5.x. Install the LOCKED OpenSSL 3.5.x LTS in /opt/openssl-3.5 and configure PKG_CONFIG_PATH for the test app.\n'
echo 'System dependencies installed. Nothing has been started or benchmarked by this script.'
