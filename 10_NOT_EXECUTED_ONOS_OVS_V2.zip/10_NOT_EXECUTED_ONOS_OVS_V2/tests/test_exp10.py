import sys,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'src'))
from campaign import CampaignDeadline,CampaignDeadlineExceeded
from migration_scheduler import load_jobs,plan,HYBRID
from exp10_mininet import variant_batches
class TestCampaign(unittest.TestCase):
 def test_expiry_fails_closed(self):
  now=[100.0];gate=CampaignDeadline(40,clock=lambda:now[0]);gate.assert_valid();now[0]+=.041
  with self.assertRaises(CampaignDeadlineExceeded):gate.assert_valid()
  self.assertTrue(gate.expired)
 def test_finish(self):
  now=[10.];gate=CampaignDeadline(100,clock=lambda:now[0]);now[0]+=.05;self.assertAlmostEqual(gate.finish(),50,places=4)
 def test_priority_planning_and_no_downgrade(self):
  jobs=load_jobs();self.assertEqual(len(jobs),12)
  for p in ('B1','B2','B3','B4','P1','P1_v1.1'):
   for cap in (2,4):
    for load in (10,25,50,75,90):
     batches=variant_batches(jobs,p,cap,load)
     self.assertLessEqual(max(len(b) for b in batches),cap)
     self.assertEqual(sorted(j.id for b in batches for j in b),sorted(j.id for j in jobs))
     self.assertTrue(all(j.required_group==HYBRID for b in batches for j in b))
 def test_p1_is_load_adaptive(self):
  j=load_jobs();self.assertEqual(max(map(len,variant_batches(j,'P1',4,10))),4)
  self.assertEqual(max(map(len,variant_batches(j,'P1',4,50))),2)
  self.assertEqual(max(map(len,variant_batches(j,'P1',4,90))),1)
if __name__=='__main__':unittest.main(verbosity=2)
