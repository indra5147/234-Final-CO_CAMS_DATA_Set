"""In-memory REST emulation for controller lifecycle unit testing.
Tests demonstrate code behavior, NOT live ONOS/OVS installation.
"""
import sys, unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from onos_flow_manager import SW1,SW2,FlowError,FlowLifecycle,FlowRule,build_rules,signature

PORTS=dict(cl1=1,cl2=2,sr1=2,sr2=3,sw1_backbone=3,sw2_backbone=1)
class FakeONOS:
 def __init__(self,fail_at=0):self.d={SW1:[],SW2:[]};self.calls=0;self.fail_at=fail_at;self.nextid=100
 def flows(self,d):return [dict(x) for x in self.d[d]]
 def post(self,payload):
  self.calls+=1
  if self.calls==self.fail_at:raise FlowError('fake API failure')
  obj={**payload,'id':str(self.nextid),'state':'ADDED'}
  self.nextid+=1;self.d[payload['deviceId']].append(obj)
 def delete(self,d,id_):self.d[d]=[x for x in self.d[d] if x.get('id')!=id_]
class Rules(unittest.TestCase):
 def test_classical_and_hybrid_exact_lab_ports(self):
  for hybrid in (False,True):
   rules=build_rules(PORTS,hybrid)
   self.assertEqual(len(rules),8)
   self.assertEqual(len(set(signature(r.payload()) for r in rules)),8)
   self.assertEqual(set(r.device for r in rules),{SW1,SW2})
   self.assertEqual(set(r.tcp_port for r in rules),{32031,32032} if hybrid else {31031,31032})
   for r in rules:
    self.assertEqual(r.payload()['priority'],40000)
    self.assertEqual(r.payload()['selector']['criteria'][3]['protocol'],6)
 def test_nonlab_rejected(self):
  with self.assertRaises(FlowError):FlowRule('of:ffffffffffffffff','10.10.10.11','10.10.10.21',31031,'forward',2)
  with self.assertRaises(FlowError):FlowRule(SW1,'10.10.10.11','8.8.8.8',31031,'forward',2)
  with self.assertRaises(FlowError):FlowRule(SW1,'10.10.10.11','10.10.10.21',443,'forward',2)
 def test_staging_and_cleanup(self):
  api=FakeONOS();f=FlowLifecycle(api,timeout_s=.5)
  f.install(build_rules(PORTS,False),'classical')
  f.install(build_rules(PORTS,True),'hybrid')
  self.assertEqual(sum(len(x) for x in api.d.values()),16)
  with self.assertRaises(FlowError):f.install(build_rules(PORTS,True),'hybrid')
  f.remove('hybrid');self.assertEqual(sum(len(x) for x in api.d.values()),8)
  f.remove_all();self.assertFalse(any(api.d.values()))
 def test_failed_post_rolls_back(self):
  api=FakeONOS(fail_at=3);f=FlowLifecycle(api,timeout_s=.5)
  with self.assertRaises(FlowError):f.install(build_rules(PORTS,True),'hybrid')
  self.assertFalse(any(api.d.values()))
  self.assertFalse(f.owned)
 def test_refuse_to_take_over_existing_flows(self):
  api=FakeONOS();api.post(build_rules(PORTS,False)[0].payload())
  f=FlowLifecycle(api)
  with self.assertRaises(FlowError):f.install(build_rules(PORTS,False),'classical')
  self.assertEqual(sum(len(x) for x in api.d.values()),1)
if __name__=='__main__':unittest.main()
