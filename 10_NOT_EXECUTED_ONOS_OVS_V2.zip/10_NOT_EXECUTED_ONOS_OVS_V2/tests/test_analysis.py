import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from analyze_exp10 import bootstrap_paired
class TestAnalysis(unittest.TestCase):
 def test_ci(self):
  a=bootstrap_paired([1.0]*30,300,4);self.assertEqual(a,[1.0,1.0])
 def test_empty_pair(self):self.assertIsNone(bootstrap_paired([]))
if __name__=='__main__':unittest.main()
