#!/usr/bin/env python3
"""Endpoint-level hard deadline proof-of-behavior tests, without real ONOS/SDN."""
import json,subprocess,time
from pathlib import Path
D=Path(__file__).resolve().parents[1]
b=str(D/'bin/tls_app');c=str(D/'certs/server.crt');key=str(D/'certs/server.key')
server=subprocess.Popen([b,'server','--bind','127.0.0.39','--old-port','31339','--new-port','32339','--cert',c,'--key',key],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,bufsize=1)
def case(name, deadline,delay,inject):
 cli=subprocess.Popen([b,'client','--host','127.0.0.39','--old-port','31339','--new-port','32339','--ca',c,'--mode','mbb','--deadline-ms',str(deadline),'--test-hybrid-delay-ms',str(delay),'--force-hybrid-fail',str(inject),'--period-us','1200'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,stdin=subprocess.PIPE,text=True,bufsize=1)
 try:
  line=cli.stdout.readline().strip();assert line.startswith('READY classical_verified=1'),(name,line)
  time.sleep(.055)
  cli.stdin.write('MIGRATE\n');cli.stdin.flush()
  migration=cli.stdout.readline().strip();assert migration.startswith('MIGRATED'),(name,migration)
  time.sleep(.035)
  cli.stdin.write('STOP\n');cli.stdin.flush()
  result=cli.stdout.readline().strip();assert result.startswith('RESULT '),(name,result)
  cli.stdin.close();returncode=cli.wait(timeout=4)
  data=json.loads(result[7:]);data.update({'case':name,'client_returncode':returncode,'migrate_log':migration})
  assert data['classical_verified']==1 and data['unsafe_downgrade']==0,data
  if name=='normal_success':assert returncode==0 and data['hybrid_verified']==1 and data['deadline_expired']==0 and data['new_responses']>0,data
  if name=='fail_before_deadline':assert returncode==0 and data['old_preserved_on_failure']==1 and data['hybrid_verified']==0 and data['old_closed_at_deadline']==0,data
  if name=='late_success_rejected':assert returncode!=0 and data['hybrid_verified']==0 and data['deadline_expired']==1 and data['old_closed_at_deadline']==1 and data['late_hybrid_rejected']==1,data
  if name=='late_failed_closed':assert returncode!=0 and data['hybrid_verified']==0 and data['deadline_expired']==1 and data['old_closed_at_deadline']==1 and data['old_preserved_on_failure']==0,data
  return data
 finally:
  if cli.poll() is None:cli.kill();cli.wait()
try:
 assert server.stdout.readline().startswith('READY')
 results=[case('normal_success',250,0,0),case('fail_before_deadline',250,0,1),case('late_success_rejected',25,85,0),case('late_failed_closed',25,85,1)]
 out=D/'results/deadline_security_fault_tests.json';out.write_text(json.dumps(results,indent=2))
 print('DEADLINE SECURITY TESTS PASS',json.dumps([{k:x[k] for k in ['case','hybrid_verified','deadline_expired','old_closed_at_deadline','late_hybrid_rejected','unsafe_downgrade','client_returncode']} for x in results]))
finally:
 server.terminate();server.wait(timeout=3)
