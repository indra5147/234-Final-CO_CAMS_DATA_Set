#!/usr/bin/env python3
"""UDP sink / cross-traffic generator for Mininet. Not a replacement for calibrated iperf3."""
import argparse, socket, time, json, math
P=argparse.ArgumentParser();P.add_argument('mode',choices=['sink','steady','bursty']);P.add_argument('--host',default='10.10.10.22');P.add_argument('--port',type=int,default=53000);P.add_argument('--mbps',type=float,default=10);P.add_argument('--duration',type=float,default=3600)
a=P.parse_args()
if a.mode=='sink':
 s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);s.bind(('0.0.0.0',a.port));s.settimeout(1);n=0;byte=0;t=time.monotonic()
 try:
  while True:
   try:r,src=s.recvfrom(65535);n+=1;byte+=len(r)
   except socket.timeout: pass
   if time.monotonic()-t>10:print(json.dumps({'rx_packets':n,'rx_bytes':byte}),flush=True);n=0;byte=0;t=time.monotonic()
 except KeyboardInterrupt:pass
else:
 s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);p=b'x'*1000
 d=(a.host,a.port);rate=max(0.1,a.mbps)*1e6/8
 # Pacing in 10ms batches. Bursty: 100ms active/100ms quiet at twice the nominal rate.
 beg=time.monotonic();bytes_sent=0;packets=0;period=.01
 while time.monotonic()-beg<a.duration:
  t=time.monotonic();allowed=(a.mode=='steady' or ((t-beg)%.2)<.1)
  budget=rate*period*(2 if a.mode=='bursty' else 1) if allowed else 0
  for _ in range(int(budget/len(p))):
   try:s.sendto(p,d);packets+=1;bytes_sent+=len(p)
   except OSError:pass
  time.sleep(max(0,period-(time.monotonic()-t)))
 print(json.dumps({'tx_packets':packets,'tx_bytes':bytes_sent,'mode':a.mode}),flush=True)
