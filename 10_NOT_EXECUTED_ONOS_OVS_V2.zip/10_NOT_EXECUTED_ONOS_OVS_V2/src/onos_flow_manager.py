"""Controller-issued, verified ONOS OpenFlow rules for the authorized EXP-10 lab.

Writes ONLY for device IDs of:0000000000000001 and of:0000000000000002;
other IDs fail closed. Rule JSON matches ONOS Classic flow REST examples.
This module's network integration has NOT been tested against an active controller
in the ChatGPT sandbox: run on a privileged, isolated Ubuntu laboratory machine.
"""
import base64
import re
import json
import time
import urllib.error
import urllib.request
from dataclasses import dataclass

SW1='of:0000000000000001'
SW2='of:0000000000000002'
ALLOW={SW1,SW2}

class FlowError(RuntimeError): pass

@dataclass(frozen=True)
class FlowRule:
    device: str
    src: str
    dst: str
    tcp_port: int
    direction: str
    output_port: int

    def __post_init__(self):
        if self.device not in ALLOW: raise FlowError('Non-lab device ID denied')
        if not (1<=int(self.output_port)<65534): raise FlowError('Invalid physical switch port')
        if int(self.tcp_port) not in (31031,32031,31032,32032): raise FlowError('Non-lab TLS port denied')
        if self.direction not in ('forward','reverse'): raise FlowError('Invalid direction')
        allowed={'10.10.10.11','10.10.10.12','10.10.10.21','10.10.10.22'}
        if self.src not in allowed or self.dst not in allowed: raise FlowError('Non-lab endpoint denied')

    def payload(self):
        typ='TCP_DST' if self.direction=='forward' else 'TCP_SRC'
        return {'priority':40000,'timeout':0,'isPermanent':True,'deviceId':self.device,
            'treatment':{'instructions':[{'type':'OUTPUT','port':str(self.output_port)}]},
            'selector':{'criteria':[
                {'type':'ETH_TYPE','ethType':'0x0800'},
                {'type':'IPV4_SRC','ip':self.src+'/32'},
                {'type':'IPV4_DST','ip':self.dst+'/32'},
                {'type':'IP_PROTO','protocol':6},
                {'type':typ,'tcpPort':self.tcp_port}]}}


def build_rules(ports, hybrid=False):
    """ports: cl1,cl2,sr1,sr2,sw1_backbone,sw2_backbone -> OVS port numbers.

    Generates 8 flow rules: 2 end-to-end paths x 2 OVS x 2 directions.
    TCP sockets selected by server-side port (old vs hybrid).
    """
    result=[]
    for idx in (1,2):
        c=f'10.10.10.{10+idx}'
        s=f'10.10.10.{20+idx}'
        port=(32030 if hybrid else 31030)+idx
        result.extend([
            FlowRule(SW1,c,s,port,'forward',ports['sw1_backbone']),
            FlowRule(SW2,c,s,port,'forward',ports[f'sr{idx}']),
            FlowRule(SW2,s,c,port,'reverse',ports['sw2_backbone']),
            FlowRule(SW1,s,c,port,'reverse',ports[f'cl{idx}'])])
    return result


def signature(obj):
    """Normalize JSON formatting differences emitted by ONOS 2.x."""
    def normalize(k):
        k=dict(k)
        if k.get('type')=='ETH_TYPE' and 'ethType' in k:
            k['ethType']=int(str(k['ethType']),16) if str(k['ethType']).lower().startswith('0x') else int(k['ethType'])
        if k.get('type') in ('TCP_DST','TCP_SRC'):
            k['tcpPort']=int(k['tcpPort'])
        if k.get('type')=='IP_PROTO':k['protocol']=int(k['protocol'])
        if k.get('type')=='OUTPUT':k['port']=str(k['port'])
        return json.dumps(k,sort_keys=True)
    return (str(obj.get('deviceId','')),int(obj.get('priority',0)),
            tuple(sorted(normalize(x) for x in obj.get('selector',{}).get('criteria',[]))),
            tuple(sorted(normalize(x) for x in obj.get('treatment',{}).get('instructions',[]))))


class ONOSREST:
    def __init__(self,base='http://127.0.0.1:8181/onos/v1',username='onos',password='rocks'):
        if base.rstrip('/')!='http://127.0.0.1:8181/onos/v1':
            raise FlowError('Controller write endpoint must be local ONOS loopback')
        self.base=base.rstrip('/')
        self.token=base64.b64encode((username+':'+password).encode()).decode()

    def call(self,method,path,payload=None):
        if not path.startswith('flows/'):
            raise FlowError('Only ONOS flow operations are allowed')
        url=self.base+'/'+path
        data=json.dumps(payload).encode() if payload is not None else None
        req=urllib.request.Request(url,data=data,method=method,
            headers={'Authorization':'Basic '+self.token,'Accept':'application/json',
                     'Content-Type':'application/json'})
        try:
            with urllib.request.urlopen(req,timeout=8) as r:
                raw=r.read()
                return json.loads(raw) if raw else {}
        except (urllib.error.HTTPError,urllib.error.URLError,TimeoutError) as e:
            raise FlowError(f'{method} {path} failed: {e}') from e

    def flows(self,device):
        if device not in ALLOW:raise FlowError('Non-lab device ID denied')
        doc=self.call('GET','flows/'+device)
        return doc.get('flows',[])

    def post(self,payload):
        device=payload['deviceId']
        if device not in ALLOW:raise FlowError('Non-lab device ID denied')
        self.call('POST','flows/'+device,payload)

    def delete(self,device,id_):
        if device not in ALLOW:raise FlowError('Non-lab device ID denied')
        if re.fullmatch(r'(?:0x)?[0-9a-fA-F]{1,32}',str(id_)) is None:raise FlowError('Invalid flow id')
        self.call('DELETE',f'flows/{device}/{id_}')

class FlowLifecycle:
    def __init__(self,client,timeout_s=15.0):
        self.client=client
        self.timeout_s=timeout_s
        self.owned={}
        self.audit=[]

    def install(self,rules,stage):
        if stage in self.owned:raise FlowError('Stage already present: '+stage)
        if not rules:raise FlowError('Empty rule set')
        keys=[signature(r.payload()) for r in rules]
        if len(set(keys))!=len(keys):raise FlowError('Duplicated staged flow rule')
        devices=sorted(set(r.device for r in rules))
        before={d:self.client.flows(d) for d in devices}
        all_existing=[v for arr in before.values() for v in arr]
        if any(signature(v) in keys for v in all_existing):
            raise FlowError('Pre-existing matching flow; refusing to take ownership')
        staged=[]
        self.owned[stage]=staged
        start=time.monotonic()
        try:
            for r in rules:self.client.post(r.payload())
            # Wait for the controller's desired entries to become ADDED, not just POST 201.
            until=time.monotonic()+self.timeout_s
            while time.monotonic()<until:
                current=[v for d in devices for v in self.client.flows(d)]
                got={signature(v):v for v in current if signature(v) in keys}
                staged[:]=[(obj['deviceId'],str(obj['id'])) for obj in got.values()
                          if obj.get('id') is not None and re.fullmatch(r'(?:0x)?[0-9a-fA-F]{1,32}',str(obj.get('id'))) is not None]
                if len(got)==len(rules) and all(str(got[k].get('state')).upper()=='ADDED' for k in keys):
                    if len(staged)!=len(rules):raise FlowError('Flow installed without valid ID')
                    elapsed=(time.monotonic()-start)*1000
                    self.audit.append({'stage':stage,'action':'install_verified','rule_count':len(rules),'elapsed_ms':elapsed})
                    return elapsed
                time.sleep(0.20)
            raise FlowError(f'Not all {len(rules)} rules reached ADDED state; observed {len(got)}')
        except BaseException:
            # Recovery: any flow matching a requested signature but absent from preflight
            # belongs to this aborted stage; use exact IDs, never delete others.
            try:
                for d in devices:
                    for obj in self.client.flows(d):
                        if signature(obj) in keys and obj.get('id') is not None:
                            self.client.delete(d,str(obj['id']))
            finally:self.owned.pop(stage,None)
            raise

    def remove(self,stage):
        installed=self.owned.get(stage,[])
        errors=[]
        for d,id_ in installed:
            try:self.client.delete(d,id_)
            except FlowError as e:errors.append(str(e))
        if not errors:
            until=time.monotonic()+self.timeout_s
            while time.monotonic()<until:
                still=[(d,id_) for d,id_ in installed if any(str(x.get('id'))==id_ for x in self.client.flows(d))]
                if not still:break
                time.sleep(.20)
            else:errors.append(f'Delete not reflected in GET flows for {stage}')
        self.audit.append({'stage':stage,'action':'remove','rule_count':len(installed),'errors':errors})
        if errors:raise FlowError('Flow cleanup failed: '+'; '.join(errors))
        self.owned.pop(stage,None)

    def remove_all(self):
        errors=[]
        for stage in list(reversed(self.owned)):
            try:self.remove(stage)
            except FlowError as e:errors.append(str(e))
        if errors:raise FlowError('; '.join(errors))
