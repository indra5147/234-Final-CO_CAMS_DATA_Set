#!/usr/bin/env python3
"""Background real verified classical TLS arrivals. For high-arrival load mode only."""
import argparse,ssl,socket,time,json
p=argparse.ArgumentParser();p.add_argument('--dst',default='10.10.10.21');p.add_argument('--port',type=int,default=31031);p.add_argument('--cafile',required=True);p.add_argument('--rate',type=float,default=40);p.add_argument('--duration',type=int,default=3600);a=p.parse_args()
ctx=ssl.create_default_context(cafile=a.cafile);ctx.minimum_version=ssl.TLSVersion.TLSv1_3;ctx.maximum_version=ssl.TLSVersion.TLSv1_3
try:ctx.set_ecdh_curve('X25519')
except (AttributeError,ValueError):pass
end=time.monotonic()+a.duration;ok=0;fail=0
while time.monotonic()<end:
 now=time.monotonic()
 try:
  with socket.create_connection((a.dst,a.port),timeout=2) as raw:
   with ctx.wrap_socket(raw,server_hostname='sdn-pqc.local') as s:
    s.sendall(b'PING\n');out=s.recv(64)
    if out==b'PONG\n':ok+=1
    else:fail+=1
 except (OSError,ssl.SSLError):fail+=1
 time.sleep(max(0,1/max(1,a.rate)-(time.monotonic()-now)))
 if (ok+fail)%500==0 and ok+fail:print(json.dumps({'arrivals_ok':ok,'arrivals_failed':fail}),flush=True)
print(json.dumps({'arrivals_ok':ok,'arrivals_failed':fail}),flush=True)
