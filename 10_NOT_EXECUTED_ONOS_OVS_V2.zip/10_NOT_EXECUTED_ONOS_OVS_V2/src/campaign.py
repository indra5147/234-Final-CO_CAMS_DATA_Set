"""Independent global migration campaign deadline guard (monotonic clock)."""
import time
class CampaignDeadlineExceeded(RuntimeError):pass
class CampaignDeadline:
 def __init__(self,budget_ms,clock=time.monotonic):
  if budget_ms<=0:raise ValueError('budget must be positive')
  self.clock=clock;self.budget_ms=float(budget_ms);self.start=self.clock();self.expired=False
 def elapsed_ms(self):return (self.clock()-self.start)*1000
 def assert_valid(self):
  if self.elapsed_ms()>=self.budget_ms:
   self.expired=True
   raise CampaignDeadlineExceeded('global campaign deadline expired; close unmigrated sessions')
 def finish(self):
  self.assert_valid();return self.elapsed_ms()
