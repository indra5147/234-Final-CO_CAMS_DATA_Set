# EXP-07 — Equal-Concurrency, Held-Out Original-Trace Evaluation

**Project:** Controller-Orchestrated Crypto-Agile Post-Quantum Migration for Scalable Software-Defined Networks  
**Locked decisions:** H1.0 and Comparative Experimental Protocol V1.0 remain unchanged.  
**Status:** EXECUTED OFFLINE REPLAY — **NOT** a hardware test; **NOT** measured application disruption.

## What was actually executed

- Read and Git-blob-verified six original CSV files (1,000 observations each) from the user-uploaded repository `usama0print/pqc-tls-benchmarking`, Git commit `7a74485a533da9ec7f4adccc644d05c69cf2ddae`.
- Used only matched classical X25519 and hybrid X25519MLKEM768 source groups to characterize three scenarios; scheduling-job execution costs use hybrid observations alone.
- Held out 800 original observations per file from 200 development observations (fixed source split seed).
- Selected candidate heuristic **LPT** on **development draws only**, never on held-out job costs.
- Ran **500 matched offline job-scheduling trials per profile and concurrency limit** for each of B1, B2, B3, B4, locked P1, P1-v1.1 safeguarded candidate, and unsafeguarded ablation.
- **4 workload profiles × 2 slot caps (2 and 4) × 500 trials × 7 strategies = 28,000 modeled policy runs; 336,000 modeled job completions.**
- Every strategy in each trial received **exactly the same 12 source-derived TLS duration draws** and exactly the same concurrency cap. No testing results were used to revise the selected candidate.
- Original `pqc-tls-benchmarking` benchmark captures OpenSSL client command wall-clock runtime; it does **not** isolate handshake-only time and does not measure SDN service disruption or migrations.

## Algorithm definitions (frozen for this experiment)

- **B1:** FIFO, work-conserving with cap 2 or 4.
- **B2:** fixed batches sized to cap with a 10 ms pause between batches.
- **B3:** FIFO fixed-rate staged launches, one every 8 ms, capped at 2 or 4 simultaneous jobs.
- **B4:** load-ascending greedy ordering (synthetic service load), work-conserving with cap 2 or 4.
- **P1 (original):** deadline-slack and security-priority ordering; **equal concurrency forced for this controlled ablation**, while the locked operational P1's adaptive concurrency rule is unchanged.
- **P1-v1.1 exploratory candidate:** development-selected longest-predicted-time-first ordering, **guarded**: if expected synthetic deadline misses exceed original P1, it falls back to original P1 ordering; development means are used, never realized held-out costs.
- **LPT ablation:** same candidate **without guard**, diagnostic only.

## Mixed-workload mean modeled outcomes (ms unless indicated)

| Worker slots | Policy | Mean makespan (ms) | Mean p95 job completion (ms) | Mean deadline misses /12 |
|---:|---|---:|---:|---:|
| 2 | B1 | 914.94 | 894.20 | 0.016 |
| 2 | B2 | 986.72 | 976.14 | 0.080 |
| 2 | B3 | 922.46 | 901.41 | 0.016 |
| 2 | B4 | 912.30 | 894.46 | 0.774 |
| 2 | P1 | 917.91 | 893.90 | 0.282 |
| 2 | P1_v1.1_candidate | 917.91 | 893.90 | 0.282 |
| 2 | LPT_unguarded_ablation | 903.94 | 895.30 | 4.026 |
| 4 | B1 | 474.59 | 461.75 | 0.000 |
| 4 | B2 | 510.36 | 499.77 | 0.000 |
| 4 | B3 | 495.55 | 482.52 | 0.000 |
| 4 | B4 | 483.75 | 467.36 | 0.000 |
| 4 | P1 | 474.25 | 463.48 | 0.000 |
| 4 | P1_v1.1_candidate | 463.34 | 456.51 | 0.000 |
| 4 | LPT_unguarded_ablation | 463.34 | 456.51 | 0.000 |

### Paired P1 / candidate minus B4, mixed workload

Negative makespan difference is a modeled scheduling improvement, not a measured service-disruption improvement. CI columns below are **conditional Monte-Carlo bootstrap intervals across replay draws**, not confidence intervals validating physical SDN superiority.

| Cap | Compared method | Mean makespan difference (ms) | Conditional 95% bootstrap CI (ms) |
|---:|---|---:|---|
| 2 | P1 | +5.61 | [+3.86, +7.28] |
| 2 | P1_v1.1_candidate | +5.61 | [+3.86, +7.28] |
| 4 | P1 | -9.50 | [-11.06, -8.08] |
| 4 | P1_v1.1_candidate | -20.41 | [-21.95, -18.90] |

## Scientific interpretation and decision

1. Original P1 is faster on modeled makespan than B4 at cap 4 in this *mixed* scenario, but is slower at cap 2. Thus there is **no universal algorithm superiority**.
2. An unsafeguarded duration-first candidate appears to reduce makespan, but dramatically increases **synthetic deadline misses** at cap 2; this candidate is unsafe even for these assumed conditions.
3. The guarded candidate avoids that *predicted* increase at cap 2 by reverting to original P1 and keeps the LPT ranking at cap 4. This is only **a preliminary algorithm proposal**, **not a change to locked P1**.
4. Even where modeled completion improves, priority-weighted completion may be worse: multi-objective dominance is not established.
5. The locked **primary endpoint is p95 *real application service disruption***. The source CSV has no disruption values. Therefore **the locked primary outcome cannot be evaluated or declared successful from EXP-07**.
6. Synthetic job load, priority, deadline and identical-cap scheduler dynamics are laboratory assumptions, not real source observations. Third-party source raw data has not been transformed into measured SDN migration events.

## SDN emulation permission check

- `unshare -n true`: `Operation not permitted`.
- `ip link add dummy-exptest type dummy`: `RTNETLINK answers: Operation not permitted`.
- `ovs-vsctl`, `onos`, and Docker are not available on this runtime.
- Therefore real ONOS/OpenFlow/OVS virtual topology and actual end-to-end migration experiments **could not be run here**. A privileged local Ubuntu testbed is required and remains separate from this successful replay.

## Provenance and scripts

- Source: https://github.com/usama0print/pqc-tls-benchmarking
- User supplied GitHub snapshot ZIP, commit `7a74485a533da9ec7f4adccc644d05c69cf2ddae`.
- `results/original_source_provenance.csv` lists the exact six original source files and Git blob SHA1 digests, verified during each execution.
- `scripts/run_exp07.py` executes from a local `/mnt/data/pqc-tls-benchmarking-...zip` snapshot. To reproduce on another computer, put original user-supplied ZIP in that location or change the `ORIG` path at the top of script.
- `results/matched_policy_runs_28000.csv`: one per modeled algorithm run.
- `results/matched_job_events_336000.csv`: synthetic policy start/finish events, each using an actual external TLS-duration record draw.
- `results/paired_P1_vs_B4_12000.csv`: paired trial comparisons.
- `results/paired_statistics_96.csv`: conditional replay/bootstrap summaries.
- Do not use this package to claim a measured cryptographic downgrade-prevention rate, physical link traffic, hardware throughput, or controller overhead.
