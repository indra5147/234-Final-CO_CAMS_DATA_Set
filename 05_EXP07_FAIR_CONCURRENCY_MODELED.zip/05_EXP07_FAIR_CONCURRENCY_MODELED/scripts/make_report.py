#!/usr/bin/env python3
from pathlib import Path
import csv,json,zipfile,hashlib,statistics
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1];RES=ROOT/'results';PL=ROOT/'plots';PL.mkdir(exist_ok=True)
def rows(n):return list(csv.DictReader((RES/n).open()))
def get(summary,p,c):return next(r for r in summary if r['profile']=='mixed' and r['cap']==str(c) and r['policy']==p)
S=rows('summary_56.csv');PA=rows('paired_statistics_96.csv');D=rows('candidate_development_selection.csv');meta=json.loads((RES/'experiment_manifest.json').read_text());
# Grouped charts - do not specify colors/styles; matplotlib defaults used.
for cap in [2,4]:
    ps=['B1','B2','B3','B4','P1','P1_v1.1_candidate','LPT_unguarded_ablation']
    ys=[float(get(S,p,cap)['mean_makespan_ms']) for p in ps]
    fig,ax=plt.subplots(figsize=(10,5.0))
    ax.bar(range(len(ps)),ys)
    ax.set_xticks(range(len(ps)),['B1','B2','B3','B4','P1','P1-v1.1','LPT ablation'],rotation=15)
    ax.set_ylabel('Modeled mean batch completion (ms)')
    ax.set_title(f'EXP-07 · Mixed workload · equal concurrency {cap} (500 replay trials)')
    ax.text(0.01,0.98,'External TLS latency inputs; NOT measured SDN migration',transform=ax.transAxes,va='top',fontsize=9)
    fig.tight_layout();fig.savefig(PL/f'mixed_comparison_cap{cap}.png',dpi=250);plt.close(fig)

fig,ax=plt.subplots(figsize=(9,4.8))
for pol in ['B4','P1','P1_v1.1_candidate']:
    ax.plot([2,4],[float(get(S,pol,k)['mean_makespan_ms']) for k in [2,4]],marker='o',label=pol.replace('_candidate',' (guarded)'))
ax.set_xticks([2,4]);ax.set_ylabel('Modeled batch completion (ms)');ax.set_xlabel('Equal concurrent migration slots')
ax.set_title('EXP-07 · Concurrent slot sensitivity (mixed workload)');ax.legend()
fig.tight_layout();fig.savefig(PL/'concurrency_sensitivity.png',dpi=250);plt.close(fig)

fig,ax=plt.subplots(figsize=(8,4.8))
for pol in ['B4','P1','P1_v1.1_candidate','LPT_unguarded_ablation']:
    ax.plot([2,4],[float(get(S,pol,k)['mean_deadline_misses']) for k in [2,4]],marker='o',label=pol.replace('_candidate',' (guarded)'))
ax.set_xticks([2,4]);ax.set_ylabel('Mean modeled deadline misses per 12 services')
ax.set_xlabel('Equal concurrent migration slots');ax.set_title('SLA guard effect on synthetic deadlines');ax.legend()
fig.tight_layout();fig.savefig(PL/'synthetic_deadline_misses.png',dpi=250);plt.close(fig)

readme=f'''# EXP-07 — Equal-Concurrency, Held-Out Original-Trace Evaluation

**Project:** Controller-Orchestrated Crypto-Agile Post-Quantum Migration for Scalable Software-Defined Networks  
**Locked decisions:** H1.0 and Comparative Experimental Protocol V1.0 remain unchanged.  
**Status:** EXECUTED OFFLINE REPLAY — **NOT** a hardware test; **NOT** measured application disruption.

## What was actually executed

- Read and Git-blob-verified six original CSV files (1,000 observations each) from the user-uploaded repository `usama0print/pqc-tls-benchmarking`, Git commit `{meta['source_commit']}`.
- Used only matched classical X25519 and hybrid X25519MLKEM768 source groups to characterize three scenarios; scheduling-job execution costs use hybrid observations alone.
- Held out 800 original observations per file from 200 development observations (fixed source split seed).
- Selected candidate heuristic **{meta['trained_candidate']}** on **development draws only**, never on held-out job costs.
- Ran **500 matched offline job-scheduling trials per profile and concurrency limit** for each of B1, B2, B3, B4, locked P1, P1-v1.1 safeguarded candidate, and unsafeguarded ablation.
- **4 workload profiles × 2 slot caps (2 and 4) × 500 trials × 7 strategies = 28,000 modeled policy runs; 336,000 modeled job completions.**
- Every strategy in each trial received **exactly the same 12 source-derived TLS duration draws** and exactly the same concurrency cap. No testing results were used to revise the selected candidate.
- Original `pqc-tls-benchmarking` benchmark captures OpenSSL client command wall-clock runtime; it does **not** isolate handshake-only time and does not measure SDN service disruption or migrations.

## Algorithm definitions (frozen for this experiment)

- **B1:** FIFO, work-conserving with cap 2 or 4.
- **B2:** fixed batches sized to cap with a 10 ms pause between batches.
- **B3:** FIFO fixed-rate staged launches, one every 8 ms, capped at 2 or 4 simultaneous jobs.
- **B4:** load-ascending greedy ordering (synthetic service load), work-conserving with cap 2 or 4.
- **P1 (original):** deadline-slack and security-priority ordering; **equal concurrency forced for this controlled ablation**, while the locked operational P1's adaptive concurrency rule is unchanged.
- **P1-v1.1 exploratory candidate:** development-selected longest-predicted-time-first ordering, **guarded**: if expected synthetic deadline misses exceed original P1, it falls back to original P1 ordering; development means are used, never realized held-out costs.
- **LPT ablation:** same candidate **without guard**, diagnostic only.

## Mixed-workload mean modeled outcomes (ms unless indicated)

| Worker slots | Policy | Mean makespan (ms) | Mean p95 job completion (ms) | Mean deadline misses /12 |
|---:|---|---:|---:|---:|
'''
for cap in [2,4]:
 for p in ['B1','B2','B3','B4','P1','P1_v1.1_candidate','LPT_unguarded_ablation']:
    r=get(S,p,cap);readme+=f"| {cap} | {p} | {float(r['mean_makespan_ms']):.2f} | {float(r['mean_p95_job_finish_ms']):.2f} | {float(r['mean_deadline_misses']):.3f} |\n"
readme+='''
### Paired P1 / candidate minus B4, mixed workload

Negative makespan difference is a modeled scheduling improvement, not a measured service-disruption improvement. CI columns below are **conditional Monte-Carlo bootstrap intervals across replay draws**, not confidence intervals validating physical SDN superiority.

| Cap | Compared method | Mean makespan difference (ms) | Conditional 95% bootstrap CI (ms) |
|---:|---|---:|---|
'''
for cap in [2,4]:
 for p in ['P1','P1_v1.1_candidate']:
    r=next(r for r in PA if r['profile']=='mixed' and r['cap']==str(cap) and r['policy']==p and r['metric']=='delta_makespan_ms')
    readme+=f"| {cap} | {p} | {float(r['mean_paired_difference']):+.2f} | [{float(r['conditional_replay_CI95_low']):+.2f}, {float(r['conditional_replay_CI95_high']):+.2f}] |\n"
readme+='''
## Scientific interpretation and decision

1. Original P1 is faster on modeled makespan than B4 at cap 4 in this *mixed* scenario, but is slower at cap 2. Thus there is **no universal algorithm superiority**.
2. An unsafeguarded duration-first candidate appears to reduce makespan, but dramatically increases **synthetic deadline misses** at cap 2; this candidate is unsafe even for these assumed conditions.
3. The guarded candidate avoids that *predicted* increase at cap 2 by reverting to original P1 and keeps the LPT ranking at cap 4. This is only **a preliminary algorithm proposal**, **not a change to locked P1**.
4. Even where modeled completion improves, priority-weighted completion may be worse: multi-objective dominance is not established.
5. The locked **primary endpoint is p95 *real application service disruption***. The source CSV has no disruption values. Therefore **the locked primary outcome cannot be evaluated or declared successful from EXP-07**.
6. Synthetic job load, priority, deadline and identical-cap scheduler dynamics are laboratory assumptions, not real source observations. Third-party source raw data has not been transformed into measured SDN migration events.

## SDN emulation permission check

- `unshare -n true`: `Operation not permitted`.
- `ip link add dummy-exptest type dummy`: `RTNETLINK answers: Operation not permitted`.
- `ovs-vsctl`, `onos`, and Docker are not available on this runtime.
- Therefore real ONOS/OpenFlow/OVS virtual topology and actual end-to-end migration experiments **could not be run here**. A privileged local Ubuntu testbed is required and remains separate from this successful replay.

## Provenance and scripts

- Source: https://github.com/usama0print/pqc-tls-benchmarking
- User supplied GitHub snapshot ZIP, commit `7a74485a533da9ec7f4adccc644d05c69cf2ddae`.
- `results/original_source_provenance.csv` lists the exact six original source files and Git blob SHA1 digests, verified during each execution.
- `scripts/run_exp07.py` executes from a local `/mnt/data/pqc-tls-benchmarking-...zip` snapshot. To reproduce on another computer, put original user-supplied ZIP in that location or change the `ORIG` path at the top of script.
- `results/matched_policy_runs_28000.csv`: one per modeled algorithm run.
- `results/matched_job_events_336000.csv`: synthetic policy start/finish events, each using an actual external TLS-duration record draw.
- `results/paired_P1_vs_B4_12000.csv`: paired trial comparisons.
- `results/paired_statistics_96.csv`: conditional replay/bootstrap summaries.
- Do not use this package to claim a measured cryptographic downgrade-prevention rate, physical link traffic, hardware throughput, or controller overhead.
'''
(ROOT/'README.md').write_text(readme,encoding='utf-8')
(RES/'EXECUTION_CHECKS.json').write_text(json.dumps({'provenance_file_count':6,'original_source_records':6000,'trial_runs':len(rows('matched_policy_runs_28000.csv')),'job_events':len(rows('matched_job_events_336000.csv')),'paired_rows':len(rows('paired_P1_vs_B4_12000.csv')),'candidate_development_selection':D,'locked_primary_metric_measured':False,'sdn_ovs_run':False},indent=2),encoding='utf-8')
print('Report written',ROOT/'README.md')
