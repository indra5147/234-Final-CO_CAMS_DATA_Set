from pathlib import Path
import csv,json
from artifact_tool import Workbook,SpreadsheetFile
P=Path(__file__).resolve().parents[1];R=P/'results'
def data(filename):
 with (R/filename).open(newline='',encoding='utf-8') as f:
  rs=list(csv.DictReader(f))
 for rec in rs:
  for k,v in rec.items():
   if k in ('profile','policy','metric','group','candidate','file','git_blob_sha1','source_group') or k.startswith('source') or k.endswith('file'):continue
   try:
    rec[k]=float(v) if '.' in v else int(v)
   except (ValueError,TypeError):pass
 return rs

wb=Workbook.create()
navy='#12283F';teal='#086C75';light='#EAF2F6';white='#FFFFFF';gray='#64748B'
def tab(name,rows,widths=None):
 sh=wb.worksheets.add(name)
 keys=list(rows[0]); vals=[keys]+[[v.get(k) for k in keys] for v in rows]
 colcount=len(keys)
 sh.get_range_by_indexes(0,0,len(vals),colcount).values=vals
 sh.get_range_by_indexes(0,0,1,colcount).format={'fill':navy,'font':{'color':white,'bold':True},'row_height':33,'wrap_text':True,'vertical_alignment':'center'}
 sh.freeze_panes.freeze_rows(1)
 for i in range(colcount):
  sh.get_range_by_indexes(0,i,len(vals),1).format.column_width=(widths or {}).get(keys[i],22)
 sh.get_range_by_indexes(1,0,len(rows),colcount).format.row_height=22
 try:sh.tables.add(f'A1:{chr(65+colcount-1)}{len(vals)}',True,f'Exp07{name.replace(" ","").replace("-","")[:15]}')
 except Exception as e:print('table fallback',name,e)
 return sh

# Compact dedicated dashboard
s=wb.worksheets.add('Overview')
s.merge_cells('A1:G2');s.get_range('A1').values=[['EXP-07 | FAIR-CONCURRENCY EVALUATION']]
s.get_range('A1:G2').format={'fill':navy,'font':{'bold':True,'color':white,'size':17},'vertical_alignment':'center','row_height':24}
s.merge_cells('A3:G3');s.get_range('A3').values=[['Controller-Orchestrated Crypto-Agile Post-Quantum Migration for Scalable Software-Defined Networks']]
s.get_range('A3:G3').format={'fill':light,'font':{'color':navy,'bold':True},'row_height':33}
notes=[['Evaluation type','Offline, trace-driven modeled scheduling — NOT physical SDN or measured service disruption'],['Original source','https://github.com/usama0print/pqc-tls-benchmarking'],['Repository commit','7a74485a533da9ec7f4adccc644d05c69cf2ddae'],['Verified original measurements','6 CSV files × 1,000 records = 6,000 source values'],['Development / held-out','200 / 800 original source observations per file'],['Matched replay design','500 trials × 4 profiles × 2 concurrency caps × 7 methods = 28,000 policy runs'],['Locked protocol','H1.0 / V1.0 unchanged; P1-v1.1 exploratory candidate only'],['Primary endpoint','Actual p95 application service disruption: NOT MEASURED'],['Interpretation','Conditional modeled run comparison, not hardware superiority proof']]
s.get_range('A5:B13').values=notes
s.get_range('A5:A13').format={'font':{'bold':True,'color':navy},'fill':light,'row_height':29}
s.get_range('B5:B13').format.wrap_text=True
s.get_range('B5:B13').format.row_height=29
s.get_range('A1:A33').format.column_width=28
s.get_range('B1:B33').format.column_width=79
s.get_range('C1:C33').format.column_width=23
s.get_range('D1:D33').format.column_width=23
s.get_range('E1:E33').format.column_width=23
s.get_range('F1:F33').format.column_width=23
s.get_range('G1:G33').format.column_width=23
s.get_range('A15:G15').values=[['Policy','Cap 2 makespan (ms)','Cap 4 makespan (ms)','Cap 2 p95 job finish','Cap 4 p95 job finish','Cap 2 deadline misses','Cap 4 deadline misses']]
s.get_range('A15:G15').format={'fill':teal,'font':{'color':white,'bold':True},'row_height':35,'wrap_text':True}
ss=data('summary_56.csv')
policies=['B1','B2','B3','B4','P1','P1_v1.1_candidate','LPT_unguarded_ablation']
def get(pol,cap):return next(x for x in ss if x['profile']=='mixed' and x['policy']==pol and x['cap']==cap)
dat=[]
for pol in policies:
 a,b=get(pol,2),get(pol,4)
 dat.append([pol,a['mean_makespan_ms'],b['mean_makespan_ms'],a['mean_p95_job_finish_ms'],b['mean_p95_job_finish_ms'],a['mean_deadline_misses'],b['mean_deadline_misses']])
s.get_range('A16:G22').values=dat
s.get_range('A16:A22').format={'font':{'bold':True}}
s.get_range('B16:G22').set_number_format('0.00')
s.merge_cells('A24:G24');s.get_range('A24').values=[['NOTE: Source durations are actual external TLS command latencies; all job completion times, priorities and SLA deadlines are modeled assumptions.']]
s.get_range('A24:G24').format={'fill':light,'font':{'color':navy,'bold':True},'row_height':31,'wrap_text':True}
s.merge_cells('A26:G26');s.get_range('A26').values=[['Candidate is NOT promoted to P1: no real SDN migration/downtime measurements and no full multi-objective superiority.']]
s.get_range('A26:G26').format={'font':{'bold':True,'color':'#9F2D2D'},'row_height':33,'wrap_text':True}
s.freeze_panes.freeze_rows(3)

tab('All 56 Results',ss,{'profile':22,'policy':25,'n_trials':13})
tab('Paired Confidence',data('paired_statistics_96.csv'),{'profile':19,'policy':25,'metric':29})
tab('Candidate Tuning',data('candidate_development_selection.csv'),{'candidate':23,'development_replay_units':27,'mean_development_objective':28})
tab('Original Data Source',data('original_source_provenance.csv'),{'profile':22,'group':25,'file':38,'git_blob_sha1':46})
SpreadsheetFile.export_xlsx(wb).save(str(P/'EXP07_Fair_Concurrency_Results.xlsx'))
print('saved',P/'EXP07_Fair_Concurrency_Results.xlsx')
try:print(wb.inspect({'kind':'sheet','include':'id,name'}).ndjson[:2500])
except Exception as e:print('inspect skipped',e)
