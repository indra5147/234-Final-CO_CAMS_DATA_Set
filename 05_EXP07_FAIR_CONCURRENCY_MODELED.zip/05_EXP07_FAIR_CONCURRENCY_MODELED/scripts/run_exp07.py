#!/usr/bin/env python3
"""EXP-07: trace-driven scheduler comparison under equal concurrency.
Measured inputs are original GitHub TLS CLI wall-clock latencies; outputs are
MODELED completion, not physical migration, measured disruption, or SDN.
"""
from pathlib import Path
from collections import defaultdict
import hashlib,zipfile,csv,io,json,random,statistics,math,heapq,os
import numpy as np
from scipy.stats import bootstrap

ROOT=Path(__file__).resolve().parents[1]
ORIG=Path(os.getenv('EXP07_SOURCE_ZIP','/mnt/data/pqc-tls-benchmarking-7a74485a533da9ec7f4adccc644d05c69cf2ddae.zip'))
SOURCE=ROOT/'source_csv'; RESULT=ROOT/'results'; SOURCE.mkdir(exist_ok=True);RESULT.mkdir(exist_ok=True)
SEED=20261028; NTEST=500; NDEV=250; GROUP='X25519MLKEM768'
POLICIES=('B1','B2','B3','B4','P1','P1_v1.1_candidate','LPT_unguarded_ablation')
PROFILES=('localhost','broadband','intercontinental','mixed')
CAPS=(2,4)
FILEMAP={
 'localhost':{'X25519':'185902','X25519MLKEM768':'190101'},
 'broadband':{'X25519':'202339','X25519MLKEM768':'202833'},
 'intercontinental':{'X25519':'203344','X25519MLKEM768':'205317'}}

def save_csv(path,rows):
    if not rows:raise ValueError('empty CSV')
    with Path(path).open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]),extrasaction='ignore');w.writeheader();w.writerows(rows)

def blobsha(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()

def load_sources():
    """Read exact GitHub source files; use supplied GitHub archive or bundled CSV copies.

    The Git blob SHAs below are verified against the original repository
    metadata, never inferred from arbitrary uploads.
    """
    expected={'185902':'dfc3eb77c0df25dbb675e8fc3fda16db9ca37d61',
      '190101':'41dd7b98b7c9af57bc24873a90d3f2ff6f2f4d62',
      '202339':'dfe0a1fa566af694dac90662142990f3a0ab5d42',
      '202833':'3bcc2e430474406c5bcffd1be114db0766b0a7ba',
      '203344':'08d351e70db45a5353353107f51616db0c8fc791',
      '205317':'f7199e500a4ab18e4bb42eb9d51a2dc40295242a'}
    result={}; inventory=[]
    z=zipfile.ZipFile(ORIG) if ORIG.is_file() else None
    try:
      for profile,groups in FILEMAP.items():
        for group,stamp in groups.items():
            path=f'results/results_20260309_{stamp}.csv'
            if z is not None:
                matches=[s for s in z.namelist() if s.endswith('/'+path)]
                assert len(matches)==1, (path,matches)
                content=z.read(matches[0])
                (SOURCE/Path(path).name).write_bytes(content)
            else:
                content=(SOURCE/Path(path).name).read_bytes()
            digest=blobsha(content)
            assert digest==expected[stamp],f'Upstream Git blob checksum mismatch: {path}'
            parsed=list(csv.DictReader(io.StringIO(content.decode('utf-8-sig'))))
            assert len(parsed)==1000
            x=[]
            for i,r in enumerate(parsed,1):
                assert r['group']==group and int(r['id'])==i
                val=float(r['latency_ms'])
                assert math.isfinite(val) and val>0
                x.append(val)
            result[(profile,group)]=np.asarray(x,dtype=float)
            inventory.append({'profile':profile,'group':group,'file':Path(path).name,'rows':len(x),'git_blob_sha1':digest,'mean_source_ms':round(float(np.mean(x)),5)})
    finally:
      if z is not None:z.close()
    save_csv(RESULT/'original_source_provenance.csv',inventory)
    rng=np.random.default_rng(SEED+10)
    dev={};held={}
    for key,values in result.items():
        ii=rng.permutation(1000)
        dev[key]=values[ii[:200]];held[key]=values[ii[200:]]
    return dev,held,inventory

def jobs_template(profile,calmeans):
    scenarios=[profile]*12 if profile!='mixed' else ['localhost']*4+['broadband']*4+['intercontinental']*4
    return [{'id':f'S{i:02d}','scenario':s,'priority':1+(i%5),'load':round((.13*i)%1,6),'deadline_ms':700+31*i,
             'pred_ms':float(calmeans[s])} for i,s in enumerate(scenarios,1)]

def predictive_misses(ordered,cap):
    # Uses ONLY calibration-set mean estimates, never heldout realized duration.
    workers=[(0.0,k) for k in range(cap)];heapq.heapify(workers)
    misses=0
    for j in ordered:
        t,k=heapq.heappop(workers)
        finish=t+j['pred_ms']
        misses+=int(finish>j['deadline_ms'])
        heapq.heappush(workers,(finish,k))
    return misses

def order(jobs,policy,candidate_name=None,cap=None):
    if policy in ('B1','B2','B3'):return list(jobs)
    if policy=='B4':return sorted(jobs,key=lambda j:(j['load'],j['id']))
    if policy=='P1':return sorted(jobs,key=lambda j:(j['deadline_ms']-j['pred_ms'],-j['priority'],j['load'],j['id']))
    if policy in ('P1_v1.1_candidate','LPT_unguarded_ablation'):
        if candidate_name=='LPT': ranked=sorted(jobs,key=lambda j:(-j['pred_ms'],j['id']))
        elif candidate_name=='LPT_PRIORITY': ranked=sorted(jobs,key=lambda j:(-j['pred_ms']*(1+0.08*j['priority']),j['id']))
        elif candidate_name=='LPT_URGENT': ranked=sorted(jobs,key=lambda j:(-j['pred_ms']*(1+0.18*j['priority'])+0.02*j['deadline_ms'],j['id']))
        elif candidate_name=='SLACK_LPT': ranked=sorted(jobs,key=lambda j:(j['deadline_ms']-3*j['pred_ms'],-j['priority'],j['id']))
        else:raise ValueError(candidate_name)
        if policy=='LPT_unguarded_ablation':return ranked
        locked_ranked=order(jobs,'P1')
        # SLA guard: reject a faster ordering if its calibration-based
        # *predicted* synthetic deadline misses exceed locked P1.
        return ranked if predictive_misses(ranked,cap)<=predictive_misses(locked_ranked,cap) else locked_ranked
    raise ValueError(policy)

def schedule(jobs,durations,policy,cap,candidate_name=None,with_events=False):
    assert cap in CAPS
    ranked=order(jobs,policy,candidate_name,cap)
    workers=[(0.0,i) for i in range(cap)];heapq.heapify(workers)
    events=[]; previous_launch= -1e7
    batch_gate=0.0
    for idx,j in enumerate(ranked):
        ready,worker=heapq.heappop(workers)
        if policy=='B2':
            # Fixed-batch: cap connections per batch; next batch begins only
            # after all earlier jobs finish + fixed 10-ms inter-batch pause.
            if idx%cap==0:
                batch_gate=max(x[0] for x in workers+[ (ready,worker) ]) if idx else 0.0
                if idx: batch_gate+=10.0
            start=max(batch_gate,ready)
        elif policy=='B3':
            # Fixed rate: one new migration is dispatched every 8 ms.
            start=max(ready,previous_launch+8.0)
        else:
            start=ready
        end=start+durations[j['id']]
        previous_launch=start
        heapq.heappush(workers,(end,worker))
        events.append({'job':j['id'],'scenario':j['scenario'],'priority':j['priority'],'load_assumption':j['load'],
                       'synthetic_deadline_ms':j['deadline_ms'],'original_tls_latency_ms':round(durations[j['id']],5),
                       'modeled_start_ms':round(start,5),'modeled_finish_ms':round(end,5),
                       'modeled_deadline_miss':int(end>j['deadline_ms'])})
    finishes=np.asarray([e['modeled_finish_ms'] for e in events]);
    weights=np.asarray([e['priority'] for e in events]);
    out={'modeled_batch_makespan_ms':round(float(max(finishes)),5),
         'modeled_p95_job_finish_ms':round(float(np.percentile(finishes,95)),5),
         'modeled_weighted_job_finish_ms':round(float(np.average(finishes,weights=weights)),5),
         'modeled_deadline_misses':sum(e['modeled_deadline_miss'] for e in events)}
    return (out,events) if with_events else out

def draw_times(rng,template,pool):
    return {j['id']:float(rng.choice(pool[(j['scenario'],GROUP)])) for j in template}

def candidates_dev_select(dev,templates):
    options=['LPT','LPT_PRIORITY','LPT_URGENT','SLACK_LPT']
    rng=np.random.default_rng(SEED+117)
    tuning=[]
    # Single candidate shared over ALL profiles + BOTH caps; no held-out data used.
    stats={o:[] for o in options}
    for profile in PROFILES:
        jobs=templates[profile]
        for trial in range(1,NDEV+1):
            durations=draw_times(rng,jobs,dev)
            for cap in CAPS:
                baseline=schedule(jobs,durations,'B4',cap)
                for name in options:
                    res=schedule(jobs,durations,'LPT_unguarded_ablation',cap,candidate_name=name)
                    # primary candidate selection: modeled mean completion, secondary deadline penalty;
                    # NO service disruption measurements present.
                    scale=max(baseline['modeled_batch_makespan_ms'],1)
                    loss=res['modeled_batch_makespan_ms']/scale +0.15*(res['modeled_p95_job_finish_ms']/scale) +0.05*(res['modeled_deadline_misses']/12)
                    stats[name].append(loss)
    for name,v in stats.items():tuning.append({'candidate':name,'development_replay_units':len(v),'mean_development_objective':round(float(np.mean(v)),7)})
    chosen=min(tuning,key=lambda x:(x['mean_development_objective'],x['candidate']))['candidate']
    save_csv(RESULT/'candidate_development_selection.csv',tuning)
    return chosen

def bootstrap_ci_mean_differences(v,seed):
    v=np.asarray(v,float)
    rng=np.random.default_rng(seed)
    # Conditional Monte Carlo CI for mean paired replay contrast.
    # Not external population CI or physical experiment inferential evidence.
    indices=rng.integers(0,len(v),size=(3000,len(v)))
    means=np.mean(v[indices],axis=1)
    return float(np.percentile(means,2.5)),float(np.percentile(means,97.5))

def main():
    dev,held,manifest=load_sources()
    means={p:float(np.mean(dev[(p,GROUP)])) for p in PROFILES[:3]}
    templates={p:jobs_template(p,means) for p in PROFILES}
    chosen=candidates_dev_select(dev,templates)
    rng=np.random.default_rng(SEED+445)
    rows=[];event_rows=[];pairs=[]
    for profile in PROFILES:
        j=templates[profile]
        for trial in range(1,NTEST+1):
            durations=draw_times(rng,j,held)
            for cap in CAPS:
                res={}
                for p in POLICIES:
                    met,ev=schedule(j,durations,p,cap,chosen,with_events=True)
                    res[p]=met
                    rows.append({'profile':profile,'trial':trial,'cap':cap,'policy':p,'source_group':GROUP,
                                 'n_services':12,'candidate_order':chosen if p in ('P1_v1.1_candidate','LPT_unguarded_ablation') else '',**met})
                    for e in ev:event_rows.append({'profile':profile,'trial':trial,'cap':cap,'policy':p,**e})
                for p in ('P1','P1_v1.1_candidate','LPT_unguarded_ablation'):
                    b=res['B4'];x=res[p]
                    pairs.append({'profile':profile,'trial':trial,'cap':cap,'policy':p,
                    'delta_makespan_ms':round(x['modeled_batch_makespan_ms']-b['modeled_batch_makespan_ms'],5),
                    'delta_p95_job_finish_ms':round(x['modeled_p95_job_finish_ms']-b['modeled_p95_job_finish_ms'],5),
                    'delta_weighted_finish_ms':round(x['modeled_weighted_job_finish_ms']-b['modeled_weighted_job_finish_ms'],5),
                    'delta_deadline_misses':x['modeled_deadline_misses']-b['modeled_deadline_misses']})
    save_csv(RESULT/'matched_policy_runs_28000.csv',rows)
    save_csv(RESULT/'matched_job_events_336000.csv',event_rows)
    save_csv(RESULT/'paired_P1_vs_B4_12000.csv',pairs)
    summary=[];paired_summary=[]
    for profile in PROFILES:
      for cap in CAPS:
        for p in POLICIES:
          sub=[r for r in rows if r['profile']==profile and r['cap']==cap and r['policy']==p]
          summary.append({'profile':profile,'cap':cap,'policy':p,'n_trials':len(sub),
             'mean_makespan_ms':round(float(np.mean([r['modeled_batch_makespan_ms'] for r in sub])),4),
             'mean_p95_job_finish_ms':round(float(np.mean([r['modeled_p95_job_finish_ms'] for r in sub])),4),
             'mean_priority_weighted_finish_ms':round(float(np.mean([r['modeled_weighted_job_finish_ms'] for r in sub])),4),
             'mean_deadline_misses':round(float(np.mean([r['modeled_deadline_misses'] for r in sub])),4)})
        for p in ('P1','P1_v1.1_candidate','LPT_unguarded_ablation'):
          sub=[r for r in pairs if r['profile']==profile and r['cap']==cap and r['policy']==p]
          for k in ('delta_makespan_ms','delta_p95_job_finish_ms','delta_weighted_finish_ms','delta_deadline_misses'):
            a=[r[k] for r in sub];lower,upper=bootstrap_ci_mean_differences(a,SEED+cap+PROFILES.index(profile)*100+len(k))
            paired_summary.append({'profile':profile,'cap':cap,'policy':p,'metric':k,'n_trial_replays':len(a),
                'mean_paired_difference':round(float(np.mean(a)),5),
                'conditional_replay_CI95_low':round(lower,5),'conditional_replay_CI95_high':round(upper,5),
                'percent_positive':round(float(100*np.mean(np.asarray(a)>0)),2)})
    save_csv(RESULT/'summary_56.csv',summary)
    save_csv(RESULT/'paired_statistics_96.csv',paired_summary)
    metadata={'type':'EXTERNAL_RECORDED_TLS_TIMINGS_AND_MODELED_SCHEDULING_REPLAY',
      'source':'https://github.com/usama0print/pqc-tls-benchmarking',
      'source_commit':'7a74485a533da9ec7f4adccc644d05c69cf2ddae',
      'source_rows_used':'6 original files x 1000 rows = 6000 (of repository 18000)',
      'source_rows_verified':sum(x['rows'] for x in manifest),
      'dev_source_rows_per_file':200,'heldout_source_rows_per_file':800,
      'developement_replays_per_profile':NDEV,'holdout_trials_per_profile_and_cap':NTEST,
      'policies':POLICIES,'cap_values':CAPS,'profiles':PROFILES,
      'total_heldout_policy_runs':len(rows),'total_heldout_modeled_job_events':len(event_rows),
      'rng_seed':SEED,'trained_candidate':chosen,'calibration_means_ms':means,
      'locked_protocol':'V1.0 H1.0 baseline unchanged; P1 candidate v1.1 exploratory only',
      'metric_scope':'MODELLED schedule finish times; NOT measured service disruption',
      'known_limits':['No actual OpenFlow/ONOS/OVS, separate network namespaces or real SDN network','Single-source TLS full CLI wall time measured, not isolated TLS protocol handshake time',
      'Trace-driven duration draws may repeat observations; 500 scheduling runs do not mean 500 new real measurements','Job load/priority/deadlines synthetic fixed assumptions; source only measures TLS command latency','No congestion contention, retries, node faults, controller overhead or policy downgrade checks modeled','All strategies fixed at equal maximum simultaneous migration jobs; baseline fixed-batch/fixed-rate controls retain extra pacing','P1 locked urgency ranking tested with concurrency override solely for controlled fairness; P1-v1.1 applies dev-only predicted-deadline guard; no candidate is promoted to locked change','Bootstrap CIs summarize conditional replay variability rather than infer physical latency population or security superiority']}
    (RESULT/'experiment_manifest.json').write_text(json.dumps(metadata,indent=2),encoding='utf-8')
    print(json.dumps({'chosen':chosen,'counts':{'runs':len(rows),'events':len(event_rows),'pairs':len(pairs)},
    'mixed_summary':[r for r in summary if r['profile']=='mixed'],
    'mixed_P1_pairs':[r for r in paired_summary if r['profile']=='mixed' and r['metric']=='delta_makespan_ms']},indent=2))

if __name__=='__main__':main()
