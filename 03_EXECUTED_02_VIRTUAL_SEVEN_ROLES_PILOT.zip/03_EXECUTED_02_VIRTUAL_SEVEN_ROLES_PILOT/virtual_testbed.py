#!/usr/bin/env python3
"""SEVEN PROCESS ROLE LOOPBACK TESTBED -- NOT SDN HARDWARE OR VIRTUAL MACHINES.
C0 process + SW1/SW2 TCP byte-relays + CL1/CL2 dispatchers + SR1/SR2
real OpenSSL 3.5 TLS servers; runs 5 policies B1 B2 B3 B4 P1.
Measured 'reconnect interval' is NOT active-service disruption.
"""
from __future__ import annotations
import argparse, asyncio, csv, datetime as dt, http.server, json, os, random, socket, statistics, subprocess, sys, threading, time, urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from urllib.error import URLError

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'src'))
from migration_scheduler import plan,load_jobs,ALGORITHMS

HOSTS={'C0':'127.0.0.10','SW1':'127.0.0.11','SW2':'127.0.0.12','CL1':'127.0.0.21','CL2':'127.0.0.22','SR1':'127.0.0.31','SR2':'127.0.0.32'}
ROUTES={
    'SW1': [('127.0.0.11',24101,'127.0.0.12',24201,'CL1→SW1→SW2→SR1'),('127.0.0.11',24102,'127.0.0.12',24202,'CL2→SW1→SW2→SR2')],
    'SW2': [('127.0.0.12',24201,'127.0.0.31',24301,'SW2→SR1'),('127.0.0.12',24202,'127.0.0.32',24302,'SW2→SR2')],
}
PORTS={'CL1':24101,'CL2':24102}
AGENT_PORTS={'CL1':24021,'CL2':24022}
ENV_LABEL='SINGLE_KERNEL_LOOPBACK_SEVEN_PROCESS_ROLES_NOT_OVS_ONOS'

async def pipe(reader,writer):
    count=0
    try:
        while True:
            data=await reader.read(65536)
            if not data:break
            writer.write(data)
            await writer.drain()
            count+=len(data)
    except (ConnectionResetError,BrokenPipeError,asyncio.CancelledError):pass
    finally:
        try:writer.write_eof()
        except (OSError,NotImplementedError):pass
    return count

async def serve_proxy(role):
    async def accept(cr,cw,dip,dport,route):
        try:sr,sw=await asyncio.wait_for(asyncio.open_connection(dip,dport),timeout=3)
        except (OSError,asyncio.TimeoutError):
            cw.close();await cw.wait_closed();return
        a,b=await asyncio.gather(pipe(cr,sw),pipe(sr,cw))
        for w in (cw,sw):
            try:w.close();await w.wait_closed()
            except OSError:pass
        print(json.dumps({'role':role,'route':route,'bytes_to_server':a,'bytes_to_client':b}),flush=True)
    servers=[]
    for bind,port,dip,dport,label in ROUTES[role]:
        servers.append(await asyncio.start_server(lambda cr,cw,dip=dip,dport=dport,label=label:accept(cr,cw,dip,dport,label),bind,port,limit=2**17))
    print(json.dumps({'role':role,'status':'READY','routes':len(servers)}),flush=True)
    await asyncio.gather(*(s.serve_forever() for s in servers))

def probe(node,group,tag,trial):
    cmd=[str(ROOT/'bin'/'tlsprobe'),'client','--host',HOSTS['SW1'],'--port',str(PORTS[node]),'--group',group,'--ca',str(ROOT/'certs'/'server.crt'),'--server-name','sdn-pqc.local','--tag',tag,'--trial',trial]
    t=time.monotonic_ns()
    try:p=subprocess.run(cmd,capture_output=True,text=True,timeout=10)
    except subprocess.TimeoutExpired:
        return {'success':False,'wall_ms':(time.monotonic_ns()-t)/1e6,'handshake_ms':None,'error':'timeout','group':''}
    wall=(time.monotonic_ns()-t)/1e6
    fields=next(csv.reader([p.stdout.strip()])) if p.stdout.strip() else []
    ok=(p.returncode==0 and len(fields)==13 and fields[5].lower()==group.lower() and fields[6]=='1' and fields[10]=='1')
    return {'success':ok,'wall_ms':wall,'handshake_ms':float(fields[7]) if len(fields)==13 else None,'app_ms':float(fields[8]) if len(fields)==13 else None,'group':fields[5] if len(fields)==13 else '', 'cipher':fields[11] if len(fields)==13 else '', 'error':p.stderr[-300:] if not ok else ''}

class Worker(http.server.BaseHTTPRequestHandler):
    node=None
    def log_message(self,*args):pass
    def do_GET(self):
        if self.path=='/ready':self.send_json({'role':self.node,'status':'READY','pid':os.getpid()})
        else:self.send_error(404)
    def do_POST(self):
        if self.path!='/run':return self.send_error(404)
        try:
            req=json.loads(self.rfile.read(int(self.headers.get('Content-Length',0))))
            if req.get('required_group')!='X25519MLKEM768':raise ValueError('Hybrid-only migration policy is mandatory')
            started=time.monotonic_ns()
            cl=probe(self.node,'X25519',req['policy'],f"{req['trial']}-{req['job']}-classical")
            t_old_ack=time.monotonic_ns()
            hy=probe(self.node,'X25519MLKEM768',req['policy'],f"{req['trial']}-{req['job']}-hybrid")
            t_new_ack=time.monotonic_ns()
            result={ 'role':self.node,'job':req['job'],'policy':req['policy'],'trial':req['trial'],
                     'classical_ok':cl['success'],'hybrid_ok':hy['success'],
                     'negotiated_classical':cl['group'],'negotiated_hybrid':hy['group'],
                     'classical_handshake_ms':cl['handshake_ms'],'hybrid_handshake_ms':hy['handshake_ms'],
                     'reconnect_interval_ms':(t_new_ack-t_old_ack)/1e6,
                     'total_pair_wall_ms':(t_new_ack-started)/1e6,
                     'error':(cl['error']+' '+hy['error']).strip()[:400] }
            self.send_json(result)
        except Exception as e:self.send_json({'error':repr(e)},500)
    def send_json(self,item,status=200):
        out=json.dumps(item).encode();self.send_response(status);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(out)));self.end_headers();self.wfile.write(out)

def serve_worker(role):
    cls=type('NodeWorker',(Worker,),{'node':role})
    server=http.server.ThreadingHTTPServer((HOSTS[role],AGENT_PORTS[role]),cls)
    print(json.dumps({'role':role,'status':'READY','port':AGENT_PORTS[role]}),flush=True)
    server.serve_forever()

def readiness(role):
    if role.startswith('CL'):
        try:
            with urllib.request.urlopen(f'http://{HOSTS[role]}:{AGENT_PORTS[role]}/ready',timeout=.3) as res:return json.load(res).get('role')==role
        except (OSError,ValueError):return False
    if role.startswith('SR'):return reachable(HOSTS[role], 24301 if role=='SR1' else 24302)
    if role=='SW1':return all(reachable('127.0.0.11',i) for i in (24101,24102))
    if role=='SW2':return all(reachable('127.0.0.12',i) for i in (24201,24202))
    return False

def reachable(ip,port):
    try:
        with socket.create_connection((ip,port),timeout=.15):return True
    except OSError:return False

def agent_call(job,policy,trial):
    idx=int(job.id[1:]); role='CL1' if idx%2 else 'CL2'
    data=json.dumps({'job':job.id,'trial':trial,'policy':policy,'required_group':job.required_group}).encode()
    req=urllib.request.Request(f'http://{HOSTS[role]}:{AGENT_PORTS[role]}/run',data=data,headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=20) as resp:return json.load(resp)

def build():
    (ROOT/'bin').mkdir(exist_ok=True);(ROOT/'logs').mkdir(exist_ok=True);(ROOT/'certs').mkdir(exist_ok=True);(ROOT/'results').mkdir(exist_ok=True)
    output=ROOT/'bin'/'tlsprobe'
    cmd=['cc','-O2','-std=c11','-Wall','-Wextra','-o',str(output),str(ROOT/'src'/'tlsprobe.c'),'-lssl','-lcrypto','-lpthread']
    subprocess.run(cmd,check=True,capture_output=True,text=True)
    cert=ROOT/'certs'/'server.crt';key=ROOT/'certs'/'server.key'
    if not(cert.exists() and key.exists()):
        subprocess.run(['openssl','req','-x509','-newkey','ec','-pkeyopt','ec_paramgen_curve:P-256','-nodes','-keyout',str(key),'-out',str(cert),'-days','3','-subj','/CN=sdn-pqc.local','-addext','subjectAltName=DNS:sdn-pqc.local'],check=True,capture_output=True)
    return output

def spawn(role):
    logfile=(ROOT/'logs'/f'{role}.jsonl').open('w')
    if role.startswith('SR'):
        binary=ROOT/'bin'/'tlsprobe'
        cmd=[str(binary),'server','--bind',HOSTS[role],'--port',str(24301 if role=='SR1' else 24302),'--group','X25519:X25519MLKEM768','--cert',str(ROOT/'certs'/'server.crt'),'--key',str(ROOT/'certs'/'server.key')]
    else:cmd=[sys.executable, str(Path(__file__).resolve()),'--role',role]
    p=subprocess.Popen(cmd,stdout=logfile,stderr=subprocess.STDOUT,start_new_session=True)
    return p,logfile

def run(trials=3,max_parallel=4,load=.62):
    build()
    # C0 runs in this main Python process, all six other logical nodes run in distinct processes.
    child={r:spawn(r) for r in ('SW2','SW1','SR1','SR2','CL1','CL2')}
    records=[]; runs=[]
    try:
        for _ in range(100):
            if all(readiness(r) for r in child):break
            time.sleep(.06)
        else:raise RuntimeError('Unable to bring up all six child role processes; see logs/*.jsonl')
        processes={r:p.pid for r,(p,_) in child.items()};processes['C0']=os.getpid()
        assert len(set(processes.values()))==7
        print('READY: 7 distinct physical OS processes representing nodes: '+json.dumps(processes),flush=True)
        # Confirm real end-to-end hybrid handshake through both TCP forwarding processes before measured trials.
        for agent in ('CL1','CL2'):
            h=probe(agent,'X25519MLKEM768','route_preflight','0')
            if not h['success']:raise RuntimeError('Real routed hybrid TLS probe failed for '+agent+': '+h['error'])
        print('PASS: Both client-to-server paths have verified hybrid TLS handshakes through SW1 and SW2 forwarding processes.',flush=True)
        jobs=load_jobs();order=list(ALGORITHMS);rng=random.Random(20261028)
        for trial in range(1,trials+1):
            rng.shuffle(order)
            for policy in order:
                t0=time.monotonic_ns();batchsizes=[]
                plans=plan(jobs,policy,observed_network_load=load,max_parallel=max_parallel,fixed_batch=2)
                current=[]
                for n,batch in enumerate(plans):
                    batchsizes.append(len(batch))
                    with ThreadPoolExecutor(max_workers=max_parallel) as pool:
                        futures=[pool.submit(agent_call,j,policy,trial) for j in batch]
                        for f in as_completed(futures):
                            result=f.result();result.update({'timestamp_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'environment':ENV_LABEL,'configured_load_signal':load})
                            current.append(result)
                    if n<len(plans)-1 and policy in ('B2','B3'):time.sleep(.010 if policy=='B2' else .008)
                duration=(time.monotonic_ns()-t0)/1e6
                assert len(current)==len(jobs),(policy,len(current))
                assert all(x.get('classical_ok') and x.get('hybrid_ok') for x in current),current
                records.extend(current)
                runs.append({'trial':trial,'policy':policy,'wall_ms':duration,'successful_migrations':len(current),'batch_sizes':batchsizes})
                print(f'COMPLETED trial={trial} policy={policy} jobs={len(current)} all_verified=True run_wall_ms={duration:.2f}',flush=True)
        out=ROOT/'results';csvfile=out/'virtual_7_role_tls_reconnect_events.csv'
        cols=['timestamp_utc','environment','trial','policy','job','role','configured_load_signal','classical_ok','hybrid_ok','negotiated_classical','negotiated_hybrid','classical_handshake_ms','hybrid_handshake_ms','reconnect_interval_ms','total_pair_wall_ms','error']
        with csvfile.open('w',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=cols);writer.writeheader();writer.writerows(({k:x.get(k,'') for k in cols} for x in records))
        with (out/'virtual_7_role_policy_runs.csv').open('w',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=['trial','policy','wall_ms','successful_migrations','batch_sizes']);writer.writeheader();writer.writerows(runs)
        # Descriptive, not inferential statistics on one physical host.
        groups={}
        for policy in ALGORITHMS:
            subset=[x for x in records if x['policy']==policy]
            times=sorted(x['reconnect_interval_ms'] for x in subset)
            rtimes=[x['wall_ms'] for x in runs if x['policy']==policy]
            groups[policy]={'events':len(subset),'validated_event_fraction':sum(x['classical_ok'] and x['hybrid_ok'] for x in subset)/len(subset),'mean_reconnect_interval_ms':round(statistics.mean(times),4),'p95_reconnect_interval_ms':round(times[max(0,int((len(times)-1)*.95))],4),'mean_policy_run_ms':round(statistics.mean(rtimes),4),'run_wall_ms':rtimes}
        output={'environment':ENV_LABEL,'notes':['Seven distinct OS processes on one shared Linux kernel; distinct loopback IP identities; not seven virtual machines','SW1/SW2 are TCP byte forwarding proxies, not ONOS-controlled Open vSwitch/OpenFlow devices','Each event is successful classical TLS ACK followed by successful hybrid TLS ACK through two proxies; it is not seamless active service migration','Reported reconnect interval includes subprocess startup, host scheduling and TLS handshakes; it is not p95 user-facing service disruption','Configured load signal is a test input, not measured offered load or link utilization','All results are exploratory within-host functional testing; NO physical hardware superiority claim'], 'openss_l_version':subprocess.check_output(['openssl','version'],text=True).strip(),'nodes':processes,'trials_per_policy':trials,'services_per_trial':len(jobs),'total_events':len(records),'total_tls_handshakes':len(records)*2+2,'policy_statistics':groups,'all_verified':all(x['classical_ok'] and x['hybrid_ok'] for x in records),'timestamp_utc':dt.datetime.now(dt.timezone.utc).isoformat()}
        (out/'seven_virtual_nodes_summary.json').write_text(json.dumps(output,indent=2))
        # Snapshot live process health and logs while processes still exist
        node_health={'pid_map':processes,'all_role_processes_alive':all(p.poll() is None for p,_ in child.values()),'loopback_routes_verified':True,'openssl_hybrid_verified':True}
        (out/'node_health.json').write_text(json.dumps(node_health,indent=2))
        print('SUCCESS: '+str(len(records))+' 2-stage TLS reconnection events, '+str(len(records)*2+2)+' successful authenticated TLS handshakes including preflight.',flush=True)
        print('NO VALIDATED SDN/PHYSICAL SUPERIORITY: proxy-based loopback only.',flush=True)
        print('Results:',out,flush=True)
    finally:
        for role,(p,log) in child.items():
            if p.poll() is None:p.terminate()
        for role,(p,log) in child.items():
            try:p.wait(timeout=3)
            except subprocess.TimeoutExpired:p.kill();p.wait()
            log.close()

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--role',choices=['SW1','SW2','CL1','CL2']);ap.add_argument('--trials',type=int,default=3);ap.add_argument('--configured-load-signal',type=float,default=.62)
    args=ap.parse_args()
    if args.role in ('SW1','SW2'):asyncio.run(serve_proxy(args.role))
    elif args.role:serve_worker(args.role)
    else:run(trials=args.trials,load=args.configured_load_signal)
if __name__=='__main__':main()
