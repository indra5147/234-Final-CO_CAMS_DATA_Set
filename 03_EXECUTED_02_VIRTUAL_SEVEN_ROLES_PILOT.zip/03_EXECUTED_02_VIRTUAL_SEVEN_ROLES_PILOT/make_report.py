from pathlib import Path
import csv,json,hashlib,subprocess,datetime as dt,statistics
from collections import defaultdict
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path(__file__).resolve().parent;out=root/'results'
summary=json.loads((out/'seven_virtual_nodes_summary.json').read_text())
with (out/'virtual_7_role_tls_reconnect_events.csv').open() as f: events=list(csv.DictReader(f))
with (out/'virtual_7_role_policy_runs.csv').open() as f: runs=list(csv.DictReader(f))
by=defaultdict(list)
for x in events:by[x['policy']].append(x)
assert len(events)==1800 and all(len(by[x])==360 for x in ['B1','B2','B3','B4','P1'])
assert all(x['negotiated_classical'].lower()=='x25519' and x['negotiated_hybrid']=='X25519MLKEM768' and x['classical_ok']=='True' and x['hybrid_ok']=='True' for x in events)
# Three plots, deliberately showing distinct outcomes and no false superiority inference
names=['B1','B2','B3','B4','P1']
fig,ax=plt.subplots(figsize=(8,4.2)); y=[summary['policy_statistics'][x]['mean_policy_run_ms'] for x in names]
ax.bar(names,y);ax.set_ylabel('Mean wall-clock time (ms)');ax.set_xlabel('Scheduling policy');ax.set_title('Single-host TLS reconnect batch completion (30 repeats)');ax.text(.02,.96,'Proxy/loopback proof-of-concept, not physical SDN',transform=ax.transAxes,va='top',fontsize=9)
fig.tight_layout();fig.savefig(out/'policy_batch_completion.png',dpi=220);plt.close(fig)
fig,ax=plt.subplots(figsize=(8,4.2));y=[summary['policy_statistics'][x]['p95_reconnect_interval_ms'] for x in names]
ax.bar(names,y);ax.set_ylabel('p95 reconnect interval (ms)');ax.set_xlabel('Scheduling policy');ax.set_title('Sequential TLS reconnect interval (360 events/policy)');ax.text(.02,.96,'Not application downtime or active-session migration',transform=ax.transAxes,va='top',fontsize=9)
fig.tight_layout();fig.savefig(out/'reconnect_interval_p95.png',dpi=220);plt.close(fig)
# Real handshake phases across all event classes
fig,ax=plt.subplots(figsize=(8,4.3))
a=[float(x['classical_handshake_ms']) for x in events];b=[float(x['hybrid_handshake_ms']) for x in events]
ax.boxplot([a,b],tick_labels=['X25519','X25519MLKEM768'],showfliers=False)
ax.set_ylabel('TLS handshake time (ms)');ax.set_title('Real OpenSSL 3.5.5 TLS 1.3 over two TCP proxies');ax.text(.02,.96,'Shared Linux kernel, loopback paths, no physical interfaces',transform=ax.transAxes,va='top',fontsize=9)
fig.tight_layout();fig.savefig(out/'tls_handshake_distributions.png',dpi=220);plt.close(fig)

# Percentiles / descriptive metadata
for code in names:
    x=by[code];g=summary['policy_statistics'][code]
    g['mean_classical_handshake_ms']=round(statistics.mean(float(z['classical_handshake_ms']) for z in x),4)
    g['mean_hybrid_handshake_ms']=round(statistics.mean(float(z['hybrid_handshake_ms']) for z in x),4)
(out/'seven_virtual_nodes_summary.json').write_text(json.dumps(summary,indent=2))
# Digest reproducibility identifiers; omit private keys
manifest={}
for p in [root/'virtual_testbed.py',root/'src'/'tlsprobe.c',root/'src'/'migration_scheduler.py',out/'virtual_7_role_tls_reconnect_events.csv',out/'virtual_7_role_policy_runs.csv']:
    manifest[str(p.relative_to(root))]=hashlib.sha256(p.read_bytes()).hexdigest()
(out/'sha256_manifest.json').write_text(json.dumps({'files':manifest,'openssl':summary['openss_l_version'],'python':subprocess.check_output(['python','--version'],text=True).strip()},indent=2))

lines=[]
lines+=['# Executed preliminary test report: seven isolated *roles* on a shared host','',f'**Executed (UTC):** {summary["timestamp_utc"]}',f'**TLS library:** {summary["openss_l_version"]}',f'**Trials per policy:** {summary["trials_per_policy"]}',f'**TLS reconnect operations:** {summary["total_events"]:,}',f'**Successful authenticated TLS handshakes (includes 2 preflights):** {summary["total_tls_handshakes"]:,}','',
'## What was actually tested','',
'- Seven distinct operating-system **processes**: C0 orchestrator, SW1/SW2 TCP forwarders, CL1/CL2 agent processes and SR1/SR2 C/OpenSSL TLS servers.',
'- Two real loopback TCP paths: CL1→SW1→SW2→SR1 and CL2→SW1→SW2→SR2, each carrying real TLS 1.3 records end to end.',
'- Each event comprises one successful **X25519** TLS handshake and application ACK, followed by one successful **X25519MLKEM768** handshake and ACK.',
'- Compared scheduling policies B1 (bounded bulk), B2 (fixed batch), B3 (fixed paced stage), B4 (load-sorted greedy), and P1 (security-urgency ordering with configured-load-dependent parallelism).',
'- 12 jobs per policy per trial, 30 policy trial blocks; method ordering randomized deterministically; configured controller load signal fixed at 0.62 (not measured utilization).',
'', '## Measured descriptive values (not hardware SDN performance)','',
'| Policy | Events | Hybrid TLS success | Mean batch time (ms) | p95 reconnect interval (ms) |',
'|---|---:|---:|---:|---:|']
for code in names:
    q=summary['policy_statistics'][code]
    lines.append(f'| {code} | {q["events"]} | {q["validated_event_fraction"]*100:.0f}% | {q["mean_policy_run_ms"]:.2f} | {q["p95_reconnect_interval_ms"]:.2f} |')
lines+=['',
'**Interpretation:** The P1 process configuration had a lower observed p95 sequential reconnect interval than B4, but B4 completed the 12-event batch faster. This is a toy single-host scheduling trade-off, **not** evidence that P1 reduces end-user disruption or is superior in SDN.',
'', '## Mandatory scientific limitations','',
'1. **Not seven virtual machines:** Linux namespace/veth creation is blocked by missing CAP_NET_ADMIN. All processes share the kernel, CPU, filesystem and network loopback.',
'2. **Not ONOS/Open vSwitch:** SW1 and SW2 are custom Python TCP relays; no OpenFlow protocol or SDN controller-to-switch communication was used.',
'3. **Not active-session migration:** Each TLS probe sends PING/ACK, closes, then opens a new hybrid TLS connection. The resulting reconnect interval includes subprocess startup; it is **not** service disruption for an established continuously serving application.',
'4. **Not real load:** 0.62 is a configured scheduling signal; no link capacity percentage, 1GbE throughput or congestion was experimentally verified.',
'5. **Not held-out hardware validation:** No independent physical machines, real NIC/switch counters, H1.0 network isolation or power/thermal characterization.',
'6. **Not an algorithm superiority finding:** Only implementation correctness and preliminary descriptive timing were checked. This cannot replace the locked V1.0 hardware acceptance criteria.',
'', '## Positive correctness evidence','',
'- Two required routes successfully carried mutually verified TLS connections.',
'- All 1,800 sequential classical→hybrid reconnect events succeeded, without an incorrect negotiated group.',
'- Policy jobs executed once per strategy and all policies maintained the hybrid-only migration requirement.',
'- Full per-event timestamps, phase handshake durations, per-trial policy completion times and forwarding proxy byte counters are retained.',
'', '## Reproduce', '', '```bash', 'python virtual_testbed.py --trials 30', 'python make_report.py', '```',
'', 'Requires Linux, C compiler, Python 3.10+, OpenSSL 3.5+ including development headers, matplotlib/numpy for plotting.',
'', '## Next research steps', '',
'1. Run a privileged Linux/VM environment (or physical H1.0) with network namespaces, real OVS bridges and ONOS.',
'2. Replace short-lived TLS probes with a continuously serving TLS application and measurable real cutover interruption.',
'3. Introduce measured background load, SLA deadlines, calibrated baselines, 30 genuinely independent runs, held-out workload regimes, faults, and exact security compliance checks.',
'4. Retain and report failures and null results; make a superiority claim only if locked primary/secondary endpoint rules are satisfied.',
]
(out/'EXPERIMENTAL_REPORT.md').write_text('\n'.join(lines)+'\n')
print('\n'.join(lines[17:30]));print('Report created at:',out/'EXPERIMENTAL_REPORT.md')
