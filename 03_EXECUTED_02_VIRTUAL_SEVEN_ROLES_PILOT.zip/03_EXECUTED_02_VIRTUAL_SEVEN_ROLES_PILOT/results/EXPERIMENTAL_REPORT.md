# Executed preliminary test report: seven isolated *roles* on a shared host

**Executed (UTC):** 2026-10-28T16:02:51.273096+00:00
**TLS library:** OpenSSL 3.5.5 27 Jan 2026 (Library: OpenSSL 3.5.5 27 Jan 2026)
**Trials per policy:** 30
**TLS reconnect operations:** 1,800
**Successful authenticated TLS handshakes (includes 2 preflights):** 3,602

## What was actually tested

- Seven distinct operating-system **processes**: C0 orchestrator, SW1/SW2 TCP forwarders, CL1/CL2 agent processes and SR1/SR2 C/OpenSSL TLS servers.
- Two real loopback TCP paths: CL1→SW1→SW2→SR1 and CL2→SW1→SW2→SR2, each carrying real TLS 1.3 records end to end.
- Each event comprises one successful **X25519** TLS handshake and application ACK, followed by one successful **X25519MLKEM768** handshake and ACK.
- Compared scheduling policies B1 (bounded bulk), B2 (fixed batch), B3 (fixed paced stage), B4 (load-sorted greedy), and P1 (security-urgency ordering with configured-load-dependent parallelism).
- 12 jobs per policy per trial, 30 policy trial blocks; method ordering randomized deterministically; configured controller load signal fixed at 0.62 (not measured utilization).

## Measured descriptive values (not hardware SDN performance)

| Policy | Events | Hybrid TLS success | Mean batch time (ms) | p95 reconnect interval (ms) |
|---|---:|---:|---:|---:|
| B1 | 360 | 100% | 79.00 | 13.84 |
| B2 | 360 | 100% | 176.34 | 12.66 |
| B3 | 360 | 100% | 317.24 | 11.73 |
| B4 | 360 | 100% | 81.01 | 16.50 |
| P1 | 360 | 100% | 119.51 | 11.07 |

**Interpretation:** The P1 process configuration had a lower observed p95 sequential reconnect interval than B4, but B4 completed the 12-event batch faster. This is a toy single-host scheduling trade-off, **not** evidence that P1 reduces end-user disruption or is superior in SDN.

## Mandatory scientific limitations

1. **Not seven virtual machines:** Linux namespace/veth creation is blocked by missing CAP_NET_ADMIN. All processes share the kernel, CPU, filesystem and network loopback.
2. **Not ONOS/Open vSwitch:** SW1 and SW2 are custom Python TCP relays; no OpenFlow protocol or SDN controller-to-switch communication was used.
3. **Not active-session migration:** Each TLS probe sends PING/ACK, closes, then opens a new hybrid TLS connection. The resulting reconnect interval includes subprocess startup; it is **not** service disruption for an established continuously serving application.
4. **Not real load:** 0.62 is a configured scheduling signal; no link capacity percentage, 1GbE throughput or congestion was experimentally verified.
5. **Not held-out hardware validation:** No independent physical machines, real NIC/switch counters, H1.0 network isolation or power/thermal characterization.
6. **Not an algorithm superiority finding:** Only implementation correctness and preliminary descriptive timing were checked. This cannot replace the locked V1.0 hardware acceptance criteria.

## Positive correctness evidence

- Two required routes successfully carried mutually verified TLS connections.
- All 1,800 sequential classical→hybrid reconnect events succeeded, without an incorrect negotiated group.
- Policy jobs executed once per strategy and all policies maintained the hybrid-only migration requirement.
- Full per-event timestamps, phase handshake durations, per-trial policy completion times and forwarding proxy byte counters are retained.

## Reproduce

```bash
python virtual_testbed.py --trials 30
python make_report.py
```

Requires Linux, C compiler, Python 3.10+, OpenSSL 3.5+ including development headers, matplotlib/numpy for plotting.

## Next research steps

1. Run a privileged Linux/VM environment (or physical H1.0) with network namespaces, real OVS bridges and ONOS.
2. Replace short-lived TLS probes with a continuously serving TLS application and measurable real cutover interruption.
3. Introduce measured background load, SLA deadlines, calibrated baselines, 30 genuinely independent runs, held-out workload regimes, faults, and exact security compliance checks.
4. Retain and report failures and null results; make a superiority claim only if locked primary/secondary endpoint rules are satisfied.
