# SDN–PQC 7-Role Local Execution Package

**Status: successfully executed 30 repeated policy runs per B1/B2/B3/B4/P1.** See `results/EXPERIMENTAL_REPORT.md` for measured outcomes and limitations.

## What it is
Seven **separate OS processes**, not seven VMs/containers or separately isolated Linux hosts. Process identities C0, SW1, SW2, CL1, CL2, SR1, SR2. Two Python asyncio TCP proxies forward real OpenSSL TLS 1.3 sessions from distinct client agents to TLS servers with loopback identity IP addresses. This is a functional software prototype, **not ONOS or Open vSwitch**. It runs standard X25519 and post-quantum hybrid X25519MLKEM768 across both proxy hops. The controller schedules 12 sequential classical-to-hybrid reconnection jobs under each B1–B4/P1 policy. **This is not active-session migration, and measured reconnect intervals are not service disruption.**

## Execute on a Linux computer
Requirements: `python3` 3.10+, `cc`, OpenSSL >= 3.5.0 plus libssl headers, `openssl` command, GNU core utilities. To regenerate figures, also install `matplotlib` and `numpy`.

```bash
python3 virtual_testbed.py --trials 30
python3 make_report.py
```

The script uses 127.0.0.11:24101/24102 and 127.0.0.12:24201/24202 proxies, clients 127.0.0.21:24021 and 127.0.0.22:24022, servers 127.0.0.31:24301 and 127.0.0.32:24302. These are all loopback (not physical data IPs). It builds the C client/server and makes a temporary **development-only** self-signed ECDSA P-256 certificate in `certs/`.

## What is included

- `src/tlsprobe.c`: actual OpenSSL 3.5 application + group verification
- `src/migration_scheduler.py`: locked five candidate policy planning routines (provisional heuristic, not independently novel algorithm)
- `virtual_testbed.py`: creates C0 and starts six additional role processes; runs the policy jobs and saves raw event logs
- `results/virtual_7_role_tls_reconnect_events.csv`: real observed per-reconnection events
- `results/virtual_7_role_policy_runs.csv`: actual batch completion wall times (30 run blocks per policy)
- `results/seven_virtual_nodes_summary.json`: descriptive summaries, separate limitations
- `results/EXPERIMENTAL_REPORT.md`: accurate interpretation and limitations
- `logs/SW1.jsonl`, `logs/SW2.jsonl`: real per-proxy transmitted-byte logs
- `results/*.png`: figures derived exclusively from real test records

## Scientific boundary

This is a **single-computer localhost proof of concept**. The host prohibits privileged namespaces/veth, and ONOS/OVS have not been installed. Timing includes process creation, Python proxying and local scheduler effects; it is not generalizable. Do not cite this as physical H1.0 measurements, production SDN security, active session cutover, p95 user-facing disruption, 1GbE performance, or proof of P1 superiority. The original locked V1.0 hardware experiment requirements still stand.
